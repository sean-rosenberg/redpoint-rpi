DECLARE
    ex_duplicate_cust_num_01 EXCEPTION ( -20002, 'PRECONDITION CHECK FAILED: Duplicate cust_num(s) found in CUST_NUM_INDIVIDUAL_XREF' );
    ex_duplicate_cust_num_02 EXCEPTION ( -20003, 'CHECK FAILED: Duplicate cust_num(s) found in STANDARDIZE_STAGE.CUST_NUM_INDIVIDUAL_XREF' );
    ex_duplicate_cust_num_03 EXCEPTION ( -20004, 'CHECK FAILED: Duplicate cust_num(s) found between STANDARDIZE_CORE.CUST_NUM_INDIVIDUAL_XREF and STANDARDIZE_STAGE.CUST_NUM_INDIVIDUAL_XREF' );
    ex_duplicate_ind_id_01 EXCEPTION ( -20012, 'PRECONDITION CHECK FAILED: Duplicate individual_id(s) found in CUST_NUM_INDIVIDUAL_XREF' );
    ex_duplicate_ind_id_02 EXCEPTION ( -20013, 'CHECK FAILED: Duplicate individual_id(s) found in STANDARDIZE_STAGE.CUST_NUM_INDIVIDUAL_XREF' );
    ex_duplicate_ind_id_03 EXCEPTION ( -20014, 'CHECK FAILED: Duplicate individual_id(s) found between STANDARDIZE_CORE.CUST_NUM_INDIVIDUAL_XREF and STANDARDIZE_STAGE.CUST_NUM_INDIVIDUAL_XREF' );
    ex_cust_num_out_of_range EXCEPTION ( -20005, 'CHECK FAILED: a customer number would be created outside of the 500M range.' );
    ex_nonactive_cust_num_used EXCEPTION ( -20006, 'CHECK FAILED: a cust_num sourced from a NON_ACTIVE party profile would be assigned (CDP-1029 BR-2).' );
    ex_unreserved_external_cust_num EXCEPTION ( -20007, 'CHECK FAILED: an eligible external cust_num was left unreserved (CDP-1029 BR-1).' );
    ex_cust_num_range_exhausted EXCEPTION ( -20008, 'CHECK FAILED: the 500M range would be exhausted by this run.' );
    what_if BOOLEAN := true;
BEGIN
    BEGIN TRANSACTION;

    
    /* Step 1: Preconditions. REC_TYPE / CREATE_FEED_INSTANCE_ID are added at deploy time by
       SP_GENERATE_CUST_NUMS_add_xref_columns.sql, not here. */
    IF ( EXISTS ( SELECT 1 FROM STANDARDIZE_CORE.CUST_NUM_INDIVIDUAL_XREF GROUP BY CUST_NUM HAVING COUNT(1) > 1 ) ) THEN
        RAISE ex_duplicate_cust_num_01;
    END IF;

    IF ( EXISTS ( SELECT 1 FROM STANDARDIZE_CORE.CUST_NUM_INDIVIDUAL_XREF GROUP BY INDIVIDUAL_ID HAVING COUNT(1) > 1 ) ) THEN
        RAISE ex_duplicate_ind_id_01;
    END IF;
    

    -- High-water mark only: gaps below SEED are retired numbers and must never be reclaimed.
    CREATE OR REPLACE TEMPORARY TABLE STANDARDIZE_STAGE.cnxi_maxid AS
    SELECT
        GREATEST(500000000, IFNULL(MAX(CUST_NUM),0)) AS SEED
    FROM
        STANDARDIZE_CORE.CUST_NUM_INDIVIDUAL_XREF
    WHERE
        CUST_NUM BETWEEN 500000000 AND 599999999
    ;


    -- Every value already spoken for in the core XREF, collapsed to ONE hashable column.
    -- Replaces the correlated  ( xref.CUST_NUM = v OR xref.INDIVIDUAL_ID = v )  anti-joins:
    -- Snowflake cannot hash a disjunctive predicate, so each of those degraded to a nested
    -- loop over the full XREF -- with the BR-1 probe side now the entire ICON/MAO PK1 history
    -- rather than one feed's delta, that is the dominant cost in the procedure.
    -- IS_CUST_NUM / IS_INDIVIDUAL_ID preserve provenance so the same-column checks further
    -- down (reject classification, final insert filter) stay exact rather than merged.
    CREATE OR REPLACE TEMPORARY TABLE STANDARDIZE_STAGE.cnxi_taken AS
    SELECT
        VAL
    ,   MAX( IS_CUST_NUM )      AS IS_CUST_NUM
    ,   MAX( IS_INDIVIDUAL_ID ) AS IS_INDIVIDUAL_ID
    FROM
    (
        SELECT CUST_NUM AS VAL, 1 AS IS_CUST_NUM, 0 AS IS_INDIVIDUAL_ID
        FROM STANDARDIZE_CORE.CUST_NUM_INDIVIDUAL_XREF
        WHERE CUST_NUM IS NOT NULL

        UNION ALL

        SELECT INDIVIDUAL_ID AS VAL, 0 AS IS_CUST_NUM, 1 AS IS_INDIVIDUAL_ID
        FROM STANDARDIZE_CORE.CUST_NUM_INDIVIDUAL_XREF
        WHERE INDIVIDUAL_ID IS NOT NULL
    ) t
    GROUP BY VAL
    ;


    -- Get individual IDs not already in CUST_NUM_INDIVIDUAL_XREF
    -- these will require new CUST_NUM.
    CREATE OR REPLACE TEMPORARY TABLE STANDARDIZE_STAGE.cnxi_new_ind AS
    SELECT
        pp.INDIVIDUAL_ID
    ,   MAX(pp.UPDATE_FEED_INSTANCE_ID) AS  FEED_INSTANCE_ID
    FROM STANDARDIZE_CORE.PARTY_PROFILE AS pp
    WHERE NOT EXISTS             -- NOT IN would go blind on a single NULL INDIVIDUAL_ID
    (
        SELECT 1
        FROM STANDARDIZE_CORE.CUST_NUM_INDIVIDUAL_XREF cnxi
        WHERE cnxi.INDIVIDUAL_ID = pp.INDIVIDUAL_ID
    )
    GROUP BY pp.INDIVIDUAL_ID
    ;

    -- CDP-1029 BR-1/BR-2: SOURCE_SYSTEM_PK_1 values carried by any NON_ACTIVE
    -- ICON/MAO party profile (any individual) may never be assigned as a CUST_NUM.
    CREATE OR REPLACE TEMPORARY TABLE STANDARDIZE_STAGE.cnxi_nonactive_cust_num AS
    SELECT
        TRY_CAST( pp.SOURCE_SYSTEM_PK_1 AS NUMBER(38,0) )   AS CUST_NUM
    ,   MAX(pp.UPDATE_FEED_INSTANCE_ID)                      AS FEED_INSTANCE_ID
    FROM STANDARDIZE_CORE.PARTY_PROFILE AS pp
    WHERE
        pp.SOR_NAME IN ( 'ICON', 'MAO' )
        --TODO: 'NON_ACTIVE' not '-'
    AND UPPER( IFNULL( pp.PARTY_PROFILE_STATUS_CODE, '' ) ) = '-'
    AND TRY_CAST( pp.SOURCE_SYSTEM_PK_1 AS NUMBER(38,0) )     BETWEEN  1
                                                             AND 999999999
    AND TRY_CAST( pp.SOURCE_SYSTEM_PK_1 AS NUMBER(38,0) ) NOT BETWEEN  500000000
                                                             AND 599999999
    GROUP BY TRY_CAST( pp.SOURCE_SYSTEM_PK_1 AS NUMBER(38,0) )
    ;

    -- Get a list of externally created cust_num values to honor in
    -- CDP, these are SOURCE_SYSTEM_PK_1 from SOR_NAME = ICON or MAO
    -- WHERE SSPK1 is not already used as CUST_NUM or INDIVIDUAL_ID
    -- in CUST_NUM_INDIVIDUAL_XREF and the value is in the range
    -- 0..499999999,600000000..999999999
    CREATE OR REPLACE TEMPORARY TABLE STANDARDIZE_STAGE.cnxi_external_cust_num AS
    WITH cte_ext_num AS
    (
        SELECT
            pp.INDIVIDUAL_ID
        ,   TRY_CAST( pp.SOURCE_SYSTEM_PK_1 AS NUMBER(38,0) )   AS t_cust_num
        ,   pp.SOURCE_REC_CREATE_DATETIME                       AS t_src_create_date
        ,   pp.SOR_NAME
        ,   new_ind.FEED_INSTANCE_ID
        ,   CASE WHEN EXISTS                                    -- CDP-1029 BR-2: PK1s sourced
                (                                                -- from a NON_ACTIVE record are
                    SELECT 1                                    -- never eligible as CUST_NUM,
                    FROM STANDARDIZE_STAGE.cnxi_nonactive_cust_num na
                    WHERE na.CUST_NUM = TRY_CAST( pp.SOURCE_SYSTEM_PK_1 AS NUMBER(38,0) )
                ) THEN 0 ELSE 1 END                              AS CN_ELIG_FLAG
        FROM STANDARDIZE_CORE.PARTY_PROFILE AS  pp
        JOIN STANDARDIZE_STAGE.cnxi_new_ind AS  new_ind ON pp.INDIVIDUAL_ID = new_ind.INDIVIDUAL_ID
        WHERE
            pp.SOR_NAME IN ( 'ICON', 'MAO' )  -- External CUST_NUM sources, include ICON and MAO
        AND t_cust_num IS NOT NULL            -- Extenal cust num must not be NULL
        AND t_cust_num     BETWEEN  1         -- must be positive and in the range
                                AND 999999999 -- 1 through 999,999,999
        AND t_cust_num NOT BETWEEN  500000000 -- but not in the reserved CDP range of 
                                AND 599999999 -- 500,000,000 through 599,999,999
    )
    SELECT
        src.INDIVIDUAL_ID
    ,   src.FEED_INSTANCE_ID
    ,   src.SOR_NAME
    ,   src.t_cust_num
    ,   src.CN_ELIG_FLAG
    ,   DENSE_RANK()                       -- Rank externally source cust_nums from 1..[n]
        OVER (                             -- where 1 is the highest rank and is used as
            PARTITION BY                   -- the cust_num for the individual_id and 
                src.INDIVIDUAL_ID          -- 2+ are recorded as 'merged' values that
            ORDER BY                       -- were unused in CDP from CDP's PoV. Eligible
                src.CN_ELIG_FLAG DESC      -- (non-NON_ACTIVE) candidates always outrank
              , src.t_src_create_date DESC -- ineligible ones (CDP-1029 BR-2).
              , src.t_cust_num ASC
              , src.SOR_NAME
        ) AS EXTERNAL_RANK
    ,   ROW_NUMBER()                        -- CUST_NUM_RANK prevents re-use of the same 
        OVER (                              -- external cust_num in this procedure, we
            PARTITION BY                    -- ONLY USE RECORDS having CUST_NUM_RANK = 1
                src.t_cust_num
            ORDER BY
                src.CN_ELIG_FLAG DESC
              , src.INDIVIDUAL_ID
              , src.t_src_create_date DESC
              , src.SOR_NAME
        ) AS CUST_NUM_RANK
    FROM cte_ext_num src
    WHERE
        NOT EXISTS
        (                   -- external cust_num value may not have been
                SELECT 1    -- previously used as cust_num or individual_id
                FROM STANDARDIZE_STAGE.cnxi_taken k
                WHERE k.VAL = src.t_cust_num
        )
    ;

    -- These are the the CUST_NUM values which will be used in CDP
    CREATE OR REPLACE TEMPORARY TABLE STANDARDIZE_STAGE.cnxi_new_external_cust_num AS
    SELECT
        new_ind.INDIVIDUAL_ID
    ,   ext_num.t_cust_num          AS CUST_NUM
    ,   'new_external_cust_num'     AS REC_TYPE
    ,   new_ind.FEED_INSTANCE_ID
    FROM STANDARDIZE_STAGE.cnxi_new_ind new_ind
    JOIN STANDARDIZE_STAGE.cnxi_external_cust_num ext_num ON new_ind.INDIVIDUAL_ID = ext_num.INDIVIDUAL_ID
    WHERE
        ext_num.EXTERNAL_RANK = 1
    AND ext_num.CUST_NUM_RANK = 1
    AND ext_num.CN_ELIG_FLAG = 1
    ;


    CREATE OR REPLACE TEMPORARY TABLE STANDARDIZE_STAGE.cnxi_merged_external_cust_num AS
    SELECT
        ext_num.t_cust_num          AS INDIVIDUAL_ID
    ,   ext_num.t_cust_num          AS CUST_NUM
    ,   'merged_external_cust_num'  AS REC_TYPE 
    ,   ext_num.FEED_INSTANCE_ID
    FROM STANDARDIZE_STAGE.cnxi_external_cust_num ext_num
    WHERE
        ext_num.EXTERNAL_RANK > 1
    AND ext_num.CUST_NUM_RANK = 1
    AND ext_num.CN_ELIG_FLAG = 1
    ;


    -- CDP-1029 BR-1/BR-2: retire NON_ACTIVE-sourced PK1s permanently so they can
    -- never be (re)claimed as a CUST_NUM in a later run (UC-07, UC-09, UC-11).
    CREATE OR REPLACE TEMPORARY TABLE STANDARDIZE_STAGE.cnxi_nonactive_external_cust_num AS
    SELECT
        na.CUST_NUM                     AS INDIVIDUAL_ID
    ,   na.CUST_NUM                     AS CUST_NUM
    ,   'nonactive_external_cust_num'   AS REC_TYPE
    ,   na.FEED_INSTANCE_ID
    FROM STANDARDIZE_STAGE.cnxi_nonactive_cust_num na
    WHERE
        NOT EXISTS
        (
                SELECT 1
                FROM STANDARDIZE_STAGE.cnxi_taken k
                WHERE k.VAL = na.CUST_NUM
        )
    ;


    -- CDP-1029 BR-1: any in-range ICON/MAO PK1 not already a CUST_NUM/INDIVIDUAL_ID and not
    -- claimed by an above branch is retired here too, even when its INDIVIDUAL_ID already has a
    -- CUST_NUM (previously silently dropped, since cte_ext_num only looks at cnxi_new_ind).
    CREATE OR REPLACE TEMPORARY TABLE STANDARDIZE_STAGE.cnxi_unused_external_cust_num AS
    SELECT
        val.CUST_NUM                   AS INDIVIDUAL_ID
    ,   val.CUST_NUM                   AS CUST_NUM
    ,   'unused_external_cust_num'     AS REC_TYPE
    ,   val.FEED_INSTANCE_ID
    FROM
    (
        SELECT
            TRY_CAST( pp.SOURCE_SYSTEM_PK_1 AS NUMBER(38,0) )   AS CUST_NUM
        ,   MAX(pp.UPDATE_FEED_INSTANCE_ID)                      AS FEED_INSTANCE_ID
        FROM STANDARDIZE_CORE.PARTY_PROFILE AS pp
        WHERE
            pp.SOR_NAME IN ( 'ICON', 'MAO' )
        AND TRY_CAST( pp.SOURCE_SYSTEM_PK_1 AS NUMBER(38,0) )     BETWEEN  1
                                                                 AND 999999999
        AND TRY_CAST( pp.SOURCE_SYSTEM_PK_1 AS NUMBER(38,0) ) NOT BETWEEN  500000000
                                                                 AND 599999999
        GROUP BY TRY_CAST( pp.SOURCE_SYSTEM_PK_1 AS NUMBER(38,0) )
    ) val
    WHERE
        NOT EXISTS
        (
                SELECT 1
                FROM STANDARDIZE_STAGE.cnxi_taken k
                WHERE k.VAL = val.CUST_NUM
        )
    AND NOT EXISTS
        (
                SELECT 1
                FROM STANDARDIZE_STAGE.cnxi_new_external_cust_num new_ext
                WHERE new_ext.CUST_NUM = val.CUST_NUM
        )
    AND NOT EXISTS
        (
                SELECT 1
                FROM STANDARDIZE_STAGE.cnxi_merged_external_cust_num merged_ext
                WHERE merged_ext.CUST_NUM = val.CUST_NUM
        )
    AND NOT EXISTS
        (
                SELECT 1
                FROM STANDARDIZE_STAGE.cnxi_nonactive_external_cust_num na_ext
                WHERE na_ext.CUST_NUM = val.CUST_NUM
        )
    AND NOT EXISTS               -- a fake reservation INDIVIDUAL_ID must never collide with a real one
        (
                SELECT 1
                FROM STANDARDIZE_STAGE.cnxi_new_ind new_ind
                WHERE new_ind.INDIVIDUAL_ID = val.CUST_NUM
        )
    ;


    -- These are new CDP-generated CUST_NUM values
    CREATE OR REPLACE TEMPORARY TABLE STANDARDIZE_STAGE.cnxi_new_cdp_cust_num AS
    SELECT
        new_ind.INDIVIDUAL_ID
    ,   ROW_NUMBER() 
        OVER ( 
            ORDER BY new_ind.INDIVIDUAL_ID
        ) + max_id.SEED                     AS CUST_NUM
    ,   'new_cdp_cust_num'                  AS REC_TYPE
    ,   new_ind.FEED_INSTANCE_ID
    FROM  STANDARDIZE_STAGE.cnxi_new_ind AS new_ind
      ,   STANDARDIZE_STAGE.cnxi_maxid   AS max_id
    WHERE NOT EXISTS             -- NOT IN would go blind on a single NULL INDIVIDUAL_ID
    (
        SELECT 1
        FROM STANDARDIZE_STAGE.cnxi_new_external_cust_num new_ext
        WHERE new_ext.INDIVIDUAL_ID = new_ind.INDIVIDUAL_ID
    )
    ;


    IF ( ( SELECT SEED FROM STANDARDIZE_STAGE.cnxi_maxid ) + ( SELECT COUNT(1) FROM STANDARDIZE_STAGE.cnxi_new_cdp_cust_num ) > 599999999 ) THEN
        RAISE ex_cust_num_range_exhausted;
    END IF;

    
    CREATE OR REPLACE TEMPORARY TABLE STANDARDIZE_STAGE.CUST_NUM_INDIVIDUAL_XREF
    (
        INDIVIDUAL_ID           NUMBER(38,0)
    ,   CUST_NUM                NUMBER(38,0)
    ,   REC_TYPE                VARCHAR(50)
    ,   CREATE_DATE             TIMESTAMP_NTZ
    ,   CREATE_FEED_INSTANCE_ID NUMBER(38,0)
    )
    ;


    INSERT INTO STANDARDIZE_STAGE.CUST_NUM_INDIVIDUAL_XREF ( INDIVIDUAL_ID, CUST_NUM, REC_TYPE, CREATE_DATE, CREATE_FEED_INSTANCE_ID )
    SELECT
        INDIVIDUAL_ID
    ,   CUST_NUM
    ,   REC_TYPE
    ,   CURRENT_TIMESTAMP   AS CREATE_DATE
    ,   FEED_INSTANCE_ID
    FROM
    (
        SELECT INDIVIDUAL_ID, CUST_NUM, REC_TYPE, FEED_INSTANCE_ID
        FROM STANDARDIZE_STAGE.cnxi_new_external_cust_num

        UNION

        SELECT INDIVIDUAL_ID, CUST_NUM, REC_TYPE, FEED_INSTANCE_ID
        FROM STANDARDIZE_STAGE.cnxi_merged_external_cust_num

        UNION

        SELECT INDIVIDUAL_ID, CUST_NUM, REC_TYPE, FEED_INSTANCE_ID
        FROM STANDARDIZE_STAGE.cnxi_nonactive_external_cust_num

        UNION

        SELECT INDIVIDUAL_ID, CUST_NUM, REC_TYPE, FEED_INSTANCE_ID
        FROM STANDARDIZE_STAGE.cnxi_unused_external_cust_num

        UNION

        SELECT INDIVIDUAL_ID, CUST_NUM, REC_TYPE, FEED_INSTANCE_ID
        FROM STANDARDIZE_STAGE.cnxi_new_cdp_cust_num
    ) AS t
    ;


    IF ( EXISTS ( SELECT 1 FROM STANDARDIZE_STAGE.CUST_NUM_INDIVIDUAL_XREF GROUP BY CUST_NUM HAVING COUNT(1) > 1 ) ) THEN
        RAISE ex_duplicate_cust_num_02;
    END IF;

    IF ( EXISTS ( SELECT 1 FROM STANDARDIZE_STAGE.CUST_NUM_INDIVIDUAL_XREF GROUP BY INDIVIDUAL_ID HAVING COUNT(1) > 1 ) ) THEN
        RAISE ex_duplicate_ind_id_02;
    END IF;    


    IF ( EXISTS (
        SELECT 1
        FROM ( 
            SELECT CUST_NUM FROM STANDARDIZE_STAGE.CUST_NUM_INDIVIDUAL_XREF
            UNION ALL
            SELECT CUST_NUM FROM STANDARDIZE_CORE.CUST_NUM_INDIVIDUAL_XREF
        ) t
        GROUP BY CUST_NUM HAVING COUNT(1) > 1    
    ) ) THEN
        RAISE ex_duplicate_cust_num_03;
    END IF;
    

    IF ( EXISTS (
        SELECT 1
        FROM ( 
            SELECT INDIVIDUAL_ID FROM STANDARDIZE_STAGE.CUST_NUM_INDIVIDUAL_XREF
            UNION ALL
            SELECT INDIVIDUAL_ID FROM STANDARDIZE_CORE.CUST_NUM_INDIVIDUAL_XREF
        ) t
        GROUP BY INDIVIDUAL_ID HAVING COUNT(1) > 1    
    ) ) THEN
        RAISE ex_duplicate_ind_id_03;
    END IF;


    IF ( EXISTS (
        SELECT 1
        FROM STANDARDIZE_STAGE.CUST_NUM_INDIVIDUAL_XREF
        WHERE CUST_NUM NOT BETWEEN 500000000 AND 599999999
        AND REC_TYPE = 'new_cdp_cust_num'
    ) ) THEN
        RAISE ex_cust_num_out_of_range;
    END IF;


    IF ( EXISTS (
        SELECT 1
        FROM STANDARDIZE_STAGE.CUST_NUM_INDIVIDUAL_XREF x
        JOIN STANDARDIZE_STAGE.cnxi_nonactive_cust_num na ON na.CUST_NUM = x.CUST_NUM
        WHERE x.REC_TYPE = 'new_external_cust_num'
    ) ) THEN
        RAISE ex_nonactive_cust_num_used;
    END IF;


    -- CDP-1029 BR-1 completeness: every in-range ICON/MAO PK1 must end up either already in the
    -- core XREF or in this run's staged rows; anything missing was left unreserved.
    IF ( EXISTS (
        SELECT TRY_CAST( pp.SOURCE_SYSTEM_PK_1 AS NUMBER(38,0) ) AS CUST_NUM
        FROM STANDARDIZE_CORE.PARTY_PROFILE pp
        WHERE
            pp.SOR_NAME IN ( 'ICON', 'MAO' )
        AND TRY_CAST( pp.SOURCE_SYSTEM_PK_1 AS NUMBER(38,0) )     BETWEEN  1
                                                                 AND 999999999
        AND TRY_CAST( pp.SOURCE_SYSTEM_PK_1 AS NUMBER(38,0) ) NOT BETWEEN  500000000
                                                                 AND 599999999
        MINUS
        (
            SELECT CUST_NUM FROM STANDARDIZE_CORE.CUST_NUM_INDIVIDUAL_XREF
            UNION
            SELECT CUST_NUM FROM STANDARDIZE_STAGE.CUST_NUM_INDIVIDUAL_XREF
        )
    ) ) THEN
        RAISE ex_unreserved_external_cust_num;
    END IF;


    -- CDP-1029: staged rows the old OR-join MERGE would silently skip are captured here instead
    -- of vanishing (an individual could otherwise end up with no CUST_NUM and no error).
    -- Same-column checks (individual_id vs individual_id, cust_num vs cust_num), so they probe
    -- cnxi_taken WITH the provenance flag -- a bare k.VAL match would merge the two key spaces
    -- and no longer be the exact complement of the insert filter below.
    -- Written as two hash left-joins rather than  EXISTS(..) OR EXISTS(..) , which Snowflake
    -- cannot reliably decorrelate into semi-joins when the two are combined with OR.
    CREATE OR REPLACE TEMPORARY TABLE STANDARDIZE_STAGE.cnxi_insert_rejects AS
    SELECT
        src.INDIVIDUAL_ID
    ,   src.CUST_NUM
    ,   src.REC_TYPE
    ,   src.CREATE_DATE
    ,   src.CREATE_FEED_INSTANCE_ID
    ,   CASE WHEN ind_hit.VAL IS NOT NULL
             THEN 'individual_id_exists'
             ELSE 'cust_num_exists' END AS REJECT_REASON
    FROM STANDARDIZE_STAGE.CUST_NUM_INDIVIDUAL_XREF src
    LEFT JOIN STANDARDIZE_STAGE.cnxi_taken ind_hit
        ON  ind_hit.VAL              = IFNULL(src.INDIVIDUAL_ID,0)
        AND ind_hit.IS_INDIVIDUAL_ID = 1
    LEFT JOIN STANDARDIZE_STAGE.cnxi_taken cn_hit
        ON  cn_hit.VAL         = IFNULL(src.CUST_NUM,0)
        AND cn_hit.IS_CUST_NUM = 1
    WHERE
        ind_hit.VAL IS NOT NULL
    OR  cn_hit.VAL  IS NOT NULL
    ;

    -- DO NOT INSERT IF what_if

    IF NOT what_if THEN
        -- Equivalent to the prior MERGE ... WHEN NOT MATCHED (De Morgan on the OR-join predicate),
        -- rewritten as two anti-joins so Snowflake can hash rather than nested-loop the match.
        -- Probes the same cnxi_taken snapshot as cnxi_insert_rejects above, with the same
        -- provenance flags, so "inserted" and "rejected" remain exact complements by construction.
        INSERT INTO STANDARDIZE_CORE.CUST_NUM_INDIVIDUAL_XREF ( INDIVIDUAL_ID, CUST_NUM, REC_TYPE, CREATE_DATE, CREATE_FEED_INSTANCE_ID )
        SELECT
            src.INDIVIDUAL_ID
        ,   src.CUST_NUM
        ,   src.REC_TYPE
        ,   src.CREATE_DATE
        ,   src.CREATE_FEED_INSTANCE_ID
        FROM STANDARDIZE_STAGE.CUST_NUM_INDIVIDUAL_XREF src
        WHERE
            NOT EXISTS
            (
                SELECT 1 FROM STANDARDIZE_STAGE.cnxi_taken k
                WHERE k.VAL = IFNULL(src.INDIVIDUAL_ID,0) AND k.IS_INDIVIDUAL_ID = 1
            )
        AND NOT EXISTS
            (
                SELECT 1 FROM STANDARDIZE_STAGE.cnxi_taken k
                WHERE k.VAL = IFNULL(src.CUST_NUM,0) AND k.IS_CUST_NUM = 1
            )
        ;
    END IF;
    COMMIT;

    RETURN 'SUCCESS';

EXCEPTION
    WHEN OTHER THEN
    
        ROLLBACK;
        
        CREATE OR REPLACE TEMPORARY TABLE STANDARDIZE_STAGE.cnxi_new_ind_debug AS
        SELECT DISTINCT INDIVIDUAL_ID FROM STANDARDIZE_CORE.PARTY_PROFILE
        EXCEPT
        SELECT INDIVIDUAL_ID FROM STANDARDIZE_CORE.CUST_NUM_INDIVIDUAL_XREF
        ;
        
        RAISE;
END;
