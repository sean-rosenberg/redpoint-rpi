from pathlib import Path
import hashlib, json, difflib
root = Path.cwd()
base = root / 'docs/GENERATE_CUST_NUMS'
backup = Path(__file__).resolve().parent
names = ['implementation-plan.md', 'README.md', 'plan-refactoring.md', 'Reviews/CR1.md', 'REPORTING.md']
def initialize():
    manifest = {'sqlBefore': {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'dw').rglob('*.sql')}}
    for name in names:
        target = backup/'docs/GENERATE_CUST_NUMS'/name
        target.parent.mkdir(parents=True, exist_ok=True)
        assert not target.exists(), target
        target.write_bytes((base/name).read_bytes())
    (backup/'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
class Doc:
    def __init__(self, name):
        self.name = name
        self.original = (base/name).read_bytes()
        self.text = self.original.decode('utf-8-sig').replace('\r\n','\n')
    def replace(self, old, new):
        assert self.text.count(old) == 1, (self.name, old[:100], self.text.count(old))
        self.text = self.text.replace(old, new, 1)
    def before(self, anchor, addition):
        self.replace(anchor, addition+'\n\n'+anchor)
    def paragraph(self, prefix, replacement):
        matches = [line for line in self.text.splitlines() if line.startswith(prefix)]
        assert len(matches) == 1, (self.name, prefix, len(matches))
        self.replace(matches[0], replacement)
    def save(self):
        data = self.text.replace('\n','\r\n' if b'\r\n' in self.original else '\n').encode('utf-8')
        if self.original.startswith(b'\xef\xbb\xbf'): data = b'\xef\xbb\xbf'+data
        (base/self.name).write_bytes(data)
        print('Updated '+self.name)
def finish():
    manifest = json.loads((backup/'manifest.json').read_text())
    actual = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'dw').rglob('*.sql')}
    assert actual == manifest['sqlBefore'], 'SQL files changed'
    manifest['documents'] = {}
    diffs=[]
    for name in names:
        old=(backup/'docs/GENERATE_CUST_NUMS'/name).read_bytes()
        new=(base/name).read_bytes()
        manifest['documents'][name]={'before':hashlib.sha256(old).hexdigest(),'after':hashlib.sha256(new).hexdigest()}
        diffs.extend(difflib.unified_diff(old.decode('utf-8-sig').splitlines(True),new.decode('utf-8-sig').splitlines(True),fromfile='before/'+name,tofile='after/'+name))
    (backup/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    (backup/'changes.diff').write_text(''.join(diffs),encoding='utf-8')
    print(f'Preserved {len(actual)} SQL files; backup and diff: {backup}')
