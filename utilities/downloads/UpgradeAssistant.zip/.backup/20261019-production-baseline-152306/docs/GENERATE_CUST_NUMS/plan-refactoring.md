# GENERATE_CUST_NUMS — Simplification and Decomposition Assessment

Assessment date: October 15, 2026 (America/Chicago). Updated October 19, 2026 for F01–F04, F09, and F11 planning decisions, the F07 fallback reversal, and the F10/F12 reporting and error-handling contracts; the October 16 individual-ID contract and business decisions remain applicable.

Source assessed: `GENERATE_CUST_NUMS.sql`, 495 lines, 20,760 bytes. SHA-256: `f935962f00bda9975225324224565c9ae7b858db7f53b8a16136ee29e71d47f4`.

Companion documents: [Business assessment](README.md) and [Code review](Reviews/CR1.md). Finding IDs below refer to that code review. This is a proposed design and migration assessment; no source SQL or database objects were changed.

## Recommendation

Refactor around four responsibilities: **prepare a stable input context, build an assignment/reservation plan, validate that plan, and apply it**. Keep the processing set-based. Use a small public coordinator and a few private routines with explicit relation contracts; do not create one procedure per current temporary table or process each individual in a procedural loop.

The target must implement the [recorded business decisions](README.md#recorded-business-decisions): authoritative `NON_ACTIVE` blocking across individuals and ICON/MAO, source-ID preflight validation, a new CORE reservation table, original dual-ranking external selection without fallback, explicit lowest priority for null dates, exclusion of reserved `500000000`, retirement of unused eligible PK1s after successful processing, and success only when execution and all required checks pass. Removing synthetic reservation rows from the target XREF model is now required. The disjoint ID ranges still mean this is a model decision rather than a collision fix for conforming data. Structural parity work is an intermediate checkpoint, not completion of the approved behavior changes.

The design must distinguish three things that the current code mixes:

- A real individual receiving a customer number.
- A customer number being made unavailable without a real assignment.
- A proposed result becoming a committed, auditable outcome.

CDP-generated real `INDIVIDUAL_ID` values are **100,000,000,000–199,999,999,999 inclusive**; see the [business assessment](README.md#number-domains). This domain is disjoint from every valid customer number and synthetic reservation ID. Assignable generated `CUST_NUM` values are `500,000,001–599,999,999`; `500,000,000` is explicitly reserved and never assigned, as explained in the business assessment's footnote. F04/F05 remain conditional invalid/legacy-data findings. Require a preflight check on `PARTY_PROFILE.INDIVIDUAL_ID`; historical XREF classification and migration checks are separate from that source check.

## Recorded decisions and remaining design constraints

| Decision | Current behavior | Refactoring constraint |
| --- | --- | --- |
| Non-active status encoding and scope | Only `'-'` is blocked, despite comments referring to `NON_ACTIVE`. Blocking is global by numeric value. | `NON_ACTIVE` is authoritative. Any qualifying ICON/MAO occurrence prevents all new assignments of the value across individuals and sources. Only exact `NON_ACTIVE` is excluded; NULL, empty strings, whitespace, hyphens, case variants, and every other string pass the status rule, subject to other eligibility rules and global blocking. Do not trim, case-fold, or impose a status whitelist. |
| Occupied-number meaning | External eligibility considers both key columns; completeness only customer numbers. | These agree for conforming real assignments and reservations. Fail preflight on unresolved CORE integrity violations (F04); handle remediation separately and retain customer-number coverage. |
| Reservation identity | Customer number is copied into `INDIVIDUAL_ID`. | Create a new reservation table in `STANDARDIZE_CORE`; keep genuine assignments in XREF. Migration must classify legacy rows by record type and evidence (F05). |
| External conflict policy | Both independently calculated ranks must be 1; there is no fallback. | Retain this selection rule. The October 19 F07 reversal supersedes the earlier fallback approval. Require eligibility and both ranks equal to 1; do not retry, rerank, or rebalance. Generate numbers for new individuals without selected external assignments, then finalize eligible unassigned-number reservations. |
| Missing/invalid values | Null individual IDs are not explicitly rejected; unknown status is not blocked; numeric strings are cast. | Require source-ID preflight across the retained input population, rejecting null, non-integer, or out-of-range IDs. PK1 must be an unsigned decimal integer with successful conversion and eligible range; only exact `NON_ACTIVE` is excluded by status, and every other value is eligible under that rule. |
| Missing source dates | Date sorting has no explicit null placement. | Use `NULLS LAST` in preference and ownership date ordering. |
| Allocation floor | First generated number is 500000001; range validation includes 500000000. | `500000000` is reserved and never assigned. Enforce `500000001–599999999`; see the README footnote about the original omission. |
| Retirement | Unassigned external values are persisted as synthetic XREF rows. | An eligible PK1 left unassigned after successful processing becomes ineligible for future assignment. Persist this in the new reservation table after dual-ranking selection completes. |
| Success | The block returns the same `SUCCESS` text for preview/live and does not fail solely on nonempty rejects. | Require an error-free run with no failed preflight or self-checks; report preview/live mode and reconcile live writes. |
| Existing assignments later found non-active | Remain untouched. | Any revocation or remediation is a separate business change. |
| Multiple writers | This block provides no serialization. | Serialize generation instances with a lock on `STANDARDIZE_AUDIT.CUST_NUM_PROCESS`; writers outside generation are an accepted risk. |

The recorded decisions settle the target behavior above. Status eligibility and original selection without fallback are settled. D03.1 also settles lifetime: committed `NON_ACTIVE` reservations remain permanent after source correction, status change, or removal, with no automatic or built-in administrative release path. Exceptional remediation remains separate. D03.2 settles reason categories/precedence: retain the three original values and branch rules. D03.3 settles existing-reservation handling: original reason and creation/feed/run metadata remain unchanged. D03.4 settles the table and separates creation audit from selected-source attribution. D03.5 settles migrated creation audit: preserve the verified original timestamp and reconstruct the historical generation invocation from evidence. No D03 policy questions remain. Remaining design work includes generated-allocation recovery and lock implementation/verification; migration implementation and evidence reconciliation remain required. These details must not reopen the settled requirement to use a separate reservation table or the F07 decision to retain original dual-ranking selection.

## Proposed decomposition

Names and interfaces below are illustrative contracts, not compiled Snowflake SQL.

| Component | Responsibility and inputs | Outputs | Side effects and ownership |
| --- | --- | --- | --- |
| `GENERATE_CUST_NUMS` | Accept explicit preview mode; create/reuse a run ID; coordinate stages and failure reporting. | Structured run result. | Public interface and sole transaction owner; acquires the process-table lock before preparation and closes its own transaction. |
| `SP_CN_PREPARE_CONTEXT` | Read the agreed source population and core baseline; validate required input fields; normalize external numbers and classify status by exact exclusion once. | Profile snapshot, core baseline/occupied keys, context metadata, input issues. | Populates predeployed permanent staging tables under the coordinator lock. No core writes or DDL. |
| `SP_CN_BUILD_PLAN` | Apply approved external ranking, reservation classification, and generated-number planning. | Proposed real assignments and proposed reservations, with reasons and lineage. | Writes work relations only. No commits, core writes, or allocator advancement. |
| `SP_CN_VALIDATE_PLAN` | Evaluate explicit invariants over the plan and baseline. | Validation issues and metrics; zero fatal issues required to apply. | Reads prepared relations. Can populate a precreated work issue table; no DDL or transaction control when used inside apply. |
| `SP_CN_APPLY_PLAN` | Validate plan freshness under the writer contract, finalize generated allocation, insert persistent results, reconcile counts. | Committed counts and allocation information. | Participates in the coordinator-owned transaction. No helper may perform DDL or transaction control. |

`SP_CN_BUILD_PLAN` should initially contain named CTEs for candidate ranking and reservation classification. Extract another procedure only when it has an independently useful contract or operational boundary. A helper that merely hides three lines of SQL adds indirection without reducing complexity.

For a smaller deployment footprint, prepare/build/validate can remain clearly separated sections of one Snowflake Scripting procedure. The essential design is the responsibility and data separation; private stored procedures are useful when the deployment and testing setup supports them.

### Control flow

```mermaid
flowchart TD
    Z[Begin transaction and acquire process-table lock] --> A[Prepare source and core context]
    A --> B[Plan real assignments]
    B --> C[Complete dual-ranking selection then plan unused reservations]
    C --> D[Validate plan and reconcile counts]
    D --> E{Fatal issues?}
    E -->|Yes| F[Rollback then record failure]
    E -->|No| G{Preview mode?}
    G -->|Yes| H[Rollback business transaction and report preview]
    G -->|No| I[Apply under writer control]
    I --> J[Commit and return applied outcome]
```

Every generation invocation, including preview, acquires the same process-table lock before preparing source/core context. The coordinator holds one DML-only transaction through planning, validation, and live commit or preview rollback. Permanent staging is deployed beforehand, so preparation performs no DDL. This replaces the earlier short apply-only transaction proposal. See the F01–F03 deliverables below.

## Work relation contracts

Make each relation's grain explicit. This is more useful than exposing a long list of similarly named temporary tables.

| Relation | Grain | Essential fields and invariant |
| --- | --- | --- |
| Run context | One row per run | Run ID, preview flag, input cutoff/identity, captured time, seed, upper bound, rule version. |
| Profile snapshot | One retained source profile row | Raw individual ID, SOR, PK1, status, date, feed; parsed number; validation/classification fields; source record key when available. Include all SORs needed for individual discovery and rows for already-mapped individuals/external coverage. Retain invalid IDs until preflight reports them; never filter them away before checking. |
| Assignment baseline | One existing genuine XREF assignment | Individual ID, customer number, available lineage; used consistently for discovery, occupancy, and comparison. Classify legacy synthetic rows during migration. |
| Reservation baseline | One existing CORE reservation | Customer number, reason, available evidence; used to prevent future assignment of retired values. |
| Occupied numbers | One unavailable customer number | Derive from assigned customer numbers and CORE reservations, retaining disposition and evidence. Legacy comparison may retain both-key flags until migration is reconciled. |
| External number facts | One in-range external number | Global blocked-status flag and appropriate feed attribution, derived from the same profile snapshot. |
| Planned assignments | One real individual | Proposed customer number, external/generated origin, feed, selected-source evidence, run ID. |
| Planned reservations | One reserved customer number | Reservation reason, feed/evidence, run ID; no fabricated individual ID. |
| Validation issues | One failed or unexecuted required check in the run report | Stable check ID, status, and affected count under [REPORTING.md](REPORTING.md); persisted rule-specific samples are out of scope. |

These are logical relations, not a requirement to materialize one table per relation. Materialize only populations reused by several statements or needed for debugging; use CTEs for single-use transformations. A view alone does not freeze the source. Benchmark the choice with actual query profiles.

Every materialized work relation must use a predeployed permanent table in `STANDARDIZE_STAGE`, keyed by `RUN_ID`, which equals `FEED_INSTANCE_ID`. Each retry has distinct `AUTOMATION_GUID`, `FEED_INSTANCE_ID`, and `CUST_NUM_PROCESS_LOG_ID` values; no correlation between retry attempts is required. Temporary/transient work tables are not the selected design. Scope every read, join, write, and final cleanup to the run; D05.2 startup truncation of dedicated work tables after gate acquisition is the explicit exception. Verify object resolution and privileges. Stage rows written within a rolled-back transaction are not durable failure evidence. Capture the original error code, state, message, and stage before diagnostic work, if any; preserve compact failure reporting separately after rollback under [REPORTING.md](REPORTING.md). Persisted bounded, rule-specific samples are out of scope. The existing harness captures the runtime SQL error; harness changes are out of scope.

**D05.2 decision (October 19, option A with defensive startup truncate):** Retain no successful-run staging rows. Immediately after acquiring the shared generation lock, and before source capture or populating work tables, `TRUNCATE TABLE` each explicitly inventoried, predeployed work table dedicated to this procedure. This startup cleanup intentionally removes stale rows across all run IDs; it is the sole exception to run-scoped staging DML. Never truncate source, CORE assignment/reservation, process control, or audit/reporting tables. Perform the truncates in the coordinator transaction while holding the gate; no early commit or unlocked cleanup. All generation modes use this ordering. After live validation/apply reconciliation, capture required report values in procedure state and delete the current run's work rows before commit. Cleanup failure fails the invocation and rolls back its transaction. Preview/failure rollback undoes both startup truncation and new staging writes, so pre-existing stale rows can reappear; do not promise durable cleanup after rollback. No staging-retention period or scheduled cleanup job is required. Durable reporting remains separate.

**D05.3 decision (October 19, option A):** Require no open caller transaction when invoking generation, for live and preview alike. The caller must finish its transaction before the call; the coordinator begins and completes its own business transaction. Reject an invocation with an already-open caller transaction before acquiring the generation gate, truncating work tables, preparing source data, or applying business writes. Never commit or roll back caller-owned work to satisfy this precondition. Preserve the error through the existing harness; any reporting of rejected entry must use the D07 independent logging contract without modifying the caller transaction. Verify entry detection and rejection with the actual wrapper and harness. The AUTOCOMMIT requirement is settled separately under D05.4; D05.3 does not replace the separate D07 audit transaction design.

**D05.4 decision (October 19, option A):** Require the caller session to have `AUTOCOMMIT = TRUE` before invoking generation, for live and preview alike, in addition to D05.3's no-open-caller-transaction requirement. `AUTOCOMMIT = FALSE` is unsupported and must not proceed into generation work. The coordinator still explicitly begins and completes its business transaction; enabled autocommit does not make the statements inside that transaction commit individually. Do not enable or change AUTOCOMMIT inside the procedure or commit caller-owned work to satisfy the contract. Verify configuration and enforcement using the selected execution-rights model and actual harness during M0; do not assume session-inspection commands are available under every rights mode. The setting does not replace the separate D07 durable-logging design.

**D05.5 decision (October 19, option A):** Retain `EXECUTE AS OWNER` for the public generation procedure, matching the supplied `GENERATE_CUST_NUMS.prod.sql` wrapper. Use the procedure owner's privileges for underlying data operations; callers need the appropriate procedure, database/schema, and warehouse access, without requiring direct privileges on every underlying table. Record the actual owner role and required grants as deployment configuration. Verify D05.1 lock-wait enforcement, D05.3 caller-transaction rejection, D05.4 AUTOCOMMIT enforcement, and D07 logging under owner rights with the actual harness, including an authorized non-owner caller. Do not assume caller-session inspection or session changes are available under owner rights. The rights policy is settled; target-account verification and grants remain implementation/deployment work. Database/schema resolution is settled separately under D05.6.

**D05.6 decision (October 19, option A):** Resolve data objects relative to the database containing the deployed generation procedure, under settled `EXECUTE AS OWNER`. Keep explicit two-part `SCHEMA.OBJECT` references, using `STANDARDIZE_CORE`, `STANDARDIZE_STAGE`, and `STANDARDIZE_AUDIT` in that same database. Apply this convention to source/target tables, work-table truncation and cleanup, process control, process logging, and helper calls. Do not introduce caller-selected database routing or environment-specific database literals inside the procedure body. Deployment selects the environment database and installs the procedure and required objects there; callers can use a fully qualified procedure name to select the intended deployment. Verify calls made while the caller has a different current database/schema still use only the called procedure's environment. D05 policy is fully settled; actual environment names, grants, implementation, and target-account verification remain deployment/qualification work.

**D06.1 decision (October 19, option A):** The caller explicitly supplies the invocation's `FEED_INSTANCE_ID`, `AUTOMATION_GUID`, and a Boolean preview flag. TRUE means preview and FALSE means live. Use the existing harness-issued identifiers; generation creates neither identifier, does not derive them from source rows, and does not look up `FEED_INSTANCE` to obtain a missing automation identifier. `RUN_ID` remains exactly `FEED_INSTANCE_ID`. Require both identifiers and an explicit non-null mode before generation work; missing identity or mode must not fall through to live processing. Use the supplied invocation feed for generation audit fields under the existing provenance decisions. Verify parameter binding with the actual harness; this records the procedure input contract without changing the harness. Automation identifier width and caller return value are settled under D06.2 and D06.3.

**D06.2 decision (October 19, option C supplied by user):** Use `VARCHAR(36)` for the `AUTOMATION_GUID` procedure input contract and the new `CUST_NUM_PROCESS_LOG` column. The identifier is externally supplied and the user has verified this contract as correct; its width and external correctness are settled, not outstanding discovery or approval items. Preserve the supplied value without truncation, normalization, or regeneration. Do not add UUID-format validation or widen the new contract based on the existing audit tables' larger capacities. Leave existing `AUTOMATION_LOG` and `FEED_INSTANCE` definitions unchanged. Implementation verification covers parameter binding and unchanged propagation into reporting; it does not reopen the confirmed identifier contract.

**D06.3 decision (October 19, option A):** Preserve the VARCHAR return contract and return the exact string `SUCCESS` only when the requested invocation mode completes successfully, including every required validation and reporting operation. Successful preview, successful live apply, and successful zero-work processing use that same return value. It indicates execution success, not proof of committed business changes. Mode, validated counts, persistence state, and process-log ID remain in `STANDARDIZE_AUDIT.CUST_NUM_PROCESS_LOG`, located using the supplied `FEED_INSTANCE_ID`; do not add a structured response or return a log ID. Failures raise the appropriate SQL error through the existing harness, preserving the original error under F12. A post-commit reporting failure still raises an error while retaining the known business commitment; it must not return `SUCCESS` or trigger blind reapplication. No harness changes are required by this return decision. D06 policy is fully settled; parameter binding and behavioral verification remain implementation work.

**D07.1 decision (October 19, option A):** Use a dedicated logging procedure in `STANDARDIZE_AUDIT` for all writes to `CUST_NUM_PROCESS_LOG`. Pass scalar/JSON report values to the helper; it explicitly begins and completes its own audit-only scoped transaction. The generation coordinator remains the sole owner of its business transaction and retains the generation lock through planning, validation, apply, and commit/rollback. The helper accesses the process log only, not source/staging data, assignments, reservations, or the process control table; the coordinator's business transaction does not also write the log row. Preserve durable initialization, `IN_PROGRESS` immediately before live business writes while the gate is held, and confirmed completion/failure reporting. Initial/in-progress audit failure prevents apply; post-commit audit failure raises without claiming rollback or returning `SUCCESS`. Preserve the original error when rollback or secondary logging fails. D07 policy is settled; M0 must prove independent audit persistence, no early gate release or shared-object deadlock, and the existing failure behavior under the selected owner-rights/caller contract. No harness changes or external logging service are introduced.

**D08.1 decision (October 19, option A):** Update affected consumers for the separate assignment/reservation model as part of the controlled cutover. Consumers read genuine assignments from XREF and reservations from `STANDARDIZE_CORE.CUST_NUM_RESERVATION` where needed. Inventory actual consumers, update and verify those affected, and deploy their compatible versions with the migration before enabling generation callers. Do not introduce a temporary compatibility view that recreates legacy combined/synthetic rows or an independent dual-writing allocator. Consumer readiness is a cutover prerequisite; discovering the inventory and proving compatibility remain implementation work. Existing evidence-based classification, separate remediation, D03.5 reservation-audit reconstruction, and F04 unresolved-data blocking remain unchanged. D04.2 still requires no detection or response to lost generated-assignment history. D08 policy is settled; migration evidence, consumer changes, and cutover/recovery qualification remain pending.

## Simplification opportunities

| Existing construction | Proposed simplification | Behavior that must remain explicit |
| --- | --- | --- |
| Five separate successful-path reads of PARTY_PROFILE | Capture one source population, then derive rules from it. | Preserve all-history coverage represented in the current table; do not silently turn this into a feed-only delta. |
| Repeated `TRY_CAST` and numeric-range predicates | One normalization layer with raw value, parsed value, validity, and rejection reason. | Enforce the approved unsigned-integer grammar before external adoption; retain invalid PK1 rows for ID preflight/discovery. |
| Separate non-active candidate logic and repeated eligibility use | One per-number classification aggregated over the source snapshot. | Any qualifying `NON_ACTIVE` ICON/MAO occurrence blocks all new assignments of the value. |
| Correlated EXISTS in the candidate SELECT expression | Left join the unique blocked-number relation and derive an eligibility flag. | Preserve row cardinality and membership; resolve the compilation risk in F13 independently of status semantics. |
| Many `cnxi_*` tables encoding categories | Named CTEs plus two plan outputs: assignments and reservations. | The five legacy record types must remain explainable during migration. |
| Four separate paths for external selection/reservation | Preserve original dual-ranking assignments, then classify remaining values for reservation. | No fallback or rebalancing. Retire eligible values left unassigned after selection only as part of successful live processing. |
| Scattered `IF EXISTS` checks | A validation relation with stable rule IDs and summary counts. | Retain fail-fast behavior for fatal preconditions where further planning is unsafe. |
| `UNION` across all proposed branches | Explicitly prove disjoint branches, then consider `UNION ALL`. | Do not use distinct elimination to conceal branch overlap; retain `UNION` until equivalence is proven. |
| Literal `what_if` and string-only success | Explicit preview parameter and structured output. | Preview still validates but does not consume live allocation state. |
| Transaction spanning CTAS and apply | Predeploy permanent tables; begin the transaction and acquire the shared process lock before preparation. | Coordinator owns commit/rollback; no runtime DDL and no early lock release. |
| Generic exception debug extract | Compact run summary and failed/unexecuted-check reporting; no persisted rule-specific samples. | Capture and preserve the original error even if rollback or reporting fails; existing harness captures the runtime SQL error. |

A global mutable lookup view or a single enormous CTE is not automatically simpler. Favor a small number of stable, named concepts whose outputs can be inspected and compared.

## Target persistent model

### Separate assignments from number availability

The recorded decision requires a new reservation table in `STANDARDIZE_CORE`. XREF holds real assignments, and the reservation table holds unavailable numbers without fabricated individual IDs. D03.4 fixes the name as `STANDARDIZE_CORE.CUST_NUM_RESERVATION` and defines the six columns below. A combined register containing both assigned and reserved numbers is not required by this decision.

| Persistent object | Purpose | Suggested contract |
| --- | --- | --- |
| Individual/customer assignment | Real `INDIVIDUAL_ID → CUST_NUM` mappings | One assignment per real individual and per assigned customer number; no reservation-only rows. |
| CORE customer-number reservation table | Persist unavailable numbers without real assignments | `CUST_NUM`, `REC_TYPE`, `CREATE_DATE`, `CREATE_FEED_INSTANCE_ID` for the generation invocation, `ORIGINATING_FEED_INSTANCE_ID` for the selected source feed, and `SOURCE_PARTY_PROFILE_ID`. No redundant `RUN_ID`. |
| Run summary and issues | Explain what happened and why | Run ID, mode, status, counts, rule version, input identity, error information. |

Determine availability from the union of assigned XREF customer numbers and CORE reserved numbers, together with the current global blocked-number classification. An unused eligible number must remain unavailable after its reservation is committed, even if its source profile is later removed. Under settled D03.1, committed `NON_ACTIVE` reservations also remain permanently unavailable after status changes, source corrections, or profile removal. A `BLOCKED_BY_INDIVIDUAL_ID` reason is unnecessary for conforming CDP IDs; diagnose and reconcile invalid/legacy overlaps. Keep assignment and reservation counts separate, and prevent a new assignment from claiming a reserved number.

On Snowflake standard tables, PK/unique declarations alone do not enforce these guarantees. The apply path and writer policy must do so, or the design must deliberately use a suitable enforced-key mechanism. [R2]

**D03.2 decision (October 19, option A):** Retain the exact reservation reason values `nonactive_external_cust_num`, `merged_external_cust_num`, and `unused_external_cust_num`. For a new reservation, classify a qualifying exact `NON_ACTIVE` value as `nonactive_external_cust_num`; otherwise use `merged_external_cust_num` when the eligible candidate has `EXTERNAL_RANK > 1` and `CUST_NUM_RANK = 1`; otherwise use `unused_external_cust_num` for remaining valid, unoccupied external values not assigned or reserved by another branch. Exclude existing assignments/reservations and final new assignments before creating reservation rows. Each newly reserved number has one reason. The `merged` label does not establish a person merge or surviving-individual link. Preserve these exact values for validated legacy reservations during migration; F04 still blocks malformed or unclassified rows.

**D03.3 decision (October 19, option A):** Existing reservation rows are immutable during normal generation. Preserve the original reason, creation date, feed attribution, and any stored creation/run metadata. Later observations, including a new exact `NON_ACTIVE` occurrence, do not update the row, append another reservation for the same number, or release the number. The reason records why the number was first reserved, not its latest observed status. Reprocessing is insert-only for newly reserved numbers; exceptional data remediation remains separate.

**D03.4 decision (October 19):** Use `STANDARDIZE_CORE.CUST_NUM_RESERVATION` with `CUST_NUM`, `REC_TYPE`, `CREATE_DATE`, `CREATE_FEED_INSTANCE_ID`, `ORIGINATING_FEED_INSTANCE_ID`, and `SOURCE_PARTY_PROFILE_ID`. For new generation rows, `CREATE_DATE` is the reservation creation timestamp and `CREATE_FEED_INSTANCE_ID` is the generation invocation's `FEED_INSTANCE_ID`. Store the selected source row's feed in `ORIGINATING_FEED_INSTANCE_ID` and its source identifier in `SOURCE_PARTY_PROFILE_ID`. For duplicate qualifying sources, select the smallest `SOURCE_PARTY_PROFILE_ID` in string order using its existing VARCHAR type, not numeric order. Carry the originating feed and source identifier together from that selected row; do not combine independent aggregate values from different rows. No separate reservation `RUN_ID` is needed because the invocation is identified by `CREATE_FEED_INSTANCE_ID`; staging/reporting retain their existing run identity contract. D03.3 immutability applies to all six reservation fields.

Legacy `CREATE_FEED_INSTANCE_ID` is source attribution in the reviewed implementation, not proof of the generation invocation. Reconcile it explicitly during migration. D03.5 requires the verified original creation timestamp and evidence-based reconstruction of the historical generation invocation. Preserve supporting evidence; missing or ambiguous required lineage blocks migration acceptance/cutover until separately resolved.

**D03.5 decision (October 19, option B):** Reconstruct historical creation audit for migrated reservations. Preserve the verified original `CREATE_DATE` and populate `CREATE_FEED_INSTANCE_ID` with the actual historical generation invocation's `FEED_INSTANCE_ID`, recovered from supporting audit/history evidence. Do not replace these values with the migration timestamp or migration invocation ID. Do not treat the legacy source-attribution value as proof of the historical generation invocation. Populate `ORIGINATING_FEED_INSTANCE_ID` and `SOURCE_PARTY_PROFILE_ID` from verified source evidence under D03.4, preserving validated original reason values. Retain reconstruction evidence with the migration reconciliation. Missing or ambiguous required audit/source lineage blocks migration acceptance and cutover until separately resolved under F04/D08; do not fabricate values, silently skip unresolved reservations, or weaken the required fields. This settles D03 policy; reconstruction, implementation, and verification remain pending.

### Legacy record mapping

| Current record type | Target disposition | Migration caution |
| --- | --- | --- |
| `new_external_cust_num` | Real XREF assignment | Preserve the external-origin evidence. |
| `new_cdp_cust_num` | Real XREF assignment | Retain the genuine assignment in XREF; its number contributes to the D04.1 seed. |
| `merged_external_cust_num` | CORE reservation with reason `merged_external_cust_num` | Existing row does not preserve a reliable surviving-individual link. |
| `nonactive_external_cust_num` | CORE reservation with reason `nonactive_external_cust_num` | Preserve evidence; the old code checked `'-'`, so the record type alone does not prove a `NON_ACTIVE` occurrence. |
| `unused_external_cust_num` | CORE reservation with reason `unused_external_cust_num` | Preserve why the number was not assigned when evidence exists. |
| Missing/unknown `REC_TYPE` | Unclassified until reconciled | Equal keys cannot be a valid real assignment under the supplied ranges, but equality alone does not establish reservation reason or historical validity. Reconcile using provenance and domain checks. |

Under settled D08.1, identify actual consumers and update those affected to use genuine XREF assignments and separate CORE reservations at cutover. Verify their behavior before enabling callers; do not introduce a temporary compatibility view that recreates legacy synthetic rows. Do not drop legacy rows or rewrite historical identities based on the record shape alone.

## Allocation, transactions, and concurrency

### First implementation: serialized allocation from retained XREF

For the initial refactor, serialize generation instances using `STANDARDIZE_AUDIT.CUST_NUM_PROCESS` and retain deterministic generated-allocation ordering. D04.1 option B selects the greatest retained generated XREF number as the seed, floored at `500000000`; initial allocation is `500000001`. Add no separate allocation-state table, sequence, or process-row counter. Removing the greatest generated-assignment row can lower the seed and permit reuse. D04.2 is settled: do not detect or react to generated-assignment history loss, including known loss. Continue using the retained-XREF seed without a history-loss recovery gate. The permanent unused-PK1 retirement rule is enforced independently by the CORE reservation table.

Preview computes provisional values from a captured boundary without advancing it. A later live run can legitimately choose different values if intervening work consumed numbers. Do not present preview values as reservations.

A sequence is outside the selected D04.1 design. The process gate still supplies generation serialization; standard integrity, range, and capacity checks remain required.

### Apply boundary

Deploy all permanent staging tables and the process control table before invocation. The coordinator begins and ends its own transaction; helpers never control transactions. DDL is excluded from runtime paths. [R1]

1. Enforce D05.3/D05.4: require no open caller transaction and `AUTOCOMMIT = TRUE`, rejecting unsupported calls without committing or rolling back caller work or changing the caller setting. Begin the coordinator transaction and acquire the shared process-table lock using a real update of its preseeded control row. Require exactly one affected row; stop on acquisition failure or timeout.
2. After acquisition, truncate the inventoried dedicated work tables under D05.2 within the same transaction, then capture source input and read the committed target baseline/seed. Build and validate the run-scoped plan while retaining the lock.
3. For live mode, insert assignments and CORE reservations, reconcile required counts/checks, capture report values, and delete current-run staging rows before commit. Cleanup failure rolls back the transaction.
4. For preview, return provisional counts without business changes and roll back the planning transaction. Capture the result before rollback; persist permitted reporting afterward.
5. On failure, capture the original error code, state, message, and stage before diagnostic work, guard rollback, then report separately without replacing the original runtime SQL error. Persisted bounded, rule-specific samples and harness changes are out of scope. Never continue after a failed lock update. Commit/rollback releases the gate; no child scope may release it early.

A waiting invocation must prepare from fresh state after acquisition, not reuse a plan built before waiting. The shared gate serializes generation only. Nonparticipating writers may invalidate a check immediately afterward; this is the accepted external-writer risk, not a claim of universal writer exclusion.

### F01–F03 implementation deliverables

These are planned changes only. The findings remain open until implementation and acceptance evidence exist.

- **F01:** Centralize the settled exact-exclusion rule: only `PARTY_PROFILE_STATUS_CODE = 'NON_ACTIVE'` is excluded. NULL, empty strings, whitespace, hyphens, case variants, and every other string are eligible under the status rule. Do not trim, case-fold, or use a whitelist. All values remain subject to valid IDs/numbers, occupancy, reservations, and the global blocked-number rule. No status-policy question remains.
- **F02:** Add one DDL file for each required permanent staging table under `dw/STANDARDIZE_STAGE/Tables`. Inventory the current work tables below before selecting consolidations; each retained or newly materialized relation needs its own DDL, explicit columns/types, `RUN_ID`, deployment ordering, grants, and retention/cleanup contract. Single-use CTEs do not require DDL. Replace CTAS/table creation with explicit-column DML, including reject and exception paths. Do not reuse unrelated `CNX_01` as scratch storage.
- **F03:** Add `dw/STANDARDIZE_AUDIT/Tables/CUST_NUM_PROCESS.sql` to the implementation scope. Proposed columns are `PROCESS_NAME`, `LAST_RUN_ID`, and `LOCK_ACQUIRED_AT`; seed exactly one row for `GENERATE_CUST_NUMS` during deployment. Each invocation updates that same row with its run identity/time in the coordinator transaction. The database transaction lock is the gate; a committed flag or a read of the row is not lock acquisition. Validate row cardinality and actual blocking behavior; standard-table key declarations are insufficient by themselves. Under settled D05.1 (October 19, option A), allow up to 60 seconds to acquire the generation lock in live and preview; fail on timeout without unlocked fallback. This is a lock-acquisition limit, not a total execution limit; verify enforcement with the target account and caller. [R1, R2]

Current staging inventory (all names in `STANDARDIZE_STAGE`; filenames use the table name plus `.sql`):

| Existing work tables | Required planning treatment |
| --- | --- |
| `cnxi_maxid`, `cnxi_taken`, `cnxi_new_ind` | Seed, occupancy, and individual discovery; populate only after locking. |
| `cnxi_nonactive_cust_num`, `cnxi_external_cust_num` | Classification and candidates; incorporate F01. |
| `cnxi_new_external_cust_num`, `cnxi_merged_external_cust_num`, `cnxi_nonactive_external_cust_num`, `cnxi_unused_external_cust_num`, `cnxi_new_cdp_cust_num` | Assignment/reservation branches; preserve lineage if consolidated. |
| `CUST_NUM_INDIVIDUAL_XREF`, `cnxi_insert_rejects`, `cnxi_new_ind_debug` | Retain combined plan/reject relations only as needed; retire the generic exception debug extract without adding persisted rule-specific samples. No runtime creation on any path. |
| New profile snapshot, reservation baseline, and split plan/issue tables if materialized | One DDL file per chosen table; finalize names and types during implementation design. |

Deploy DDL and the control-row seed first, then procedure changes. Verify required objects/grants before enabling calls; do not create missing objects lazily. Final cleanup uses run-scoped DML; D05.2 startup truncation deliberately clears stale rows across run IDs after the shared gate is acquired. A waiting invocation cannot clean up the active invocation's work. Durable audit/reporting data is excluded from all staging cleanup. Preview rollback does not promise durable staging rows. No DDL files are created by this documentation-only plan.

### F09 and F11 prepared input and PK1 validation

After acquiring the F03 process lock, materialize the required `PARTY_PROFILE` columns once into a predeployed permanent staging table with `RUN_ID`. Preserve raw individual ID, source identity/SOR, PK1, status, source date, feed attribution, and available source-record keys. Include the rows needed for all individuals and external-number coverage, including already-mapped individuals and non-ICON/MAO sources needed for discovery. Do not reduce this to new individuals or external candidates only.

Run source-ID preflight against that captured population before excluding invalid IDs. A null, non-integer, or out-of-domain individual ID must remain visible and fail preflight, including on an already-mapped individual. Invalid PK1 does not remove its row from this check or from individual discovery.

Normalize PK1 and classify status once by exact exclusion in prepared relations, retaining raw values and diagnostic classifications. For PK1, require both the unsigned-integer pattern and successful conversion:

```sql
REGEXP_LIKE(SOURCE_SYSTEM_PK_1, '^\\s*\\d+\\s*$')
AND TRY_CAST(SOURCE_SYSTEM_PK_1 AS NUMBER(38,0)) IS NOT NULL
```

The doubled backslashes are Snowflake single-quoted SQL string escaping; the `*` operators are not escaped. See [REGEXP_LIKE](https://docs.snowflake.com/en/sql-reference/functions/regexp_like). Evaluate/store syntax validity and conversion once, then reuse the parsed value and validation result. Treat NULL validation results as invalid external input. Keep range and availability checks separate; `0` satisfies integer syntax but is outside eligible external ranges. Leading zeros map to the same numeric value. Preserve rejection reasons for syntax, conversion, and range failures.

Derive assignments, ranked external candidates, reservations, and source-based self-checks exclusively from these prepared relations. Do not reread `PARTY_PROFILE` downstream. Target integrity checks and apply reconciliation remain necessary under F03; the snapshot does not eliminate the accepted risk of outside writers. Record the population identity for the run. Any additional materialized relation follows F02: one permanent-table DDL file under `dw/STANDARDIZE_STAGE/Tables`, deployed before invocation.

F09 population scope and F11 unsigned-integer syntax are decided. These sections are implementation requirements, not SQL changes or live verification evidence.

## Explicit validation contracts

Keep rule IDs stable so tests, run reports, and operational alerts refer to the same conditions.

| Rule family | Required assertion |
| --- | --- |
| Input identity | Preflight every retained `PARTY_PROFILE.INDIVIDUAL_ID` in the input population, including already mapped individuals: non-null integer in `100000000000–199999999999`. Any failure stops the run before assignment planning. |
| Core integrity | Validate existing CORE before assignment planning or business writes. Fail the entire preview/live invocation on unresolved violations, including invalid real-assignment `INDIVIDUAL_ID`, malformed legacy reservations, unresolved null/unrecognized `REC_TYPE`, and uniqueness/required-field failures. Handle remediation separately; filtering or quarantine does not permit continuation. |
| Assignment coverage | Every required new real individual has exactly one proposed genuine assignment or an explicit fatal issue. |
| Assignment uniqueness | No two assignments claim the same customer number; no real individual receives multiple assignments. |
| Number disposition | Every in-scope external value has one approved disposition: already assigned, newly assigned, retired, or explicitly blocked under policy. |
| Category disjointness | A number cannot be both assigned and retired in one plan. Each new reservation has one exact original reason under D03.2 precedence: qualifying non-active, otherwise qualifying merged, otherwise unused. |
| Non-active policy | No new assignment uses a value having any qualifying `NON_ACTIVE` ICON/MAO occurrence across individuals and sources. Existing assignments are not retrospectively revoked by this decision. |
| External selection | Require eligibility and both original ranks equal to 1. Do not retry or rerank after a conflict. New individuals without selected external assignments receive generated numbers; finalize eligible unassigned-number reservations after selection. |
| Date priority | Null source dates have lowest priority under every session null-ordering setting. |
| Retirement | Every eligible PK1 left unassigned after successful live processing has a persistent CORE reservation and is excluded on future runs. |
| Generated range | Allocations are within `500000001–599999999`; `500000000` is never assigned. Use the greatest retained generated XREF number as the seed under D04.1; do not fill gaps below it. |
| Key-space policy | Real assignments use the supplied disjoint ID domain; legacy synthetic reservations use valid external numbers with equal keys. Fail preflight on unresolved out-of-contract rows; reconcile them separately before relying on occupancy/coverage equivalence. Do not automatically repair, delete, or reassign historical identities. |
| Apply reconciliation | Planned accepted rows equal committed rows; any skipped assignment has a fatal or explicitly approved outcome. |
| Preview | No persistent assignment, reservation, or allocation-state mutation occurs; output is clearly marked provisional. |
| Idempotency | Reprocessing unchanged committed input adds no duplicate assignments/reservations and consumes no unnecessary numbers. Existing reservations keep their original reason and creation/feed/run metadata even when later source observations change. |
| Success | Execution is error-free and every required preflight and self-check passes. Any failed check prevents success, including live count reconciliation. Report mode independently of success. |

Track counts separately: new individuals, external assignments, generated assignments, reservations by reason, validation failures, accepted rows, rejected rows, and inserted rows. Reservation count must never be mistaken for the number of customers served.

## Refactoring sequence and acceptance gates

### Phase 0 — Establish the baseline and decisions

Obtain the deployed procedure wrapper, source/target DDL, migration script, business story, caller behavior, and orchestration. Resolve the F13 compilation gate: replace or verify the correlated EXISTS projection, normalize the preview IF syntax, and compile with the actual wrapper/client. Record actual status encodings, compliance with the supplied real-ID range, legacy record types/reservation invariants, and source retention. Capture representative row counts and query profiles.

Create fixtures from the review's ten original cases and normal cases. Classify F04/F05 overlaps as invalid/legacy-data scenarios; add valid real-ID boundary and reservation-coexistence cases. Label each expected result as either **current behavior to preserve** or **approved correction**. This prevents a cleaner implementation from silently changing identity assignment.

**Exit gate:** Every high-severity finding has a decision, an explicit operating precondition, or a failing acceptance test assigned to the implementation scope. No production data changes are required for this phase.

### Phase 1 — Structural simplification and observability

Introduce a run ID, explicit preview mode, normalized source snapshot, named rule constants, and structured result. Separate preparation, planning, validation, and apply. Preserve dual-ranking order and legacy output semantics for comparison. A legacy output adapter can render reservations into the old shape for parity testing; it must expose out-of-contract identities or malformed reservations rather than hide them.

Deploy permanent staging DDL and the process control table/seed before calls. Add assignment/count reconciliation and coordinator-owned locking from preparation through completion. Guard exception diagnostics. Preserve original dual-ranking selection without fallback in all phases; avoid an indiscriminate `UNION ALL` replacement.

**Exit gate:** For unchanged approved rules, legacy and refactored previews agree on keys, record types, and feed attribution. D03.4 reservation audit/source fields are an approved correction with separate expected outcomes. Compare row multiplicity as well as sets so duplicate bugs are visible. Exclude expected clock differences such as creation timestamps. Intentional fixes have separate expected-result fixtures. Snowflake rollback and preview tests pass.

### Phase 2 — Correct the business-rule inconsistencies

Implement exact `NON_ACTIVE` global blocking with status eligibility for every other value, the required source-ID preflight, explicit `NULLS LAST`, original dual-ranking selection without fallback, and exclusion of reserved `500000000`. Add retirement of eligible PK1s left unassigned after successful processing and enforce the recorded success definition. Make coverage derive from the same classified source population as the plan. Implement the approved unsigned-integer PK1 rule; status eligibility is settled: only exact `NON_ACTIVE` is excluded. F07's earlier fallback change is superseded; verify original selection semantics with the other approved corrections and finalize reservations after selection.

**Exit gate:** All affected regression fixtures pass with the approved outcomes. Existing assignments remain unchanged unless a separately scoped remediation explicitly requires otherwise. The two-session concurrency tests demonstrate the selected writer/allocator guarantees.

### Phase 3 — Implement the required CORE reservation table

Create the new `STANDARDIZE_CORE` reservation table and migrate genuine assignments/reservations through deployment migrations. Add run reporting objects according to the completed design. D04.1 requires no separate allocation-state object or counter. Backfill reservations from verified record types and available history. Reconcile unknown legacy rows; never guess their meaning from equal numeric keys. Phases 2 and 3 must be integrated before claiming the recorded target behavior is complete; their separation is a review sequence, not permission to omit the reservation model.

Compare the new model in shadow/preview mode against the legacy interpretation. Under D08.1, inventory, update, and verify affected consumers against the separate assignment/reservation stores, then deploy their compatible versions and switch writers under a controlled cutover without a temporary compatibility view. Preserve a recovery path compatible with the new model and reconcile migration changes against the captured baseline. Under settled D04.2, do not detect or react to generated-assignment history loss, including known loss; reconstruction of that history is not a prerequisite for resuming generation. D03.5 reservation audit/source-lineage and F04 current-state integrity requirements remain applicable. Avoid independent dual-writing implementations with divergent business rules.

**Exit gate:** Every legacy row is classified and all CORE integrity violations are resolved through separately handled remediation before generation can proceed. Quarantine alone does not satisfy F04 preflight. All consumed numbers are accounted for, real assignments reconcile, consumers distinguish reservations, and cutover/recovery has been rehearsed.

### Phase 4 — Optimize using measurements

Measure the normalized snapshot and reduced work-table design against the baseline on realistic data. Remove redundant scans and materializations only where profiles show a benefit. Consider incremental maintenance of reservation evidence only when historical coverage, late arrivals, corrections, and the global non-active rule remain correct.

**Exit gate:** Correctness and provenance remain unchanged, with measured improvement in the chosen runtime/cost objectives. Avoid promising a speedup or a particular temporary-table count before profiling.

## Focused test matrix

| Area | Minimum scenarios |
| --- | --- |
| Status | Exact `NON_ACTIVE` blocks all new assignments of a qualifying value across individuals and ICON/MAO. NULL, empty/whitespace strings, hyphen, arbitrary strings, case variants, and padded variants pass the status rule. Verify each case without trimming/case folding, subject to other eligibility rules; none can override an exact `NON_ACTIVE` occurrence of the same numeric PK1. |
| External selection | Shared 101 with alternative 102: individual 7 wins 101, individual 8 receives a generated number, and 102 is reserved. Preserve both-rank eligibility with no fallback, reranking, or rebalancing; exercise multiple conflicts, duplicate/tied occurrences, and unchanged-input reruns. Known source dates outrank null dates regardless of session settings. |
| PK1 syntax and conversion | Accept digit strings and normalize leading zeros; reject signs, fractions, exponents, embedded spaces, empty strings, NULL, and overflow. Invalid PK1 cannot yield rounded assignments/reservations and does not remove a valid individual from generated-assignment eligibility. |
| Number domains | 0, 1, 499999999, 500000000, 599999999, 600000000, 999999999, 1000000000. Apply range restrictions separately from syntax/conversion; `0` passes syntax but is ineligible. |
| Prepared source population | Invalid IDs remain visible to preflight, including already-mapped individuals. Preserve external coverage on mapped individuals and other sources needed for discovery. Change source rows after capture and prove all downstream source-based decisions/checks use the prepared population; retain raw PK1/status diagnostics. |
| Real-ID domain and legacy exceptions | Accept `100000000000` and `199999999999`; reject `99999999999`, `200000000000`, null, zero, and fractional real IDs. Preserve valid `(42,42)` reservations alongside real ID `100000000042`. Treat the original F04/F05 overlaps as invalid/legacy data. Verify that unresolved CORE violations stop preview/live preflight without business writes, valid legacy reservations remain valid under their separate domain, and separately remediated data passes on a later invocation. |
| Allocation | Empty history starts at `500000001`; a proposed assignment of `500000000` fails. Internal gaps, exact remaining capacity, exhaustion, maximum historical row removed under the chosen recovery contract, preview followed by another live allocation. |
| Historical coverage | Eligible PK1 left unused after successful live processing is reserved and unavailable on later feeds, including after source removal. Include new numbers on already mapped individuals, late blocked occurrences, and unchanged-input reruns. |
| Reservation migration | Known synthetic record types move to CORE reservations without fabricated target individual IDs; real XREF assignments and unavailable values reconcile before/after cutover. Unknown legacy rows require classification. Under D03.5, preserve original creation timestamps and reconstruct actual historical generation invocation IDs from retained evidence. Missing/ambiguous required audit or source lineage blocks acceptance/cutover; migration audit values cannot substitute. |
| Persistence | Preview makes no allocation changes; injected failure before commit rolls back all persistent effects; durable failure reporting preserves original error. |
| Concurrency | Same individual, shared seed, competing external number, and preview/live overlap in two sessions. Prove B waits at the gate and reads fresh state after A commits; repeat after rollback. Verify timeout, missing/duplicate control row, error exit, and lock release. Document bypass writers as accepted-risk evidence. |
| Staging deployment and isolation | Every materialized table has a separate permanent-table DDL file; no runtime DDL including exception paths. Distinct run IDs cannot mix. Verify locked startup truncation of stale work rows, no waiting-run interference, empty work tables after successful live completion, and cleanup-failure rollback. Preview/failure rollback restores pre-existing stale rows; durable reporting is preserved separately. |
| Provenance and callers | D03.4 generation audit versus originating source feed; smallest qualifying source ID in string order (`'10'` before `'2'`); source feed and identifier from the same row; failure when required source lineage is unavailable. Also verify result mode/counts, deployed execution rights, and supported caller transaction settings. |
| Success | Every failed preflight/self-check or execution error prevents success; valid preview and live runs report their mode. Zero-work runs may succeed when error-free and all checks pass. |

## Effort and completion criteria

Structural extraction is moderate effort: the SQL is already set-based, and its work tables expose useful boundaries. Policy correction and persistent-model migration are the larger work because they affect identity guarantees and consumers. A reliable calendar estimate requires the missing wrapper, schemas, data volumes, test environment, and consumer inventory.

The refactor is complete when its public routine is short enough to show the workflow clearly, each rule has one implementation and a testable contract, assignment and reservation counts reconcile, apply has a proven transaction/writer boundary, and an operator can explain every proposed or committed number from the run's evidence. Shorter SQL alone is not an adequate acceptance criterion.

## Platform references

- **[R1]** [Snowflake transactions](https://docs.snowflake.com/en/sql-reference/transactions): DDL and transaction-scope constraints underlying the apply design.
- **[R2]** [Overview of constraints](https://docs.snowflake.com/en/sql-reference/constraints-overview): why standard-table uniqueness must not be assumed enforced.
- [Snowflake temporary tables](https://docs.snowflake.com/en/user-guide/tables-temp-transient): relevant to session work relations and diagnostic lifetime.
