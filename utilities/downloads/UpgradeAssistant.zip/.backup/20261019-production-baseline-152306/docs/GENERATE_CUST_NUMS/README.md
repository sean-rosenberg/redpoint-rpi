# GENERATE_CUST_NUMS — Business Purpose, Rules, and Processing Flow

Assessment date: October 15, 2026 (America/Chicago). Updated October 19, 2026 with F01–F03, F09, and F11 planning decisions; the October 16 individual-ID range and business decisions remain applicable.

Source: `GENERATE_CUST_NUMS.sql`, 495 lines, 20,760 bytes. SHA-256: `f935962f00bda9975225324224565c9ae7b858db7f53b8a16136ee29e71d47f4`. Line references below refer to this exact source. The supplied file is a Snowflake Scripting block beginning with `DECLARE`; the deployed `CREATE PROCEDURE` definition was not supplied.

Companion documents: [Code review](Reviews/CR1.md) and [Refactoring plan](plan-refactoring.md).

The source assessment below describes the reviewed implementation. The [recorded business decisions](#recorded-business-decisions) define the required behavior for refactoring and supersede earlier recommendations where they differ. This documentation update does not implement those changes in SQL.

## Assessment

The apparent business purpose is to maintain stable customer numbers for individuals in a customer data platform, while honoring eligible numbers from ICON and MAO and preventing reuse of numbers that have been consumed or retired. “Customer data platform” is inferred from the source's use of “CDP”; no separate business specification was supplied.

The process combines two different responsibilities:

1. **Assignment:** associate a real `INDIVIDUAL_ID` with one customer number, preferring a qualifying external number and otherwise generating a number in the CDP range.
2. **Reservation:** record external numbers that must remain unavailable, even when they are not assigned to a real individual by this run.

In the reviewed implementation, both responsibilities write to `STANDARDIZE_CORE.CUST_NUM_INDIVIDUAL_XREF`. Reservation rows use the reserved number as both `INDIVIDUAL_ID` and `CUST_NUM`. Consequently, this table is both a person-to-number mapping and a number reservation register. That dual meaning complicates consumer interpretation, but reservation IDs cannot collide with valid CDP-generated individual IDs under the disjoint ranges documented below. The recorded decision requires reservations to move to a new table in `STANDARDIZE_CORE`, leaving XREF for real assignments.

**The supplied version is a preview:** `what_if` is initialized to `true` at line 12. It builds and validates proposed rows but skips the core insert. A returned `SUCCESS` therefore does not mean customer numbers were persisted.

## Evidence and boundaries

This assessment distinguishes implemented behavior from inferred intent. References to `CDP-1029`, `BR-1`, `BR-2`, `UC-07`, `UC-09`, and `UC-11` come from comments and error messages. Their underlying requirements were not available and have not been independently verified.

No Snowflake execution, production data inspection, schema inspection, or performance measurement was performed. The deployment script named in the source, `GENERATE_CUST_NUMS_add_xref_columns.sql`, was not supplied. Existing constraints, source status values, scheduling controls, and downstream use of reservation rows remain unknown. The flow below describes the source's relational logic; code review F13 identifies compilation-sensitive constructs that must be verified or corrected before execution.

## Business objects and ownership

| Object or field | Business role | Important qualification |
| --- | --- | --- |
| `STANDARDIZE_CORE.PARTY_PROFILE` | Source of individuals and external customer-number candidates | Reads all available rows, with no feed parameter or incremental filter. “History” means whatever this table actually retains. |
| `INDIVIDUAL_ID` | Identity to which a real customer number is assigned | CDP-generated IDs are `100,000,000,000–199,999,999,999` inclusive. Synthetic reservation rows use external customer numbers instead, so interpretation depends on `REC_TYPE`. |
| `SOURCE_SYSTEM_PK_1` | Potential existing customer number from ICON or MAO | Converted to `NUMBER(38,0)` before range checks. |
| `SOR_NAME` | Identifies the source system | Only the literal values `ICON` and `MAO` participate in external-number handling. Individuals from other sources can still receive generated numbers. |
| `PARTY_PROFILE_STATUS_CODE` | Intended to disqualify numbers associated with non-active profiles | Current comparison is to `'-'`, not `'NON_ACTIVE'`. |
| `SOURCE_REC_CREATE_DATETIME` | Preference among external candidates for one individual | Later dates sort first, but null placement is not explicitly specified. |
| Core `CUST_NUM_INDIVIDUAL_XREF` | Persistent assignments and reservations | This block only inserts; it does not update, delete, merge identities, or revoke existing assignments. |
| Stage `CUST_NUM_INDIVIDUAL_XREF` | Proposed changes for the current session | A temporary table, despite its schema-qualified name. |
| `REC_TYPE` | Explains whether a row is an assignment or a reservation | Must already exist in the persistent target. |
| `CREATE_FEED_INSTANCE_ID` | Feed-level attribution for the inserted row | Frequently the maximum feed ID across several profiles, rather than the feed of the winning source record. |

## Number domains

CDP-generated **`INDIVIDUAL_ID` values range from 100,000,000,000 through 199,999,999,999, inclusive** (business information supplied October 16, 2026). This is the real identity domain, distinct from the customer-number ranges allocated or adopted by this procedure. The supplied block does not generate these individual IDs or explicitly validate their range.

| Domain | Rule | Source |
| --- | --- | --- |
| CDP-generated real individual IDs | `100,000,000,000–199,999,999,999` inclusive | Supplied business contract; not a range check implemented in this block |
| External candidate numbers | `1–499,999,999` or `600,000,000–999,999,999` after numeric conversion | Lines 123–129, 232–237 |
| CDP-generated customer numbers (`CUST_NUM`) | Required assignable range: `500,000,001–599,999,999`; `500,000,000` is reserved and must never be assigned.[^reserved-base] | Recorded decision; reviewed range checks at lines 294–296, 380–387 still permit the reserved lower value |
| First generated number with no existing CDP-range values | `500,000,001` | Seed is at least `500,000,000`; allocation adds a row number starting at 1, lines 28–36, 273–291 |
| Reuse of gaps | No allocation into gaps below the current seed | The allocator starts above the greatest retained CDP-range `CUST_NUM`. |
| Zero, negatives, malformed values, and out-of-range external values | Do not participate as external numbers | They do not prevent the corresponding individual from receiving a generated number. |

Real CDP-generated individual IDs therefore cannot equal any valid external customer number, generated customer number, or synthetic reservation ID. For conforming real assignments and reservation rows with `INDIVIDUAL_ID = CUST_NUM`, either-key occupancy and customer-number-only coverage agree for external values. The collision examples in review F04/F05 require out-of-contract identities or inconsistent legacy rows; they are not normal cases under this contract. Validate real IDs at the source boundary and classify core rows by record type; applying the real-ID range to every XREF row would incorrectly reject valid reservations.

The external-range comment at lines 101–105 includes zero; the predicates exclude it. The confirmed generated allocation capacity is 99,999,999 numbers, from `500,000,001` through `599,999,999` inclusive.

[^reserved-base]: The original implementation omitted an explicit business rule stating that `500000000` is reserved and must never be assigned. Its seed calculation already caused initial allocation to start at `500000001`, but its inclusive range validation still admitted `500000000`. The October 16, 2026 decision makes the exclusion explicit and requires validation to enforce it.

## Business rules as implemented

| ID | Rule | Source and assessment |
| --- | --- | --- |
| B01 | Reject a core table containing duplicate customer numbers or duplicate individual IDs. | Lines 19–25. These checks do not establish that either field is non-null. |
| B02 | Treat an individual as “new” only when no core row has the same `INDIVIDUAL_ID`. | Lines 67–81. All `REC_TYPE` values count, including synthetic reservations; their IDs are disjoint from valid real CDP IDs. |
| B03 | Preserve existing mappings. | Existing individual IDs are excluded, and the only core mutation is an insert, lines 453–478. |
| B04 | Consider only valid ICON/MAO PK1 values for external assignment or reservation. | Lines 83–165 and 216–270. Numeric conversion happens before eligibility testing. |
| B05 | Treat an external value as unavailable if it already occurs in either core key column. | `cnxi_taken`, lines 39–64; candidate exclusion, lines 157–164. For conforming real assignments and reservations, the individual-ID arm adds no external values beyond those in `CUST_NUM`. |
| B06 | Disqualify an external value globally if any qualifying ICON/MAO row carries the blocked status. | Lines 83–99, 115–120. It is a rule about the number across all individuals, not just the candidate's own profile. Current blocked status is `'-'`. |
| B07 | Prefer candidates by eligibility, newest source creation date, lowest number, then source-system name. | `EXTERNAL_RANK`, lines 137–146. No explicit ICON-versus-MAO business priority is defined beyond ordering by name. |
| B08 | Resolve competition for the same external number using eligibility, lowest individual ID, newest source creation date, then source-system name. | `CUST_NUM_RANK`, lines 147–156. Exact duplicate source rows may tie, although their output values can be identical. |
| B09 | Assign an external number only if it ranks first under both rankings and is eligible. | Lines 167–180. An individual losing its first choice does not get another attempt with its next choice. |
| B10 | Reserve eligible lower-ranked external numbers as “merged.” | Lines 183–194. This records unavailability; it does not record an actual merge relationship to the surviving individual. |
| B11 | Reserve unoccupied blocked-status numbers, including numbers belonging to already mapped individuals. | Lines 197–213. Values already occupied in core are excluded from this branch. |
| B12 | Reserve other unclaimed valid external numbers, including values attached to already mapped individuals. | Lines 216–270. The branch excludes values equal to a new real individual ID; the other reservation branches lack this exclusion. The exclusion cannot match a valid CDP-generated real ID. |
| B13 | Generate one CDP-range number for each new individual without a selected external assignment. | Lines 273–291. Allocation order is ascending individual ID. There is no status filter on the population of new individuals. |
| B14 | Abort if generated demand exceeds the upper bound or proposed rows fail uniqueness/range checks. | Lines 294–296 and 345–387. |
| B15 | Reject new external assignments present in the blocked-number set. | Lines 390–397. This uses the same previously constructed set; it does not independently re-evaluate source status. |
| B16 | Require every valid ICON/MAO external value to appear in the **customer-number column** of core or stage. | Lines 400–419. This uses a different predicate from B05, but agrees for conforming real assignments and reservation rows; see F04 for invalid/legacy-data exceptions. |
| B17 | Insert only proposed rows whose individual and customer-number keys are absent from the earlier core occupancy snapshot. | Lines 422–478. Rejects are staged separately, but a nonempty reject set is not itself fatal. |
| B18 | Return `SUCCESS` for a completed preview or a completed live path. | Lines 12, 453–481. The return does not include mode or row counts. |

### Meaning of output record types

| `REC_TYPE` | Row contents | Business meaning |
| --- | --- | --- |
| `new_external_cust_num` | Real individual ID; selected external number | A genuine assignment. |
| `new_cdp_cust_num` | Real individual ID; newly generated CDP number | A genuine assignment when external selection did not succeed. |
| `merged_external_cust_num` | External number in both key columns | Reservation of an eligible lower-ranked candidate. No surviving-person link is retained. |
| `nonactive_external_cust_num` | External number in both key columns | Reservation because the number occurs on a profile matching the blocked-status predicate. |
| `unused_external_cust_num` | External number in both key columns | Catch-all reservation for another valid, unoccupied, unclaimed external number. |

Downstream consumers cannot safely interpret every row as a real person-to-number assignment. They need an explicit contract for these record types and any historical rows whose type is unknown.

## Processing flow

```mermaid
flowchart TD
    A[Check core uniqueness] --> B[Capture occupied values and seed]
    B --> C[Find new individuals]
    C --> D[Build blocked values and rank candidates]
    D --> E[Select external assignments]
    D --> F[Build external reservations]
    E --> G[Generate numbers for remaining individuals]
    F --> H[Assemble proposed rows]
    G --> H
    H --> I[Validate and classify rejects]
    I --> J{Preview mode?}
    J -->|Yes| K[Return success with temporary results]
    J -->|No| L[Insert accepted rows into core]
    L --> K
```

Any raised error transfers control to the exception handler. The handler attempts a rollback, builds a temporary list of still-unmapped IDs, and rethrows the error.

| Stage | Work produced | Source |
| --- | --- | --- |
| 1. Preconditions | Validate duplicate-free core keys. | Lines 17–25 |
| 2. Allocation context | `cnxi_maxid` holds the current seed; `cnxi_taken` holds occupied values with key-column provenance flags. | Lines 28–64 |
| 3. Individual population | `cnxi_new_ind`, grouped by individual with maximum update feed ID. | Lines 67–81 |
| 4. Blocked numbers | `cnxi_nonactive_cust_num`, across all qualifying source profiles. | Lines 83–99 |
| 5. External ranking | `cnxi_external_cust_num`, restricted to new individuals and unoccupied values. | Lines 101–165 |
| 6. External assignments | `cnxi_new_external_cust_num`, requiring both ranks to equal one. | Lines 167–180 |
| 7. Reservations | Merged, non-active, and unused external-number tables. | Lines 183–270 |
| 8. Generated assignments | `cnxi_new_cdp_cust_num` and exhaustion check. | Lines 273–296 |
| 9. Proposed output | Temporary stage XREF; distinct union of all five output categories, stamped with creation time. | Lines 299–342 |
| 10. Validation | Stage/core uniqueness, generated range, blocked-number assignment, and external coverage. | Lines 345–419 |
| 11. Reject classification | `cnxi_insert_rejects`, using the earlier occupancy snapshot and same-column keys. | Lines 422–449 |
| 12. Completion | Optional core insert, commit statement, and success return; otherwise exception handling. | Lines 451–495 |

## Worked business examples

These examples describe the supplied logic with an initially empty core unless stated otherwise. Real IDs use the supplied CDP range. Values are illustrative, not production records.

| Situation | Result |
| --- | --- |
| Individual 100000000007 has one eligible external number 42. | Assign `(100000000007, 42)` as `new_external_cust_num`. |
| Individual 100000000007 has no qualifying ICON/MAO number. | Propose `(100000000007, 500000001)` as `new_cdp_cust_num`. |
| Individual 100000000007 has number 11 on a newer source row and number 42 on an older row. | Assign 11 and reserve `(42, 42)` as merged, provided no other conflicts arise. |
| Individual 100000000007 has external number 42 on a row whose status is `'-'`. | Reserve `(42, 42)` as non-active and give individual 100000000007 a generated number. |
| The same row instead has literal status `'NON_ACTIVE'`. | Current code can assign 42. This violates the confirmed authoritative encoding and global blocking decision. |
| Individuals 100000000007 and 100000000008 both prefer 101; individual 100000000008 also has lower-ranked 102. | Individual 100000000007 receives 101; individual 100000000008 receives a generated number; 102 is reserved as merged. There is no fallback retry. |
| Core contains real assignment `(100000000042, 500000001)` and new individual 100000000007 presents eligible external number 42. | The real ID does not occupy external number 42; assign `(100000000007, 42)` if no other conflicts exist. |
| Invalid/legacy core contains `(42, 500000001)` and a new profile presents external number 42. | This violates the supplied real-ID domain and is not a normal reservation. The value is excluded as occupied, but customer-number-only coverage fails with `-20007` (F04). |

## Important operational implications

- **Existing assignments are not reconsidered.** If an already assigned external number later appears on a blocked-status profile, this block does not revoke that assignment. The recorded decision prohibits new assignments of that value; it does not direct retrospective revocation.
- **Retirement relies on retained data.** Synthetic reservations persist through inserts, but no independent historical allocation ledger appears here. Removing the largest allocated CDP number can lower the next seed on a later run.
- **Preview is computationally substantive.** It scans inputs, constructs temporary tables, and can fail validation. It does not reserve generated numbers for a later live run.
- **The apparent transaction is not an end-to-end rollback boundary.** Snowflake DDL implicitly commits active transactions; this block interleaves temporary-table DDL with its transaction statements. See code review F02 and [Snowflake transactions](https://docs.snowflake.com/en/sql-reference/transactions).
- **Diagnostics are session-local.** Ordinary temporary tables exist only in their creating session. No durable run report is produced here. See [Snowflake temporary tables](https://docs.snowflake.com/en/user-guide/tables-temp-transient).
- **Feed attribution is coarse.** Assignment and merged rows use the maximum feed ID for the individual; non-active and unused rows use a maximum over their qualifying number occurrences. Those values need not identify the exact source row that determined the outcome.

## Recorded business decisions

These decisions were supplied October 16, 2026, with F01–F04, F09, and F11 additions and the F07 fallback reversal on October 19, 2026. They replace the earlier open-question recommendations and govern the target implementation. The current-behavior tables and examples above remain an assessment of the reviewed SQL.

| Question | Recorded decision | Required effect |
| --- | --- | --- |
| Which status values are excluded? | Only the exact `PARTY_PROFILE_STATUS_CODE` value `NON_ACTIVE` is excluded. Every other value is eligible under the status rule, including NULL, empty strings, whitespace, hyphens, case variants, and arbitrary strings. | Compare exactly without trimming, case folding, or a whitelist. Other eligibility rules and global blocking by a qualifying exact `NON_ACTIVE` occurrence still apply. This decision is settled. |
| Does one blocked occurrence disqualify a number globally and permanently? | Any qualifying `NON_ACTIVE` ICON or MAO occurrence of a given `SOURCE_SYSTEM_PK_1` prevents all new assignments of that value. | Apply the block across individuals and both sources. An active occurrence cannot override a qualifying blocked occurrence. The decision concerns new assignments. |
| How are staging objects provisioned (F02)? | Use permanent staging tables created before procedure execution. | Supply one DDL file per required staging table in `dw/STANDARDIZE_STAGE/Tables`. D05.2 defensively truncates dedicated work tables after lock acquisition; subsequent work and final cleanup use run-scoped DML. |
| How are concurrent generation instances controlled (F03)? | Serialize CUST_NUM generation through a lock on a new `STANDARDIZE_AUDIT.CUST_NUM_PROCESS` table. | Acquire before baseline/seed reads and hold through commit or rollback. External writers bypassing this protocol are an accepted risk; this is not a guarantee against those writers. |
| Which source population governs a run (F09)? | Materialize the required `PARTY_PROFILE` columns once, preserving rows for all individuals and external-number coverage. | Run source-ID preflight before filtering invalid IDs. Normalize PK1 and classify status by exact exclusion once, retain raw diagnostics, and derive assignments, ranked external candidates, reservations, and source-based self-checks from the prepared relations. |
| What PK1 format is eligible for external adoption (F11)? | PK1 must represent a valid unsigned decimal integer and satisfy the existing external customer-number ranges. | Validate syntax and conversion before adoption; normalize leading zeros numerically. Reject signed, decimal, exponent, empty, NULL, and unconvertible values as external candidates. Invalid PK1 does not remove a valid individual from generated-number eligibility. |
| How is the supplied real-ID domain validated, including historical data? | Require a preflight check on `PARTY_PROFILE.INDIVIDUAL_ID`. | Before planning assignments, reject null or out-of-domain source IDs; require integer IDs in `100000000000–199999999999` inclusive. Check all retained rows in the input population, including rows for already mapped individuals. |
| How are unresolved CORE integrity violations handled (F04)? | Fail preflight and handle remediation separately. | Stop the entire invocation before assignment planning or business writes if existing CORE has invalid real-assignment `INDIVIDUAL_ID` values, malformed legacy reservations, unresolved null/unrecognized `REC_TYPE` values, or other required integrity-check failures. Filtering or quarantine does not permit continuation. Automatic repair, deletion, or historical identity reassignment is not authorized. |
| Should reservations continue sharing XREF with real assignments? | Use a new reservation table in the CORE schema. | Store reservations in a new `STANDARDIZE_CORE` table, without fabricated individual IDs. Keep real assignments in XREF and check both stores when determining number availability. The new table's name and column layout are implementation details to design. |
| Should a losing individual try its next external candidate? | No. The earlier approval for fallback is superseded by the October 19 decision to retain original dual-ranking selection. | Select eligible candidates only when both ranks equal 1. Do not retry, rerank, or rebalance. A new individual without a selected external assignment receives a generated number even if an eligible alternative exists. Finalize eligible unassigned-number reservations after selection. |
| Can a committed `NON_ACTIVE` reservation be released after the source changes? | No. D03.1 option A: retain it permanently. | Later status changes, corrections, or source removal do not restore availability. No automatic or built-in administrative release path; exceptional data remediation is separate. |
| Which reservation reasons are retained? | D03.2 option A: retain `nonactive_external_cust_num`, `merged_external_cust_num`, and `unused_external_cust_num`. | Preserve original branch classification with the approved status/eligibility corrections: non-active first, then qualifying merged, then unused. One reason per newly reserved number; preserve validated legacy reason values. |
| Can later observations change an existing reservation? | No. D03.3 option A: keep its original reason and creation metadata. | Do not update its reason, creation date, feed attribution, or stored creation/run metadata. The number remains unavailable; insert only new reservations. |
| How are reservation audit and source fields populated? | D03.4: `CREATE_DATE` and `CREATE_FEED_INSTANCE_ID` are creation audit; the feed is the generation invocation. Keep source feed in `ORIGINATING_FEED_INSTANCE_ID` and source identity in `SOURCE_PARTY_PROFILE_ID`. | Choose the smallest qualifying source ID in string order for duplicates and carry that same row's source feed. No redundant reservation `RUN_ID`. |
| How is creation audit populated for migrated reservations? | D03.5 option B: preserve the verified original timestamp and reconstruct the actual historical generation invocation. | Retain supporting history/audit evidence. Do not substitute migration audit values or mistake legacy source attribution for the creating invocation. Missing or ambiguous required evidence blocks acceptance/cutover until separate resolution. |
| How is the generated-number seed maintained? | D04.1 option B: greatest retained generated XREF number, floored at `500000000`; no separate counter or sequence. | D04.2: do not detect or react to generated-assignment history loss, including known loss. A lost highest assignment can lower the seed and allow reuse. |
| Are missing source dates lowest priority? | Yes, null source dates are the lowest priority. | Use explicit `NULLS LAST` wherever source dates participate in preference or ownership ordering. |
| Is `500000000` a reserved sentinel or an allocatable number? | `500000000` is reserved and never assigned.[^reserved-base] | Generate CDP customer numbers only in `500000001–599999999` and validate against those bounds. |
| What does “never reuse” include? | An eligible PK1 not assigned to an `INDIVIDUAL_ID` during successful processing becomes ineligible for assignment in the future. | Persist its retirement in the new reservation table as part of successful live processing, after dual-ranking selection completes. Later feeds must not make it available again. |
| What constitutes success? | An error-free run without any failed preflight or self-checks. | Any error or failed required check prevents a success outcome. A successful preview validates proposals; successful live processing also persists and reconciles assignments and reservations. Report the mode so these outcomes are distinguishable. |

**D03.2 decision (October 19, option A):** Retain the exact reservation reason values `nonactive_external_cust_num`, `merged_external_cust_num`, and `unused_external_cust_num`. For a new reservation, classify a qualifying exact `NON_ACTIVE` value as `nonactive_external_cust_num`; otherwise use `merged_external_cust_num` when the eligible candidate has `EXTERNAL_RANK > 1` and `CUST_NUM_RANK = 1`; otherwise use `unused_external_cust_num` for remaining valid, unoccupied external values not assigned or reserved by another branch. Exclude existing assignments/reservations and final new assignments before creating reservation rows. Each newly reserved number has one reason. The `merged` label does not establish a person merge or surviving-individual link. Preserve these exact values for validated legacy reservations during migration; F04 still blocks malformed or unclassified rows.

**D03.3 decision (October 19, option A):** Existing reservation rows are immutable during normal generation. Preserve the original reason, creation date, feed attribution, and any stored creation/run metadata. Later observations, including a new exact `NON_ACTIVE` occurrence, do not update the row, append another reservation for the same number, or release the number. The reason records why the number was first reserved, not its latest observed status. Reprocessing is insert-only for newly reserved numbers; exceptional data remediation remains separate.

**D03.4 decision (October 19):** Use `STANDARDIZE_CORE.CUST_NUM_RESERVATION` with `CUST_NUM`, `REC_TYPE`, `CREATE_DATE`, `CREATE_FEED_INSTANCE_ID`, `ORIGINATING_FEED_INSTANCE_ID`, and `SOURCE_PARTY_PROFILE_ID`. For new generation rows, `CREATE_DATE` is the reservation creation timestamp and `CREATE_FEED_INSTANCE_ID` is the generation invocation's `FEED_INSTANCE_ID`. Store the selected source row's feed in `ORIGINATING_FEED_INSTANCE_ID` and its source identifier in `SOURCE_PARTY_PROFILE_ID`. For duplicate qualifying sources, select the smallest `SOURCE_PARTY_PROFILE_ID` in string order using its existing VARCHAR type, not numeric order. Carry the originating feed and source identifier together from that selected row; do not combine independent aggregate values from different rows. No separate reservation `RUN_ID` is needed because the invocation is identified by `CREATE_FEED_INSTANCE_ID`; staging/reporting retain their existing run identity contract. D03.3 immutability applies to all six reservation fields.

The original source assessment above describes legacy attribution. It is not the target reservation audit contract. Legacy audit/source mapping must be reconciled explicitly under settled D03.5: retain the original creation timestamp and reconstruct the historical generation invocation. Required historical lineage must not be fabricated.

**D03.5 decision (October 19, option B):** Reconstruct historical creation audit for migrated reservations. Preserve the verified original `CREATE_DATE` and populate `CREATE_FEED_INSTANCE_ID` with the actual historical generation invocation's `FEED_INSTANCE_ID`, recovered from supporting audit/history evidence. Do not replace these values with the migration timestamp or migration invocation ID. Do not treat the legacy source-attribution value as proof of the historical generation invocation. Populate `ORIGINATING_FEED_INSTANCE_ID` and `SOURCE_PARTY_PROFILE_ID` from verified source evidence under D03.4, preserving validated original reason values. Retain reconstruction evidence with the migration reconciliation. Missing or ambiguous required audit/source lineage blocks migration acceptance and cutover until separately resolved under F04/D08; do not fabricate values, silently skip unresolved reservations, or weaken the required fields. This settles D03 policy; reconstruction, implementation, and verification remain pending.

**D04.1 decision (October 19, option B):** Retain the original XREF-derived generated-number seed. After acquiring the process lock and passing CORE preflight, read the greatest retained generated `CUST_NUM` in `500000001–599999999`, using `500000000` as the floor when none exists. Allocate sequentially above that seed in individual-ID order; do not fill gaps below it. Add no separate allocation-state table, sequence, or `LAST_GENERATED_CUST_NUM` counter. `CUST_NUM_PROCESS` remains the generation gate, not a historical number counter. Preview and confirmed rollback leave the persisted XREF unchanged and consume no generated numbers. Preventing reuse depends on retaining committed generated-assignment history. The allocator cannot prove that higher historical assignments were deleted merely by inspecting the remaining XREF. Under settled D04.2, do not detect or react to generated-assignment history loss; continue using the retained-XREF seed, including when loss is known. A lost highest assignment can lower the seed and permit reuse.

**D05.1 decision (October 19, option A):** Wait up to 60 seconds to acquire the shared generation lock. If it remains blocked at the limit, fail the invocation before source preparation, allocation planning, or business writes; do not continue without the lock. Apply the same limit to live and preview invocations. This limits lock acquisition, not total procedure execution. Verify enforcement with the actual wrapper, caller settings, and target account during implementation.

**D05.2 decision (October 19, option A with defensive startup truncate):** Retain no successful-run staging rows. Immediately after acquiring the shared generation lock, and before source capture or populating work tables, `TRUNCATE TABLE` each explicitly inventoried, predeployed work table dedicated to this procedure. This startup cleanup intentionally removes stale rows across all run IDs; it is the sole exception to run-scoped staging DML. Never truncate source, CORE assignment/reservation, process control, or audit/reporting tables. Perform the truncates in the coordinator transaction while holding the gate; no early commit or unlocked cleanup. All generation modes use this ordering. After live validation/apply reconciliation, capture required report values in procedure state and delete the current run's work rows before commit. Cleanup failure fails the invocation and rolls back its transaction. Preview/failure rollback undoes both startup truncation and new staging writes, so pre-existing stale rows can reappear; do not promise durable cleanup after rollback. No staging-retention period or scheduled cleanup job is required. Durable reporting remains separate.

**D05.3 decision (October 19, option A):** Require no open caller transaction when invoking generation, for live and preview alike. The caller must finish its transaction before the call; the coordinator begins and completes its own business transaction. Reject an invocation with an already-open caller transaction before acquiring the generation gate, truncating work tables, preparing source data, or applying business writes. Never commit or roll back caller-owned work to satisfy this precondition. Preserve the error through the existing harness; any reporting of rejected entry must use the D07 independent logging contract without modifying the caller transaction. Verify entry detection and rejection with the actual wrapper and harness. The AUTOCOMMIT requirement is settled separately under D05.4; D05.3 does not replace the separate D07 audit transaction design.

**D05.4 decision (October 19, option A):** Require the caller session to have `AUTOCOMMIT = TRUE` before invoking generation, for live and preview alike, in addition to D05.3's no-open-caller-transaction requirement. `AUTOCOMMIT = FALSE` is unsupported and must not proceed into generation work. The coordinator still explicitly begins and completes its business transaction; enabled autocommit does not make the statements inside that transaction commit individually. Do not enable or change AUTOCOMMIT inside the procedure or commit caller-owned work to satisfy the contract. Verify configuration and enforcement using the selected execution-rights model and actual harness during M0; do not assume session-inspection commands are available under every rights mode. The setting does not replace the separate D07 durable-logging design.

**D05.5 decision (October 19, option A):** Retain `EXECUTE AS OWNER` for the public generation procedure, matching the supplied `GENERATE_CUST_NUMS.prod.sql` wrapper. Use the procedure owner's privileges for underlying data operations; callers need the appropriate procedure, database/schema, and warehouse access, without requiring direct privileges on every underlying table. Record the actual owner role and required grants as deployment configuration. Verify D05.1 lock-wait enforcement, D05.3 caller-transaction rejection, D05.4 AUTOCOMMIT enforcement, and D07 logging under owner rights with the actual harness, including an authorized non-owner caller. Do not assume caller-session inspection or session changes are available under owner rights. The rights policy is settled; target-account verification and grants remain implementation/deployment work. Database/schema resolution is settled separately under D05.6.

**D05.6 decision (October 19, option A):** Resolve data objects relative to the database containing the deployed generation procedure, under settled `EXECUTE AS OWNER`. Keep explicit two-part `SCHEMA.OBJECT` references, using `STANDARDIZE_CORE`, `STANDARDIZE_STAGE`, and `STANDARDIZE_AUDIT` in that same database. Apply this convention to source/target tables, work-table truncation and cleanup, process control, process logging, and helper calls. Do not introduce caller-selected database routing or environment-specific database literals inside the procedure body. Deployment selects the environment database and installs the procedure and required objects there; callers can use a fully qualified procedure name to select the intended deployment. Verify calls made while the caller has a different current database/schema still use only the called procedure's environment. D05 policy is fully settled; actual environment names, grants, implementation, and target-account verification remain deployment/qualification work.

**D06.1 decision (October 19, option A):** The caller explicitly supplies the invocation's `FEED_INSTANCE_ID`, `AUTOMATION_GUID`, and a Boolean preview flag. TRUE means preview and FALSE means live. Use the existing harness-issued identifiers; generation creates neither identifier, does not derive them from source rows, and does not look up `FEED_INSTANCE` to obtain a missing automation identifier. `RUN_ID` remains exactly `FEED_INSTANCE_ID`. Require both identifiers and an explicit non-null mode before generation work; missing identity or mode must not fall through to live processing. Use the supplied invocation feed for generation audit fields under the existing provenance decisions. Verify parameter binding with the actual harness; this records the procedure input contract without changing the harness. Automation identifier width and caller return value are settled under D06.2 and D06.3.

**D06.2 decision (October 19, option C supplied by user):** Use `VARCHAR(36)` for the `AUTOMATION_GUID` procedure input contract and the new `CUST_NUM_PROCESS_LOG` column. The identifier is externally supplied and the user has verified this contract as correct; its width and external correctness are settled, not outstanding discovery or approval items. Preserve the supplied value without truncation, normalization, or regeneration. Do not add UUID-format validation or widen the new contract based on the existing audit tables' larger capacities. Leave existing `AUTOMATION_LOG` and `FEED_INSTANCE` definitions unchanged. Implementation verification covers parameter binding and unchanged propagation into reporting; it does not reopen the confirmed identifier contract.

**D06.3 decision (October 19, option A):** Preserve the VARCHAR return contract and return the exact string `SUCCESS` only when the requested invocation mode completes successfully, including every required validation and reporting operation. Successful preview, successful live apply, and successful zero-work processing use that same return value. It indicates execution success, not proof of committed business changes. Mode, validated counts, persistence state, and process-log ID remain in `STANDARDIZE_AUDIT.CUST_NUM_PROCESS_LOG`, located using the supplied `FEED_INSTANCE_ID`; do not add a structured response or return a log ID. Failures raise the appropriate SQL error through the existing harness, preserving the original error under F12. A post-commit reporting failure still raises an error while retaining the known business commitment; it must not return `SUCCESS` or trigger blind reapplication. No harness changes are required by this return decision. D06 policy is fully settled; parameter binding and behavioral verification remain implementation work.

**D07.1 decision (October 19, option A):** Use a dedicated logging procedure in `STANDARDIZE_AUDIT` for all writes to `CUST_NUM_PROCESS_LOG`. Pass scalar/JSON report values to the helper; it explicitly begins and completes its own audit-only scoped transaction. The generation coordinator remains the sole owner of its business transaction and retains the generation lock through planning, validation, apply, and commit/rollback. The helper accesses the process log only, not source/staging data, assignments, reservations, or the process control table; the coordinator's business transaction does not also write the log row. Preserve durable initialization, `IN_PROGRESS` immediately before live business writes while the gate is held, and confirmed completion/failure reporting. Initial/in-progress audit failure prevents apply; post-commit audit failure raises without claiming rollback or returning `SUCCESS`. Preserve the original error when rollback or secondary logging fails. D07 policy is settled; M0 must prove independent audit persistence, no early gate release or shared-object deadlock, and the existing failure behavior under the selected owner-rights/caller contract. No harness changes or external logging service are introduced.

**D08.1 decision (October 19, option A):** Update affected consumers for the separate assignment/reservation model as part of the controlled cutover. Consumers read genuine assignments from XREF and reservations from `STANDARDIZE_CORE.CUST_NUM_RESERVATION` where needed. Inventory actual consumers, update and verify those affected, and deploy their compatible versions with the migration before enabling generation callers. Do not introduce a temporary compatibility view that recreates legacy combined/synthetic rows or an independent dual-writing allocator. Consumer readiness is a cutover prerequisite; discovering the inventory and proving compatibility remain implementation work. Existing evidence-based classification, separate remediation, D03.5 reservation-audit reconstruction, and F04 unresolved-data blocking remain unchanged. D04.2 still requires no detection or response to lost generated-assignment history. D08 policy is settled; migration evidence, consumer changes, and cutover/recovery qualification remain pending.

### What “never reuse” now requires

The retirement decision applies to **eligible external PK1 values left unassigned after successful processing**. A number does not need to have been assigned to a person to become permanently unavailable. Its unused disposition at the end of successful processing is sufficient.

For example, individual `100000000007` presents eligible numbers 11 and 42. If 11 is assigned and no individual receives 42 after dual-ranking selection, reserve 42 in the new CORE reservation table. If a later feed presents 42 for another individual, it remains ineligible. Removing the original profile must not erase that retirement.

The F07 reversal retains original selection without fallback. If individuals `100000000007` and `100000000008` both prefer 101, and the latter also has eligible 102, individual `100000000007` receives 101. Individual `100000000008` receives a generated number, and eligible unassigned 102 is retired in the CORE reservation table. Finalize retirement after this selection; do not retry alternatives or rearrange winners. An existing genuine assignment also continues to occupy its number; a rerun must not classify it as unused merely because no new assignment was needed.

Successful live processing must preserve both real assignments and the retirement of unused eligible values together. A preview can show proposed reservations but does not make them permanent. A failed run must not be treated as successful retirement; the apply design must prevent partial persistence from contradicting that outcome.

Permanent external-PK1 retirement remains separate from generated-number allocation. D04.1 retains the greatest generated number still in XREF, without a separate historical counter. Preview and confirmed rollback consume no generated numbers. D04.2 is settled: do not detect or react to generated-assignment history loss, including known deletion or incomplete restore. Continue from the retained-XREF seed without a history-loss recovery gate; possible reuse after loss is accepted.

### What global blocking now requires

A qualifying `NON_ACTIVE` occurrence blocks the external value across **all individuals and both ICON and MAO**. Eligibility is therefore not decided independently for each profile.

For example, an ICON profile for `100000000007` carries PK1 42 with status `NON_ACTIVE`, while an active MAO profile for `100000000008` also carries 42. Neither individual may receive 42 as a new assignment. Each receives an external number only if an eligible candidate passes both original rankings; otherwise it receives a generated number. There is no iterative retry of alternatives after a ranking conflict.

The decision does not restrict the block to the latest occurrence, the same individual, or the same source. Existing assignments are outside its prohibition on **new** assignments; it does not instruct this procedure to revoke them. Blocking because of `NON_ACTIVE` and retirement because an eligible value was left unused are distinct reasons for unavailability and should remain distinguishable in reservation evidence.

**D03.1 decision (October 19, option A):** A committed reservation created because of exact `NON_ACTIVE` is permanent. A later eligible status, corrected occurrence, or removed source profile does not make the number available again. Normal processing never releases it, and no administrative release procedure is included in this scope; exceptional data remediation remains separate. Status classification remains governed by D01: only exact `NON_ACTIVE` is excluded; NULL, empty strings, whitespace, hyphens, case variants, and every other string pass the status rule. Do not trim or case-fold status values. Passing the current status rule does not override an existing permanent reservation.

### Acceptance examples for the recorded decisions

These are required outcomes for the refactor, not new execution results.

| Situation | Required outcome |
| --- | --- |
| An otherwise qualifying ICON/MAO value occurs with exact `NON_ACTIVE`, including alongside any otherwise eligible status for another individual/source. | No new assignment of that value. |
| Status is NULL, empty, whitespace, `-`, `ACTIVE`, `non_active`, `Non_Active`, padded `NON_ACTIVE`, or any other string except exact `NON_ACTIVE`. | Pass the status rule; apply the other eligibility rules and global blocked-number check. |
| A retained `PARTY_PROFILE` row has a null ID, `99999999999`, or `200000000000`. | Preflight fails; the run cannot succeed. IDs `100000000000` and `199999999999` pass the domain check. |
| An individual loses its preferred external number and has another eligible candidate. | Do not retry the alternative. If no external candidate passes both original rankings, give the individual a generated number and reserve eligible values left unassigned after selection. |
| Otherwise equally eligible candidates have known and null source dates. | The known date takes priority. |
| The generated range is empty. | First allocation is `500000001`; any proposed assignment of `500000000` fails validation. |
| An eligible PK1 remains unassigned after successful live processing, then reappears in a later feed. | A CORE reservation persists and prevents future assignment. |
| A reservation is required. | Store it in the new CORE reservation table; do not fabricate an XREF individual. |
| Any required preflight or self-check fails, or execution raises an error. | Report failure, not success. A run with no errors and all required checks passing meets the success definition; report whether it was preview or live. |

The companion code review retains its source findings and identifies the decisions that resolve policy ambiguity. The refactoring plan translates these decisions into target contracts and acceptance tests.
