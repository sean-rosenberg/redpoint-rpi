# RPDM SQL Scripts

This directory stores copies of SQL statements defined in RPDM projects and automations.

> **Source of truth:** RPDM is authoritative. These files document the SQL defined there; editing a local copy does not update RPDM.

## Directory structure

The local directory `dw/.scripts/rpdm` represents the RPDM repository root. Subdirectories mirror the RPDM folder hierarchy.

Local project and automation folders include a `.dlp` or `.dla` suffix. These suffixes are omitted from the corresponding RPDM paths.

For example:

- **RPDM:** `repository://InSitu_Model/core/PartyProfile_002_Transform`
- **Local:** `dw/.scripts/rpdm/InSitu_Model/core/PartyProfile_002_Transform.dlp/`

Within each project or automation folder, SQL files are grouped into subfolders named after the RPDM tool that contains the statements. For example:

    InSitu_Model/core/PartyProfile_002_Transform.dlp/
      Calculate 19/
        07-DIFFKEY_CUST_NUM_INDIVIDUAL_XREF.sql
