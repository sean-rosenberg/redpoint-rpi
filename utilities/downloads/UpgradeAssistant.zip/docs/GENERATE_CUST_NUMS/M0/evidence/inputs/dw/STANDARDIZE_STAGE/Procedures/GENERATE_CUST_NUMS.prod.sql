CREATE OR REPLACE PROCEDURE "GENERATE_CUST_NUMS"()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS $$
DECLARE
    ex_duplicate_cust_num_01 EXCEPTION ( -20002, ''PRECONDITION CHECK FAILED: Duplicate cust_num(s) found in CUST_NUM_INDIVIDUAL_XREF'' );
    ex_duplicate_cust_num_02 EXCEPTION ( -20003, ''CHECK FAILED: Duplicate cust_num(s) found in STANDARDIZE_STAGE.CUST_NUM_INDIVIDUAL_XREF'' );
    ex_duplicate_cust_num_03 EXCEPTION ( -20004, ''CHECK FAILED: Duplicate cust_num(s) found between STANDARDIZE_CORE.CUST_NUM_INDIVIDUAL_XREF and STANDARDIZE_STAGE.CUST_NUM_INDIVIDUAL_XREF'' );
    ex_duplicate_ind_id_01 EXCEPTION ( -20012, ''PRECONDITION CHECK FAILED: Duplicate individual_id(s) found in CUST_NUM_INDIVIDUAL_XREF'' );
    ex_duplicate_ind_id_02 EXCEPTION ( -20013, ''CHECK FAILED: Duplicate individual_id(s) found in STANDARDIZE_STAGE.CUST_NUM_INDIVIDUAL_XREF'' );
    ex_duplicate_ind_id_03 EXCEPTION ( -20014, ''CHECK FAILED: Duplicate individual_id(s) found between STANDARDIZE_CORE.CUST_NUM_INDIVIDUAL_XREF and STANDARDIZE_STAGE.CUST_NUM_INDIVIDUAL_XREF'' );
    ex_cust_num_out_of_range EXCEPTION ( -20005, ''CHECK FAILED: a customer number would be created outside of the 500M range.'' );
BEGIN

    BEGIN TRANSACTION;

    IF ( EXISTS ( SELECT 1 FROM STANDARDIZE_CORE.CUST_NUM_INDIVIDUAL_XREF GROUP BY CUST_NUM HAVING COUNT(1) > 1 ) ) THEN
        RAISE ex_duplicate_cust_num_01;
    END IF;

    IF ( EXISTS ( SELECT 1 FROM STANDARDIZE_CORE.CUST_NUM_INDIVIDUAL_XREF GROUP BY INDIVIDUAL_ID HAVING COUNT(1) > 1 ) ) THEN
        RAISE ex_duplicate_ind_id_01;
    END IF;
    

    CREATE OR REPLACE TABLE STANDARDIZE_STAGE.cnxi_maxid AS
    SELECT
        GREATEST(500000000, IFNULL(MAX(CUST_NUM),0)) AS SEED
    FROM
        STANDARDIZE_CORE.CUST_NUM_INDIVIDUAL_XREF
    WHERE
        CUST_NUM BETWEEN 500000000 AND 599999999
    ;
    

    -- Get individual IDs not already in CUST_NUM_INDIVIDUAL_XREF
    -- these will require new CUST_NUM.
    CREATE OR REPLACE TABLE STANDARDIZE_STAGE.cnxi_new_ind AS
    SELECT
        pp.INDIVIDUAL_ID
    ,   MAX(pp.UPDATE_FEED_INSTANCE_ID) AS  FEED_INSTANCE_ID
    FROM STANDARDIZE_CORE.PARTY_PROFILE AS pp
    WHERE pp.INDIVIDUAL_ID NOT IN
    (
        SELECT cnxi.INDIVIDUAL_ID
        FROM STANDARDIZE_CORE.CUST_NUM_INDIVIDUAL_XREF cnxi
    )
    GROUP BY pp.INDIVIDUAL_ID
    ;

    -- Get a list of externally created cust_num values to honor in
    -- CDP, these are SOURCE_SYSTEM_PK_1 from SOR_NAME = ICON or MAO
    -- WHERE SSPK1 is not already used as CUST_NUM or INDIVIDUAL_ID
    -- in CUST_NUM_INDIVIDUAL_XREF and the value is in the range
    -- 0..499999999,600000000..999999999
    CREATE OR REPLACE TABLE STANDARDIZE_STAGE.cnxi_external_cust_num AS
    WITH cte_ext_num AS
    (
        SELECT
            pp.INDIVIDUAL_ID
        ,   TRY_CAST( pp.SOURCE_SYSTEM_PK_1 AS NUMBER(38,0) )   AS t_cust_num
        ,   pp.SOURCE_REC_CREATE_DATETIME                       AS t_src_create_date
        ,   pp.SOR_NAME
        ,   new_ind.FEED_INSTANCE_ID
        FROM STANDARDIZE_CORE.PARTY_PROFILE AS  pp
        JOIN STANDARDIZE_STAGE.cnxi_new_ind AS  new_ind ON pp.INDIVIDUAL_ID = new_ind.INDIVIDUAL_ID
        WHERE
            pp.SOR_NAME IN ( ''ICON'', ''MAO'' )  -- External CUST_NUM sources, include ICON and MAO
        AND t_cust_num IS NOT NULL            -- Extenal cust num must not be NULL
        AND t_cust_num     BETWEEN  1         -- must be positive and in the range
                                AND 999999999 -- 1 through 999,999,999
        AND t_cust_num NOT BETWEEN  500000000 -- but not in the reserved CDP range of 
                                AND 599999999 -- 500,000,000 through 599,999,999
    )
    SELECT
        src.INDIVIDUAL_ID
    ,   src.FEED_INSTANCE_ID
    ,   src.SOR_NAME
    ,   src.t_cust_num
    ,   DENSE_RANK()                       -- Rank externally source cust_nums from 1..[n]
        OVER (                             -- where 1 is the highest rank and is used as
            PARTITION BY                   -- the cust_num for the individual_id and 
                src.INDIVIDUAL_ID          -- 2+ are recorded as ''merged'' values that
            ORDER BY                       -- were unused in CDP from CDP''s PoV.
                src.t_src_create_date DESC
              , src.t_cust_num ASC
              , src.SOR_NAME
        ) AS EXTERNAL_RANK
    ,   ROW_NUMBER()                        -- CUST_NUM_RANK prevents re-use of the same 
        OVER (                              -- external cust_num in this procedure, we
            PARTITION BY                    -- ONLY USE RECORDS having CUST_NUM_RANK = 1
                src.t_cust_num
            ORDER BY
                src.INDIVIDUAL_ID
              , src.t_src_create_date DESC
              , src.SOR_NAME
        ) AS CUST_NUM_RANK
    FROM cte_ext_num src
    WHERE
        NOT EXISTS
        (                   -- external cust_num value may not have been
                SELECT 1    -- previously used as cust_num or individual_id
                FROM STANDARDIZE_CORE.CUST_NUM_INDIVIDUAL_XREF xref
                WHERE 
                    xref.CUST_NUM      = src.t_cust_num
                OR  xref.INDIVIDUAL_ID = src.t_cust_num
        )
    ;

    -- These are the the CUST_NUM values which will be used in CDP
    CREATE OR REPLACE TABLE STANDARDIZE_STAGE.cnxi_new_external_cust_num AS
    SELECT
        new_ind.INDIVIDUAL_ID
    ,   ext_num.t_cust_num          AS CUST_NUM
    ,   ''new_external_cust_num''     AS REC_TYPE
    ,   new_ind.FEED_INSTANCE_ID
    FROM STANDARDIZE_STAGE.cnxi_new_ind new_ind
    JOIN STANDARDIZE_STAGE.cnxi_external_cust_num ext_num ON new_ind.INDIVIDUAL_ID = ext_num.INDIVIDUAL_ID
    WHERE
        ext_num.EXTERNAL_RANK = 1
    AND ext_num.CUST_NUM_RANK = 1
    ;


    CREATE OR REPLACE TABLE STANDARDIZE_STAGE.cnxi_merged_external_cust_num AS
    SELECT
        ext_num.t_cust_num          AS INDIVIDUAL_ID
    ,   ext_num.t_cust_num          AS CUST_NUM
    ,   ''merged_external_cust_num''  AS REC_TYPE 
    ,   ext_num.FEED_INSTANCE_ID
    FROM STANDARDIZE_STAGE.cnxi_external_cust_num ext_num
    WHERE
        ext_num.EXTERNAL_RANK > 1
    AND ext_num.CUST_NUM_RANK = 1
    ;


    -- These are new CDP-generated CUST_NUM values
    CREATE OR REPLACE TABLE STANDARDIZE_STAGE.cnxi_new_cdp_cust_num AS
    SELECT
        new_ind.INDIVIDUAL_ID
    ,   ROW_NUMBER() 
        OVER ( 
            ORDER BY new_ind.INDIVIDUAL_ID
        ) + max_id.SEED                     AS CUST_NUM
    ,   ''new_cdp_cust_num''                  AS REC_TYPE
    ,   new_ind.FEED_INSTANCE_ID
    FROM  STANDARDIZE_STAGE.cnxi_new_ind AS new_ind
      ,   STANDARDIZE_STAGE.cnxi_maxid   AS max_id
    WHERE new_ind.INDIVIDUAL_ID NOT IN 
    (
        SELECT new_ext.INDIVIDUAL_ID 
        FROM STANDARDIZE_STAGE.cnxi_new_external_cust_num AS new_ext
    )
    ;

    
    CREATE OR REPLACE TABLE STANDARDIZE_STAGE.CUST_NUM_INDIVIDUAL_XREF
    (
        INDIVIDUAL_ID           NUMBER(38,0)
    ,   CUST_NUM                NUMBER(38,0)
    ,   REC_TYPE                VARCHAR(50)
    ,   CREATE_DATE             TIMESTAMP_NTZ
    ,   CREATE_FEED_INSTANCE_ID NUMBER(38,0)
    )
    ;


    INSERT INTO STANDARDIZE_STAGE.CUST_NUM_INDIVIDUAL_XREF ( INDIVIDUAL_ID, CUST_NUM, REC_TYPE, CREATE_DATE, CREATE_FEED_INSTANCE_ID )
    SELECT
        INDIVIDUAL_ID
    ,   CUST_NUM
    ,   REC_TYPE
    ,   CURRENT_TIMESTAMP   AS CREATE_DATE
    ,   FEED_INSTANCE_ID
    FROM
    (
        SELECT INDIVIDUAL_ID, CUST_NUM, REC_TYPE, FEED_INSTANCE_ID
        FROM STANDARDIZE_STAGE.cnxi_new_external_cust_num

        UNION

        SELECT INDIVIDUAL_ID, CUST_NUM, REC_TYPE, FEED_INSTANCE_ID
        FROM STANDARDIZE_STAGE.cnxi_merged_external_cust_num

        UNION

        SELECT INDIVIDUAL_ID, CUST_NUM, REC_TYPE, FEED_INSTANCE_ID
        FROM STANDARDIZE_STAGE.cnxi_new_cdp_cust_num
    ) AS t
    ;


    IF ( EXISTS ( SELECT 1 FROM STANDARDIZE_STAGE.CUST_NUM_INDIVIDUAL_XREF GROUP BY CUST_NUM HAVING COUNT(1) > 1 ) ) THEN
        RAISE ex_duplicate_cust_num_02;
    END IF;

    IF ( EXISTS ( SELECT 1 FROM STANDARDIZE_STAGE.CUST_NUM_INDIVIDUAL_XREF GROUP BY INDIVIDUAL_ID HAVING COUNT(1) > 1 ) ) THEN
        RAISE ex_duplicate_ind_id_02;
    END IF;    


    IF ( EXISTS (
        SELECT 1
        FROM ( 
            SELECT CUST_NUM FROM STANDARDIZE_STAGE.CUST_NUM_INDIVIDUAL_XREF
            UNION ALL
            SELECT CUST_NUM FROM STANDARDIZE_CORE.CUST_NUM_INDIVIDUAL_XREF
        ) t
        GROUP BY CUST_NUM HAVING COUNT(1) > 1    
    ) ) THEN
        RAISE ex_duplicate_cust_num_03;
    END IF;
    

    IF ( EXISTS (
        SELECT 1
        FROM ( 
            SELECT INDIVIDUAL_ID FROM STANDARDIZE_STAGE.CUST_NUM_INDIVIDUAL_XREF
            UNION ALL
            SELECT INDIVIDUAL_ID FROM STANDARDIZE_CORE.CUST_NUM_INDIVIDUAL_XREF
        ) t
        GROUP BY INDIVIDUAL_ID HAVING COUNT(1) > 1    
    ) ) THEN
        RAISE ex_duplicate_ind_id_03;
    END IF;


    IF ( EXISTS (
        SELECT 1
        FROM STANDARDIZE_STAGE.CUST_NUM_INDIVIDUAL_XREF
        WHERE CUST_NUM NOT BETWEEN 500000000 AND 599999999
        AND REC_TYPE = ''new_cdp_cust_num''
    ) ) THEN
        RAISE ex_cust_num_out_of_range;
    END IF;


    MERGE INTO STANDARDIZE_CORE.CUST_NUM_INDIVIDUAL_XREF AS tgt
    USING STANDARDIZE_STAGE.CUST_NUM_INDIVIDUAL_XREF src
    ON tgt.INDIVIDUAL_ID = IFNULL(src.INDIVIDUAL_ID,0)
    OR tgt.CUST_NUM = IFNULL(src.CUST_NUM,0)      -- ADDED TO PREVENT CUST_NUM DUPLICATES
    WHEN NOT MATCHED THEN
        INSERT ( INDIVIDUAL_ID, CUST_NUM, CREATE_DATE, REC_TYPE, CREATE_FEED_INSTANCE_ID )
        VALUES ( INDIVIDUAL_ID, CUST_NUM, CREATE_DATE, REC_TYPE, CREATE_FEED_INSTANCE_ID )
    ;

    COMMIT;

    RETURN ''SUCCESS'';

EXCEPTION
    WHEN OTHER THEN
    
        ROLLBACK;
        
        CREATE OR REPLACE TABLE STANDARDIZE_STAGE.cnxi_new_ind_debug AS
        SELECT DISTINCT INDIVIDUAL_ID FROM STANDARDIZE_CORE.PARTY_PROFILE
        EXCEPT
        SELECT INDIVIDUAL_ID FROM STANDARDIZE_CORE.CUST_NUM_INDIVIDUAL_XREF
        ;
        
        RAISE;
END
$$