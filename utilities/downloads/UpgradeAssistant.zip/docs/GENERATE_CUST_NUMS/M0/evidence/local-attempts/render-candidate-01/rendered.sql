-- M0 ISOLATED ONLY. Stop on the first SQL error. No production execution.
EXECUTE IMMEDIATE $$
DECLARE bad_environment EXCEPTION (-20990, 'M0 environment guard failed');
BEGIN
  IF (CURRENT_ACCOUNT() <> 'REPLACE_ACCOUNT_LOCATOR' OR
      CURRENT_DATABASE() <> 'M0_CUST_NUM_REPLACE_CANDIDATE' OR
      CURRENT_ROLE() <> 'REPLACE_OWNER_OR_CALLER_ROLE' OR
      CURRENT_WAREHOUSE() <> 'REPLACE_TEST_WAREHOUSE') THEN
    RAISE bad_environment;
  END IF;
  RETURN 'M0_ENVIRONMENT_OK';
END;
$$;
-- M0_STATEMENT
USE SCHEMA M0_CUST_NUM_REPLACE_CANDIDATE.STANDARDIZE_STAGE;
-- M0_STATEMENT
-- M0 transaction/entry prototype ONLY. No customer allocator is implemented.
-- The runner enforces AUTOCOMMIT and LOCK_TIMEOUT outside the owner scope.
-- Direct-call enforcement remains an explicit M0 gap; see STATUS.md.
CREATE PROCEDURE STANDARDIZE_STAGE.GENERATE_CUST_NUMS_M0(
  FEED_INSTANCE_ID NUMBER(38,0), AUTOMATION_GUID VARCHAR(36), PREVIEW BOOLEAN)
RETURNS VARCHAR LANGUAGE SQL EXECUTE AS OWNER AS $$
DECLARE
  bad_entry EXCEPTION (-20970, 'M0 explicit inputs and no caller transaction required');
  bad_gate EXCEPTION (-20971, 'M0 exactly one control row required');
  primary_failure EXCEPTION (-20972, 'M0 primary fault');
  rollback_failure EXCEPTION (-20973, 'M0 simulated rollback-handler fault');
  bad_fixture EXCEPTION (-20974, 'M0 isolated fixture precondition failed');
  run_id NUMBER := FEED_INSTANCE_ID;
  mode_value VARCHAR := IFF(PREVIEW,'PREVIEW','LIVE');
  owns_tx BOOLEAN := FALSE;
  applied BOOLEAN := FALSE;
  committed BOOLEAN := FALSE;
  commit_started BOOLEAN := FALSE;
  log_created BOOLEAN := FALSE;
  n NUMBER;
  observed NUMBER;
  hold_seconds NUMBER;
  fail_at VARCHAR;
  secondary_fail BOOLEAN;
  rollback_fault BOOLEAN;
  zero_work BOOLEAN;
  inject_log_failure BOOLEAN;
  stage_name VARCHAR := 'ENTRY';
  original_code NUMBER;
  original_state VARCHAR;
  original_message VARCHAR;
  original_stage VARCHAR;
  persistence_value VARCHAR := 'NOT_ATTEMPTED';
  metrics_value VARIANT;
BEGIN
  -- No transaction control or business reads precede this entry rejection.
  IF (FEED_INSTANCE_ID IS NULL OR AUTOMATION_GUID IS NULL OR AUTOMATION_GUID = '' OR
      PREVIEW IS NULL OR CURRENT_TRANSACTION() IS NOT NULL) THEN RAISE bad_entry; END IF;
  SELECT COUNT(*) INTO :n FROM STANDARDIZE_AUDIT.M0_ENVIRONMENT WHERE MARKER='CUST_NUM_M0_20261019';
  IF (n <> 1 OR NOT STARTSWITH(CURRENT_DATABASE(),'M0_CUST_NUM_')) THEN RAISE bad_fixture; END IF;
  SELECT COUNT(*) INTO :n FROM STANDARDIZE_STAGE.M0_SCENARIO WHERE RUN_ID=:run_id;
  IF (n <> 1) THEN RAISE bad_fixture; END IF;
  SELECT HOLD_SECONDS,FAIL_AT,SECONDARY_LOG_FAIL,SIMULATE_ROLLBACK_ERROR,ZERO_WORK
    INTO :hold_seconds,:fail_at,:secondary_fail,:rollback_fault,:zero_work
    FROM STANDARDIZE_STAGE.M0_SCENARIO WHERE RUN_ID=:run_id;
  metrics_value := OBJECT_CONSTRUCT_KEEP_NULL(
    'unmappedIndividuals',NULL,'externalAssignments',NULL,'generatedAssignments',NULL,'reservationCount',NULL,
    'generatedSeed',NULL,'maxGeneratedValue',NULL,'generatedCapacityRemaining',NULL,
    'persistence','NOT_ATTEMPTED','validation',OBJECT_CONSTRUCT('status','NOT_RUN','issues',
      ARRAY_CONSTRUCT(OBJECT_CONSTRUCT_KEEP_NULL('checkId','M0_WRAPPER_COMPLETION','status','NOT_RUN','affectedCount',NULL))));
  inject_log_failure := fail_at='INITIAL_LOG';
  CALL STANDARDIZE_AUDIT.M0_WRITE_LOG(:run_id,:AUTOMATION_GUID,:mode_value,:metrics_value,TRUE,:inject_log_failure);
  log_created := TRUE;
  stage_name := 'GATE';
  BEGIN TRANSACTION;
  owns_tx := TRUE;
  UPDATE STANDARDIZE_AUDIT.CUST_NUM_PROCESS SET LAST_RUN_ID=:run_id,LOCK_ACQUIRED_AT=CURRENT_TIMESTAMP()
    WHERE PROCESS_NAME='GENERATE_CUST_NUMS';
  n := SQLROWCOUNT;
  IF (n <> 1) THEN RAISE bad_gate; END IF;
  stage_name := 'STARTUP_TRUNCATE';
  TRUNCATE TABLE STANDARDIZE_STAGE.M0_WORK;
  IF (fail_at='AFTER_TRUNCATE') THEN RAISE primary_failure; END IF;
  stage_name := 'PREPARE';
  SELECT VALUE INTO :observed FROM STANDARDIZE_CORE.M0_BUSINESS WHERE ID=1;
  INSERT INTO STANDARDIZE_STAGE.M0_WORK VALUES (:run_id,:observed);
  -- No real assignment/reservation plan exists in M0; leave its metrics unknown.
  IF (NOT PREVIEW AND NOT zero_work) THEN
    stage_name := 'IN_PROGRESS_LOG';
    metrics_value := OBJECT_INSERT(metrics_value,'persistence','IN_PROGRESS',TRUE);
    inject_log_failure := fail_at='IN_PROGRESS_LOG';
    CALL STANDARDIZE_AUDIT.M0_WRITE_LOG(:run_id,:AUTOMATION_GUID,:mode_value,:metrics_value,FALSE,:inject_log_failure);
  END IF;
  -- B must still block here: truncate and independent logging must not release A's gate.
  IF (hold_seconds > 0) THEN CALL SYSTEM$WAIT(:hold_seconds,'SECONDS'); END IF;
  IF (fail_at='BEFORE_APPLY') THEN RAISE primary_failure; END IF;
  IF (NOT PREVIEW AND NOT zero_work) THEN
    stage_name := 'BUSINESS_MARKER';
    UPDATE STANDARDIZE_CORE.M0_BUSINESS SET VALUE=:observed+1,LAST_RUN_ID=:run_id WHERE ID=1;
    n := SQLROWCOUNT;
    IF (n <> 1) THEN RAISE bad_fixture; END IF;
    applied := TRUE;
    IF (fail_at='AFTER_APPLY') THEN RAISE primary_failure; END IF;
  END IF;
  stage_name := 'CLEANUP';
  IF (fail_at='CLEANUP') THEN RAISE primary_failure; END IF;
  DELETE FROM STANDARDIZE_STAGE.M0_WORK WHERE RUN_ID=:run_id;
  IF (PREVIEW) THEN
    ROLLBACK;
  ELSE
    stage_name := 'COMMIT';
    commit_started := TRUE;
    COMMIT;
    committed := TRUE;
  END IF;
  owns_tx := FALSE;
  persistence_value := IFF(applied,'COMMITTED','NOT_ATTEMPTED');
  metrics_value := OBJECT_INSERT(metrics_value,'persistence',persistence_value,TRUE);
  -- M0 transaction success does not certify allocator checks. These stay NOT_RUN.
  stage_name := 'FINAL_LOG';
  inject_log_failure := fail_at='FINAL_LOG';
  CALL STANDARDIZE_AUDIT.M0_WRITE_LOG(:run_id,:AUTOMATION_GUID,:mode_value,:metrics_value,FALSE,:inject_log_failure);
  RETURN 'SUCCESS'; -- prototype mechanics only; never an allocator qualification claim
EXCEPTION WHEN OTHER THEN
  original_code := SQLCODE;
  original_state := SQLSTATE;
  original_message := SQLERRM;
  original_stage := stage_name;
  IF (committed) THEN
    persistence_value := IFF(applied,'COMMITTED','NOT_ATTEMPTED');
  ELSEIF (owns_tx) THEN
    persistence_value := IFF(commit_started,'UNKNOWN',IFF(applied,'UNKNOWN','NOT_ATTEMPTED'));
    BEGIN
      IF (rollback_fault) THEN RAISE rollback_failure; END IF;
      ROLLBACK;
      owns_tx := FALSE;
      IF (NOT commit_started) THEN persistence_value := IFF(applied,'ROLLED_BACK','NOT_ATTEMPTED'); END IF;
    EXCEPTION WHEN OTHER THEN NULL;
    END;
  END IF;
  -- If rollback outcome is unknown, do not erase uncertainty with a success claim.
  IF (log_created) THEN
    BEGIN
      metrics_value := OBJECT_INSERT(metrics_value,'persistence',persistence_value,TRUE);
      metrics_value := OBJECT_INSERT(metrics_value,'validation',OBJECT_CONSTRUCT('status','FAIL','issues',
        ARRAY_CONSTRUCT(OBJECT_CONSTRUCT_KEEP_NULL('checkId','M0_WRAPPER_COMPLETION','status','FAIL','affectedCount',NULL))),TRUE);
      CALL STANDARDIZE_AUDIT.M0_WRITE_LOG(:run_id,:AUTOMATION_GUID,:mode_value,:metrics_value,FALSE,:secondary_fail);
    EXCEPTION WHEN OTHER THEN NULL;
    END;
  END IF;
  RAISE; -- preserve the original SQL exception, including after secondary failures
END;
$$;
