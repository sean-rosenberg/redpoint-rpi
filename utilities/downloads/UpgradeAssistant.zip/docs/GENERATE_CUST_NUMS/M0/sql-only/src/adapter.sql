-- Procedure-specific SQL caller example; not a deployed RPDM framework change.
DECLARE
  v_result VARIANT;
  v_status VARCHAR;
  v_error VARCHAR;
  v_stage VARCHAR;
  v_bad_contract EXCEPTION (-20978,'Missing or invalid JSON outcome from procedure');
BEGIN
  CALL @DB@.STANDARDIZE_STAGE.@P@GENERATE_CUST_NUMS_PROTOTYPE(:P_FEED,:P_GUID,:P_PREVIEW,:v_result);
  IF (v_result IS NULL OR COALESCE(v_result:contractVersion::NUMBER<>2,TRUE)
      OR COALESCE(v_result:status::VARCHAR NOT IN ('SUCCESS','ERROR'),TRUE)
      OR COALESCE(v_result:persistence::VARCHAR NOT IN ('NOT_ATTEMPTED','COMMITTED','ROLLED_BACK','UNKNOWN'),TRUE)) THEN RAISE v_bad_contract; END IF;
  v_status := v_result:status::VARCHAR;
  v_stage := v_result:stage::VARCHAR;
  v_error := IFF(v_status='ERROR',LEFT(TO_JSON(v_result),4000),NULL);
  -- Caller persists outcome AFTER the procedure has closed its business transaction.
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@AUTOMATION_LOG SET AUTOMATION_STATUS=:v_status,
    END_DATE=CURRENT_TIMESTAMP(),LAST_ERROR_STEP_NAME=IFF(:v_status='ERROR',:v_stage,NULL),LAST_ERROR=:v_error
    WHERE AUTOMATION_GUID=:P_GUID;
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@FEED_INSTANCE SET FEED_PROCESS_RESULT=:v_status,FEED_END_DATE=CURRENT_TIMESTAMP()
    WHERE FEED_INSTANCE_ID=:P_FEED AND AUTOMATION_GUID=:P_GUID;
  IF (v_status='ERROR') THEN
    INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@CALLER_ACTION SELECT :P_FEED,
      IFF(:v_result:persistence::VARCHAR IN ('COMMITTED','UNKNOWN'),'RECONCILE','STOP'),:v_result,CURRENT_TIMESTAMP();
    RESULT := v_result;
    RETURN 'ERROR'; -- exits before the simulated downstream-success branch
  END IF;
  INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@CALLER_ACTION VALUES (:P_FEED,'CONTINUE',:v_result,CURRENT_TIMESTAMP());
  RESULT := v_result;
  -- RPDM must branch on RESULT:status. ERROR stops downstream work.
  -- COMMITTED/UNKNOWN errors require reconciliation; never blindly retry allocation.
  RETURN v_status;
END;
