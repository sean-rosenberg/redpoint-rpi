-- M0 JSON/serialization prototype. It NEVER allocates customer numbers.
DECLARE
  bad_entry EXCEPTION (-20970,'M0 explicit non-null inputs and no caller transaction required');
  bad_gate EXCEPTION (-20971,'M0 exactly one generation gate row required');
  controlled_error EXCEPTION (-20972,'M0 controlled business-marker error');
  bad_fixture EXCEPTION (-20974,'M0 fixture or environment marker invalid');
  v_stage VARCHAR := 'ENTRY';
  v_mode VARCHAR := IFF(PREVIEW,'PREVIEW','LIVE');
  v_owns_tx BOOLEAN := FALSE;
  v_applied BOOLEAN := FALSE;
  v_committed BOOLEAN := FALSE;
  v_commit_started BOOLEAN := FALSE;
  v_persistence VARCHAR := 'NOT_ATTEMPTED';
  v_n NUMBER;
  v_observed NUMBER;
  v_hold NUMBER;
  v_fail BOOLEAN;
  v_zero BOOLEAN;
  v_requested TIMESTAMP_LTZ;
  v_acquired TIMESTAMP_LTZ;
  v_release_started TIMESTAMP_LTZ;
  v_released TIMESTAMP_LTZ;
  v_result VARIANT;
  v_error VARIANT;
BEGIN
  RESULT := NULL;
  IF (FEED_INSTANCE_ID IS NULL OR AUTOMATION_GUID IS NULL OR AUTOMATION_GUID=''
      OR PREVIEW IS NULL OR CURRENT_TRANSACTION() IS NOT NULL) THEN RAISE bad_entry; END IF;
  SELECT COUNT(*) INTO :v_n FROM @DB@.STANDARDIZE_AUDIT.@P@ENVIRONMENT
    WHERE PACKAGE_VERSION='M0-SQL-ONLY-2' AND DATABASE_NAME='@DB@' AND OBJECT_PREFIX='@P@';
  IF (v_n<>1) THEN RAISE bad_fixture; END IF;
  SELECT COUNT(*) INTO :v_n FROM @DB@.STANDARDIZE_STAGE.@P@SCENARIO s
    WHERE s.FEED_INSTANCE_ID=:FEED_INSTANCE_ID;
  IF (v_n<>1) THEN RAISE bad_fixture; END IF;
  SELECT HOLD_SECONDS,FAIL_AFTER_APPLY,ZERO_WORK INTO :v_hold,:v_fail,:v_zero
    FROM @DB@.STANDARDIZE_STAGE.@P@SCENARIO s WHERE s.FEED_INSTANCE_ID=:FEED_INSTANCE_ID;
  IF (v_hold<0 OR v_hold>30) THEN RAISE bad_fixture; END IF;
  v_stage := 'GATE';
  v_requested := CURRENT_TIMESTAMP();
  BEGIN TRANSACTION;
  v_owns_tx := TRUE;
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@CUST_NUM_PROCESS SET LAST_RUN_ID=:FEED_INSTANCE_ID
    WHERE PROCESS_NAME='GENERATE_CUST_NUMS';
  v_n := SQLROWCOUNT;
  IF (v_n<>1) THEN RAISE bad_gate; END IF;
  v_acquired := CURRENT_TIMESTAMP();
  v_stage := 'PREPARE';
  TRUNCATE TABLE @DB@.STANDARDIZE_STAGE.@P@PROTOTYPE_WORK;
  SELECT VALUE INTO :v_observed FROM @DB@.STANDARDIZE_CORE.@P@PROTOTYPE_BUSINESS WHERE ID=1;
  INSERT INTO @DB@.STANDARDIZE_STAGE.@P@PROTOTYPE_WORK VALUES (:FEED_INSTANCE_ID,:v_observed);
  -- Audit-only scoped transaction is in the serialized path; no failure injection here.
  v_stage := 'IN_PROGRESS_LOG';
  v_result := OBJECT_CONSTRUCT('status','IN_PROGRESS','scope','M0_PROTOTYPE',
    'sessionId',CURRENT_SESSION(),'gateAcquiredAt',v_acquired,'observedValue',v_observed);
  CALL @DB@.STANDARDIZE_STAGE.@P@WRITE_PROTOTYPE_LOG(:FEED_INSTANCE_ID,:v_result);
  IF (v_hold>0) THEN CALL SYSTEM$WAIT(:v_hold,'SECONDS'); END IF;
  v_stage := 'BUSINESS_MARKER';
  IF (NOT PREVIEW AND NOT v_zero) THEN
    UPDATE @DB@.STANDARDIZE_CORE.@P@PROTOTYPE_BUSINESS SET VALUE=:v_observed+1 WHERE ID=1;
    v_applied := TRUE;
  END IF;
  IF (v_fail) THEN RAISE controlled_error; END IF;
  DELETE FROM @DB@.STANDARDIZE_STAGE.@P@PROTOTYPE_WORK WHERE RUN_ID=:FEED_INSTANCE_ID;
  v_stage := 'COMPLETE_TRANSACTION';
  v_release_started := CURRENT_TIMESTAMP();
  IF (PREVIEW) THEN ROLLBACK;
  ELSE
    v_commit_started := TRUE;
    COMMIT;
    v_committed := TRUE;
  END IF;
  v_owns_tx := FALSE;
  v_released := CURRENT_TIMESTAMP();
  v_persistence := IFF(v_applied,'COMMITTED','NOT_ATTEMPTED');
  v_result := OBJECT_CONSTRUCT_KEEP_NULL('contractVersion',2,'scope','M0_PROTOTYPE',
    'feedInstanceId',FEED_INSTANCE_ID,'automationGuid',AUTOMATION_GUID,'mode',v_mode,
    'status','SUCCESS','persistence',v_persistence,'stage','COMPLETE','error',NULL,'action','CONTINUE',
    'prototypeEvidence',OBJECT_CONSTRUCT_KEEP_NULL('sessionId',CURRENT_SESSION(),'observedValue',v_observed,
      'requestedAt',v_requested,'gateAcquiredAt',v_acquired,'releaseStartedAt',v_release_started,'releasedAt',v_released));
  v_stage := 'FINAL_LOG';
  CALL @DB@.STANDARDIZE_STAGE.@P@WRITE_PROTOTYPE_LOG(:FEED_INSTANCE_ID,:v_result);
  RESULT := v_result;
  RETURN 'SUCCESS';
EXCEPTION WHEN OTHER THEN
  -- Capture first; any rollback/logging error must not overwrite this error.
  v_error := OBJECT_CONSTRUCT('sqlcode',SQLCODE,'sqlstate',SQLSTATE,'message',SQLERRM,'stage',v_stage);
  IF (v_committed) THEN v_persistence := IFF(v_applied,'COMMITTED','NOT_ATTEMPTED');
  ELSEIF (v_owns_tx) THEN
    v_persistence := IFF(v_applied OR v_commit_started,'UNKNOWN','NOT_ATTEMPTED');
    BEGIN
      v_release_started := CURRENT_TIMESTAMP();
      ROLLBACK;
      v_owns_tx := FALSE;
      v_released := CURRENT_TIMESTAMP();
      IF (NOT v_commit_started) THEN v_persistence := IFF(v_applied,'ROLLED_BACK','NOT_ATTEMPTED'); END IF;
    EXCEPTION WHEN OTHER THEN NULL;
    END;
  END IF;
  v_result := OBJECT_CONSTRUCT_KEEP_NULL('contractVersion',2,'scope','M0_PROTOTYPE',
    'feedInstanceId',FEED_INSTANCE_ID,'automationGuid',AUTOMATION_GUID,'mode',IFF(PREVIEW IS NULL,NULL,v_mode),
    'status','ERROR','persistence',v_persistence,'stage',v_stage,'error',v_error,
    'action',IFF(v_persistence IN ('COMMITTED','UNKNOWN'),'RECONCILE','STOP'),
    'prototypeEvidence',OBJECT_CONSTRUCT_KEEP_NULL('sessionId',CURRENT_SESSION(),'observedValue',v_observed,
      'requestedAt',v_requested,'gateAcquiredAt',v_acquired,'releaseStartedAt',v_release_started,'releasedAt',v_released));
  IF (FEED_INSTANCE_ID IS NOT NULL) THEN
    BEGIN
      CALL @DB@.STANDARDIZE_STAGE.@P@WRITE_PROTOTYPE_LOG(:FEED_INSTANCE_ID,:v_result);
    EXCEPTION WHEN OTHER THEN NULL;
    END;
  END IF;
  RESULT := v_result;
  RETURN 'ERROR';
END;
