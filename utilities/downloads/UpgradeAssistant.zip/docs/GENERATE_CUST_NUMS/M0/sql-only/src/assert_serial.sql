DECLARE
  v_run VARCHAR := $Q_SERIAL_RUN_ID;
  v_a VARIANT; v_b VARIANT;
  v_kind VARCHAR; v_initial NUMBER; v_final NUMBER;
  v_ok BOOLEAN := FALSE; v_n NUMBER;
  v_bad EXCEPTION (-20994,'Unknown pair or workers unfinished; save evidence before preparing another pair');
BEGIN
  SELECT COUNT(*) INTO :v_n FROM @DB@.STANDARDIZE_AUDIT.@P@SERIAL_PAIR WHERE RUN_ID=:v_run;
  IF (v_n<>1) THEN RAISE v_bad; END IF;
  SELECT COUNT(*) INTO :v_n FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT
    WHERE RUN_ID=:v_run AND TEST_ID IN ('SERIAL-A','SERIAL-B') AND STATUS IN ('NOT_RUN','RUNNING');
  IF (v_n<>0) THEN RAISE v_bad; END IF;
  SELECT PAIR_KIND,INITIAL_VALUE INTO :v_kind,:v_initial FROM @DB@.STANDARDIZE_AUDIT.@P@SERIAL_PAIR WHERE RUN_ID=:v_run;
  SELECT COUNT(*) INTO :v_n FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=:v_run AND TEST_ID='SERIAL-'||:v_kind;
  IF (v_n<>0) THEN RAISE v_bad; END IF;
  SELECT ACTUAL INTO :v_a FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=:v_run AND TEST_ID='SERIAL-A';
  SELECT ACTUAL INTO :v_b FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=:v_run AND TEST_ID='SERIAL-B';
  SELECT VALUE INTO :v_final FROM @DB@.STANDARDIZE_CORE.@P@PROTOTYPE_BUSINESS WHERE ID=1;
  -- releaseStartedAt is captured immediately before COMMIT/ROLLBACK. The timestamp
  -- after release can race with B acquiring; do not assert the wrong timestamp order.
  v_ok := COALESCE(
    v_a:prototypeEvidence:sessionId::NUMBER<>v_b:prototypeEvidence:sessionId::NUMBER
    AND v_b:prototypeEvidence:requestedAt::TIMESTAMP_LTZ>=v_a:prototypeEvidence:gateAcquiredAt::TIMESTAMP_LTZ
    AND v_b:prototypeEvidence:requestedAt::TIMESTAMP_LTZ<v_a:prototypeEvidence:releaseStartedAt::TIMESTAMP_LTZ
    AND v_b:prototypeEvidence:gateAcquiredAt::TIMESTAMP_LTZ>=v_a:prototypeEvidence:releaseStartedAt::TIMESTAMP_LTZ
    AND v_a:prototypeEvidence:observedValue::NUMBER=v_initial
    AND v_b:prototypeEvidence:observedValue::NUMBER=v_initial+IFF(v_kind='COMMIT',1,0)
    AND v_final=v_initial+IFF(v_kind='COMMIT',2,1)
    AND v_b:status::VARCHAR='SUCCESS' AND v_b:persistence::VARCHAR='COMMITTED'
    AND ((v_kind='COMMIT' AND v_a:status::VARCHAR='SUCCESS' AND v_a:persistence::VARCHAR='COMMITTED')
      OR (v_kind='ROLLBACK' AND v_a:status::VARCHAR='ERROR' AND v_a:error:sqlcode::NUMBER=-20972 AND v_a:persistence::VARCHAR='ROLLED_BACK')
      OR (v_kind='PREVIEW' AND v_a:status::VARCHAR='SUCCESS' AND v_a:persistence::VARCHAR='NOT_ATTEMPTED')),FALSE);
  INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT
    (RUN_ID,TEST_ID,DISPOSITION,STATUS,STARTED_AT,FINISHED_AT,PHASE,ACTUAL,ASSERTION_PASS)
    SELECT :v_run,'SERIAL-'||:v_kind,'REQUIRED',IFF(:v_ok,'PASS','FAIL'),CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),'ASSERT',
      OBJECT_CONSTRUCT_KEEP_NULL('a',:v_a,'b',:v_b,'initialValue',:v_initial,'finalValue',:v_final),:v_ok;
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RUN SET FINISHED_AT=CURRENT_TIMESTAMP(),RUN_STATUS=IFF(:v_ok,'PASS','FAIL') WHERE RUN_ID=:v_run;
  RETURN OBJECT_CONSTRUCT('runId',v_run,'checkId','SERIAL-'||v_kind,'status',IFF(v_ok,'PASS','FAIL'));
END;
