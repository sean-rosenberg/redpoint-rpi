### JSON outcome and caller actions

The target signature is `GENERATE_CUST_NUMS(FEED_INSTANCE_ID NUMBER(38,0), AUTOMATION_GUID VARCHAR(36), PREVIEW BOOLEAN, RESULT OUT VARIANT) RETURNS VARCHAR`. No arguments have defaults. The scalar return mirrors `RESULT:status`; callers must inspect the JSON. The JSON is an outcome envelope, separate from the existing compact process metrics; it does not add metric columns or rule-specific sample storage.

| Field | Contract |
| --- | --- |
| `contractVersion` | Integer `2`. |
| `scope` | `ALLOCATOR` for the future implementation; `M0_PROTOTYPE` for the harmless M0 mechanics prototype. |
| `feedInstanceId`, `automationGuid` | Exact supplied identity. A rejected null input remains JSON null. Generation invents neither identity. |
| `mode` | `PREVIEW` or `LIVE`; null when the supplied mode is invalid. |
| `status` | `SUCCESS` only when the requested operation and required checks/reporting complete; otherwise `ERROR` for a handled failure. |
| `persistence` | `NOT_ATTEMPTED`, `COMMITTED`, `ROLLED_BACK`, or `UNKNOWN`, describing business changes. Never infer rollback from an error status. Successful preview uses `NOT_ATTEMPTED`. |
| `stage` | Completion or the stage where the original failure occurred. |
| `error` | Explicit JSON null on success; otherwise `{sqlcode, sqlstate, message, stage}` captured before rollback/reporting. Preserve original values, including negative application codes. |
| `action` | `CONTINUE` on success; `STOP` on an error with no committed changes; `RECONCILE` for errors with `COMMITTED` or `UNKNOWN` persistence. Neither error action authorizes an automatic retry. |

The caller receives the OUT value in a local Snowflake Scripting variable, persists the outcome to the existing automation/feed audit fields, and branches on status. `ERROR` must stop downstream processing even though the CALL completed normally. If RPDM requires a SQL exception to mark the step failed, its procedure-specific SQL adapter must first persist the original JSON details and then raise a caller-level failure. That raised code need not equal the original SQLCODE; the retained JSON/audit values remain the original diagnostic evidence. Do not rely on OUT values surviving a rethrow from the allocating procedure.

The outer caller also catches SQL failures when the procedure cannot return a valid JSON object, including compilation/invocation errors. A missing, invalid, or unknown-version outcome is a failure, never implicit success. A lost connection or terminated session may leave a run incomplete; absence of an error result is not success. Full JSON is retained in qualification evidence; the mock `LAST_ERROR` is limited to its existing 4000 characters. Actual RPDM binding/status integration remains to be verified before cutover; no deployed RPDM modification is claimed.

Snowflake SQL procedures support OUT arguments passed through scripting variables; session variables cannot themselves be OUT arguments. [Snowflake output argument documentation](https://docs.snowflake.com/en/developer-guide/stored-procedure/stored-procedures-snowflake-scripting#using-output-arguments-to-return-values)

The M0 prototype adds `prototypeEvidence` with session IDs, gate timestamps, and a synthetic counter observation exclusively for serialization evidence. This is not a new production reporting requirement. Success from this prototype does not certify assignment, reservation, migration, or allocator validation behavior.
