-- Generated locally; Snowflake compilation/execution NOT_RUN. See README.md.
EXECUTE IMMEDIATE $$
DECLARE
  v_db VARCHAR := $Q_DATABASE;
  v_prefix VARCHAR := $Q_PREFIX;
  v_account VARCHAR := $Q_ACCOUNT;
  v_ack VARCHAR := $Q_ACK;
  v_sql VARCHAR;
  v_n NUMBER;
  v_guard EXCEPTION (-20990, 'Qualification guard failed: check account, database, prefix, marker, and caller transaction');
  v_step VARCHAR;
  v_query VARCHAR;
  v_error VARIANT;
  v_artifacts VARCHAR := v_db || '.STANDARDIZE_AUDIT.' || v_prefix || 'ARTIFACT';
BEGIN
  IF (v_db IS NULL OR v_prefix IS NULL OR v_account IS NULL OR v_ack IS NULL
      OR NOT REGEXP_LIKE(v_db, '^[A-Z][A-Z0-9_]*$')
      OR NOT REGEXP_LIKE(v_prefix, '^M[0-9]+_$')
      OR v_account <> CURRENT_ACCOUNT() OR v_db <> CURRENT_DATABASE()
      OR v_ack <> 'ISOLATED_PREFIX_FIXTURES_ONLY'
      OR CURRENT_TRANSACTION() IS NOT NULL) THEN RAISE v_guard; END IF;
  LET v_marker VARCHAR := v_db || '.STANDARDIZE_AUDIT.' || v_prefix || 'ENVIRONMENT';
  SELECT COUNT(*) INTO :v_n FROM IDENTIFIER(:v_marker) WHERE PACKAGE_VERSION = 'M0-SQL-ONLY-2' AND DATABASE_NAME = :v_db AND OBJECT_PREFIX = :v_prefix AND ACCOUNT_NAME = :v_account;
  IF (v_n <> 1) THEN RAISE v_guard; END IF;
  v_step := 'PROTOTYPE_GATE';
  v_sql := REPLACE(REPLACE('CREATE TABLE @DB@.STANDARDIZE_AUDIT.@P@CUST_NUM_PROCESS (PROCESS_NAME VARCHAR, LAST_RUN_ID NUMBER);', '@DB@', v_db), '@P@', v_prefix);
  INSERT INTO IDENTIFIER(:v_artifacts) SELECT UUID_STRING(),CURRENT_TIMESTAMP(),'DEPLOY_'||:v_step,'RUNNING',:v_sql,SHA2(:v_sql,256),NULL,NULL;
  BEGIN
    EXECUTE IMMEDIATE :v_sql;
    v_query := SQLID;
    UPDATE IDENTIFIER(:v_artifacts) SET STATUS='PASS',QUERY_ID=:v_query WHERE KIND='DEPLOY_'||:v_step AND STATUS='RUNNING';
  EXCEPTION WHEN OTHER THEN
    v_error := OBJECT_CONSTRUCT('sqlcode',SQLCODE,'sqlstate',SQLSTATE,'message',SQLERRM);
    UPDATE IDENTIFIER(:v_artifacts) SET STATUS='FAIL',ERROR=:v_error WHERE KIND='DEPLOY_'||:v_step AND STATUS='RUNNING';
    RETURN 'DEPLOYMENT_FAILED: '||v_step||'. Run 06_export_evidence.sql; use a fresh prefix for a corrected attempt.';
  END;
  v_step := 'GATE_SEED';
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@CUST_NUM_PROCESS VALUES (''GENERATE_CUST_NUMS'',NULL);', '@DB@', v_db), '@P@', v_prefix);
  INSERT INTO IDENTIFIER(:v_artifacts) SELECT UUID_STRING(),CURRENT_TIMESTAMP(),'DEPLOY_'||:v_step,'RUNNING',:v_sql,SHA2(:v_sql,256),NULL,NULL;
  BEGIN
    EXECUTE IMMEDIATE :v_sql;
    v_query := SQLID;
    UPDATE IDENTIFIER(:v_artifacts) SET STATUS='PASS',QUERY_ID=:v_query WHERE KIND='DEPLOY_'||:v_step AND STATUS='RUNNING';
  EXCEPTION WHEN OTHER THEN
    v_error := OBJECT_CONSTRUCT('sqlcode',SQLCODE,'sqlstate',SQLSTATE,'message',SQLERRM);
    UPDATE IDENTIFIER(:v_artifacts) SET STATUS='FAIL',ERROR=:v_error WHERE KIND='DEPLOY_'||:v_step AND STATUS='RUNNING';
    RETURN 'DEPLOYMENT_FAILED: '||v_step||'. Run 06_export_evidence.sql; use a fresh prefix for a corrected attempt.';
  END;
  v_step := 'PROTOTYPE_BUSINESS';
  v_sql := REPLACE(REPLACE('CREATE TABLE @DB@.STANDARDIZE_CORE.@P@PROTOTYPE_BUSINESS (ID NUMBER, VALUE NUMBER);', '@DB@', v_db), '@P@', v_prefix);
  INSERT INTO IDENTIFIER(:v_artifacts) SELECT UUID_STRING(),CURRENT_TIMESTAMP(),'DEPLOY_'||:v_step,'RUNNING',:v_sql,SHA2(:v_sql,256),NULL,NULL;
  BEGIN
    EXECUTE IMMEDIATE :v_sql;
    v_query := SQLID;
    UPDATE IDENTIFIER(:v_artifacts) SET STATUS='PASS',QUERY_ID=:v_query WHERE KIND='DEPLOY_'||:v_step AND STATUS='RUNNING';
  EXCEPTION WHEN OTHER THEN
    v_error := OBJECT_CONSTRUCT('sqlcode',SQLCODE,'sqlstate',SQLSTATE,'message',SQLERRM);
    UPDATE IDENTIFIER(:v_artifacts) SET STATUS='FAIL',ERROR=:v_error WHERE KIND='DEPLOY_'||:v_step AND STATUS='RUNNING';
    RETURN 'DEPLOYMENT_FAILED: '||v_step||'. Run 06_export_evidence.sql; use a fresh prefix for a corrected attempt.';
  END;
  v_step := 'BUSINESS_SEED';
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_CORE.@P@PROTOTYPE_BUSINESS VALUES (1,0);', '@DB@', v_db), '@P@', v_prefix);
  INSERT INTO IDENTIFIER(:v_artifacts) SELECT UUID_STRING(),CURRENT_TIMESTAMP(),'DEPLOY_'||:v_step,'RUNNING',:v_sql,SHA2(:v_sql,256),NULL,NULL;
  BEGIN
    EXECUTE IMMEDIATE :v_sql;
    v_query := SQLID;
    UPDATE IDENTIFIER(:v_artifacts) SET STATUS='PASS',QUERY_ID=:v_query WHERE KIND='DEPLOY_'||:v_step AND STATUS='RUNNING';
  EXCEPTION WHEN OTHER THEN
    v_error := OBJECT_CONSTRUCT('sqlcode',SQLCODE,'sqlstate',SQLSTATE,'message',SQLERRM);
    UPDATE IDENTIFIER(:v_artifacts) SET STATUS='FAIL',ERROR=:v_error WHERE KIND='DEPLOY_'||:v_step AND STATUS='RUNNING';
    RETURN 'DEPLOYMENT_FAILED: '||v_step||'. Run 06_export_evidence.sql; use a fresh prefix for a corrected attempt.';
  END;
  v_step := 'PROTOTYPE_WORK';
  v_sql := REPLACE(REPLACE('CREATE TABLE @DB@.STANDARDIZE_STAGE.@P@PROTOTYPE_WORK (RUN_ID NUMBER, OBSERVED_VALUE NUMBER);', '@DB@', v_db), '@P@', v_prefix);
  INSERT INTO IDENTIFIER(:v_artifacts) SELECT UUID_STRING(),CURRENT_TIMESTAMP(),'DEPLOY_'||:v_step,'RUNNING',:v_sql,SHA2(:v_sql,256),NULL,NULL;
  BEGIN
    EXECUTE IMMEDIATE :v_sql;
    v_query := SQLID;
    UPDATE IDENTIFIER(:v_artifacts) SET STATUS='PASS',QUERY_ID=:v_query WHERE KIND='DEPLOY_'||:v_step AND STATUS='RUNNING';
  EXCEPTION WHEN OTHER THEN
    v_error := OBJECT_CONSTRUCT('sqlcode',SQLCODE,'sqlstate',SQLSTATE,'message',SQLERRM);
    UPDATE IDENTIFIER(:v_artifacts) SET STATUS='FAIL',ERROR=:v_error WHERE KIND='DEPLOY_'||:v_step AND STATUS='RUNNING';
    RETURN 'DEPLOYMENT_FAILED: '||v_step||'. Run 06_export_evidence.sql; use a fresh prefix for a corrected attempt.';
  END;
  v_step := 'SCENARIO';
  v_sql := REPLACE(REPLACE('CREATE TABLE @DB@.STANDARDIZE_STAGE.@P@SCENARIO (FEED_INSTANCE_ID NUMBER, HOLD_SECONDS NUMBER, FAIL_AFTER_APPLY BOOLEAN, ZERO_WORK BOOLEAN);', '@DB@', v_db), '@P@', v_prefix);
  INSERT INTO IDENTIFIER(:v_artifacts) SELECT UUID_STRING(),CURRENT_TIMESTAMP(),'DEPLOY_'||:v_step,'RUNNING',:v_sql,SHA2(:v_sql,256),NULL,NULL;
  BEGIN
    EXECUTE IMMEDIATE :v_sql;
    v_query := SQLID;
    UPDATE IDENTIFIER(:v_artifacts) SET STATUS='PASS',QUERY_ID=:v_query WHERE KIND='DEPLOY_'||:v_step AND STATUS='RUNNING';
  EXCEPTION WHEN OTHER THEN
    v_error := OBJECT_CONSTRUCT('sqlcode',SQLCODE,'sqlstate',SQLSTATE,'message',SQLERRM);
    UPDATE IDENTIFIER(:v_artifacts) SET STATUS='FAIL',ERROR=:v_error WHERE KIND='DEPLOY_'||:v_step AND STATUS='RUNNING';
    RETURN 'DEPLOYMENT_FAILED: '||v_step||'. Run 06_export_evidence.sql; use a fresh prefix for a corrected attempt.';
  END;
  v_step := 'PROTOTYPE_LOG';
  v_sql := REPLACE(REPLACE('CREATE TABLE @DB@.STANDARDIZE_AUDIT.@P@PROTOTYPE_PROCESS_LOG (FEED_INSTANCE_ID NUMBER, RESULT VARIANT, UPDATED_AT TIMESTAMP_LTZ);', '@DB@', v_db), '@P@', v_prefix);
  INSERT INTO IDENTIFIER(:v_artifacts) SELECT UUID_STRING(),CURRENT_TIMESTAMP(),'DEPLOY_'||:v_step,'RUNNING',:v_sql,SHA2(:v_sql,256),NULL,NULL;
  BEGIN
    EXECUTE IMMEDIATE :v_sql;
    v_query := SQLID;
    UPDATE IDENTIFIER(:v_artifacts) SET STATUS='PASS',QUERY_ID=:v_query WHERE KIND='DEPLOY_'||:v_step AND STATUS='RUNNING';
  EXCEPTION WHEN OTHER THEN
    v_error := OBJECT_CONSTRUCT('sqlcode',SQLCODE,'sqlstate',SQLSTATE,'message',SQLERRM);
    UPDATE IDENTIFIER(:v_artifacts) SET STATUS='FAIL',ERROR=:v_error WHERE KIND='DEPLOY_'||:v_step AND STATUS='RUNNING';
    RETURN 'DEPLOYMENT_FAILED: '||v_step||'. Run 06_export_evidence.sql; use a fresh prefix for a corrected attempt.';
  END;
  v_step := 'CALLER_ACTION';
  v_sql := REPLACE(REPLACE('CREATE TABLE @DB@.STANDARDIZE_AUDIT.@P@CALLER_ACTION (FEED_INSTANCE_ID NUMBER, ACTION VARCHAR, RESULT VARIANT, CREATED_AT TIMESTAMP_LTZ);', '@DB@', v_db), '@P@', v_prefix);
  INSERT INTO IDENTIFIER(:v_artifacts) SELECT UUID_STRING(),CURRENT_TIMESTAMP(),'DEPLOY_'||:v_step,'RUNNING',:v_sql,SHA2(:v_sql,256),NULL,NULL;
  BEGIN
    EXECUTE IMMEDIATE :v_sql;
    v_query := SQLID;
    UPDATE IDENTIFIER(:v_artifacts) SET STATUS='PASS',QUERY_ID=:v_query WHERE KIND='DEPLOY_'||:v_step AND STATUS='RUNNING';
  EXCEPTION WHEN OTHER THEN
    v_error := OBJECT_CONSTRUCT('sqlcode',SQLCODE,'sqlstate',SQLSTATE,'message',SQLERRM);
    UPDATE IDENTIFIER(:v_artifacts) SET STATUS='FAIL',ERROR=:v_error WHERE KIND='DEPLOY_'||:v_step AND STATUS='RUNNING';
    RETURN 'DEPLOYMENT_FAILED: '||v_step||'. Run 06_export_evidence.sql; use a fresh prefix for a corrected attempt.';
  END;
  v_step := 'BASELINE_COMPILE';
  v_sql := REPLACE(REPLACE('CREATE PROCEDURE @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS ''
DECLARE
    ex_duplicate_cust_num_01 EXCEPTION ( -20002, ''''PRECONDITION CHECK FAILED: Duplicate cust_num(s) found in CUST_NUM_INDIVIDUAL_XREF'''' );
    ex_duplicate_cust_num_02 EXCEPTION ( -20003, ''''CHECK FAILED: Duplicate cust_num(s) found in STANDARDIZE_STAGE.CUST_NUM_INDIVIDUAL_XREF'''' );
    ex_duplicate_cust_num_03 EXCEPTION ( -20004, ''''CHECK FAILED: Duplicate cust_num(s) found between STANDARDIZE_CORE.CUST_NUM_INDIVIDUAL_XREF and STANDARDIZE_STAGE.CUST_NUM_INDIVIDUAL_XREF'''' );
    ex_duplicate_ind_id_01 EXCEPTION ( -20012, ''''PRECONDITION CHECK FAILED: Duplicate individual_id(s) found in CUST_NUM_INDIVIDUAL_XREF'''' );
    ex_duplicate_ind_id_02 EXCEPTION ( -20013, ''''CHECK FAILED: Duplicate individual_id(s) found in STANDARDIZE_STAGE.CUST_NUM_INDIVIDUAL_XREF'''' );
    ex_duplicate_ind_id_03 EXCEPTION ( -20014, ''''CHECK FAILED: Duplicate individual_id(s) found between STANDARDIZE_CORE.CUST_NUM_INDIVIDUAL_XREF and STANDARDIZE_STAGE.CUST_NUM_INDIVIDUAL_XREF'''' );
    ex_cust_num_out_of_range EXCEPTION ( -20005, ''''CHECK FAILED: a customer number would be created outside of the 500M range.'''' );
BEGIN

    BEGIN TRANSACTION;

    IF ( EXISTS ( SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF GROUP BY CUST_NUM HAVING COUNT(1) > 1 ) ) THEN
        RAISE ex_duplicate_cust_num_01;
    END IF;

    IF ( EXISTS ( SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF GROUP BY INDIVIDUAL_ID HAVING COUNT(1) > 1 ) ) THEN
        RAISE ex_duplicate_ind_id_01;
    END IF;
    

    CREATE OR REPLACE TABLE @DB@.STANDARDIZE_STAGE.@P@cnxi_maxid AS
    SELECT
        GREATEST(500000000, IFNULL(MAX(CUST_NUM),0)) AS SEED
    FROM
        @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF
    WHERE
        CUST_NUM BETWEEN 500000000 AND 599999999
    ;
    

    -- Get individual IDs not already in CUST_NUM_INDIVIDUAL_XREF
    -- these will require new CUST_NUM.
    CREATE OR REPLACE TABLE @DB@.STANDARDIZE_STAGE.@P@cnxi_new_ind AS
    SELECT
        pp.INDIVIDUAL_ID
    ,   MAX(pp.UPDATE_FEED_INSTANCE_ID) AS  FEED_INSTANCE_ID
    FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE AS pp
    WHERE pp.INDIVIDUAL_ID NOT IN
    (
        SELECT cnxi.INDIVIDUAL_ID
        FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF cnxi
    )
    GROUP BY pp.INDIVIDUAL_ID
    ;

    -- Get a list of externally created cust_num values to honor in
    -- CDP, these are SOURCE_SYSTEM_PK_1 from SOR_NAME = ICON or MAO
    -- WHERE SSPK1 is not already used as CUST_NUM or INDIVIDUAL_ID
    -- in CUST_NUM_INDIVIDUAL_XREF and the value is in the range
    -- 0..499999999,600000000..999999999
    CREATE OR REPLACE TABLE @DB@.STANDARDIZE_STAGE.@P@cnxi_external_cust_num AS
    WITH cte_ext_num AS
    (
        SELECT
            pp.INDIVIDUAL_ID
        ,   TRY_CAST( pp.SOURCE_SYSTEM_PK_1 AS NUMBER(38,0) )   AS t_cust_num
        ,   pp.SOURCE_REC_CREATE_DATETIME                       AS t_src_create_date
        ,   pp.SOR_NAME
        ,   new_ind.FEED_INSTANCE_ID
        FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE AS  pp
        JOIN @DB@.STANDARDIZE_STAGE.@P@cnxi_new_ind AS  new_ind ON pp.INDIVIDUAL_ID = new_ind.INDIVIDUAL_ID
        WHERE
            pp.SOR_NAME IN ( ''''ICON'''', ''''MAO'''' )  -- External CUST_NUM sources, include ICON and MAO
        AND t_cust_num IS NOT NULL            -- Extenal cust num must not be NULL
        AND t_cust_num     BETWEEN  1         -- must be positive and in the range
                                AND 999999999 -- 1 through 999,999,999
        AND t_cust_num NOT BETWEEN  500000000 -- but not in the reserved CDP range of 
                                AND 599999999 -- 500,000,000 through 599,999,999
    )
    SELECT
        src.INDIVIDUAL_ID
    ,   src.FEED_INSTANCE_ID
    ,   src.SOR_NAME
    ,   src.t_cust_num
    ,   DENSE_RANK()                       -- Rank externally source cust_nums from 1..[n]
        OVER (                             -- where 1 is the highest rank and is used as
            PARTITION BY                   -- the cust_num for the individual_id and 
                src.INDIVIDUAL_ID          -- 2+ are recorded as ''''''''merged'''''''' values that
            ORDER BY                       -- were unused in CDP from CDP''''''''s PoV.
                src.t_src_create_date DESC
              , src.t_cust_num ASC
              , src.SOR_NAME
        ) AS EXTERNAL_RANK
    ,   ROW_NUMBER()                        -- CUST_NUM_RANK prevents re-use of the same 
        OVER (                              -- external cust_num in this procedure, we
            PARTITION BY                    -- ONLY USE RECORDS having CUST_NUM_RANK = 1
                src.t_cust_num
            ORDER BY
                src.INDIVIDUAL_ID
              , src.t_src_create_date DESC
              , src.SOR_NAME
        ) AS CUST_NUM_RANK
    FROM cte_ext_num src
    WHERE
        NOT EXISTS
        (                   -- external cust_num value may not have been
                SELECT 1    -- previously used as cust_num or individual_id
                FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF xref
                WHERE 
                    xref.CUST_NUM      = src.t_cust_num
                OR  xref.INDIVIDUAL_ID = src.t_cust_num
        )
    ;

    -- These are the the CUST_NUM values which will be used in CDP
    CREATE OR REPLACE TABLE @DB@.STANDARDIZE_STAGE.@P@cnxi_new_external_cust_num AS
    SELECT
        new_ind.INDIVIDUAL_ID
    ,   ext_num.t_cust_num          AS CUST_NUM
    ,   ''''new_external_cust_num''''     AS REC_TYPE
    ,   new_ind.FEED_INSTANCE_ID
    FROM @DB@.STANDARDIZE_STAGE.@P@cnxi_new_ind new_ind
    JOIN @DB@.STANDARDIZE_STAGE.@P@cnxi_external_cust_num ext_num ON new_ind.INDIVIDUAL_ID = ext_num.INDIVIDUAL_ID
    WHERE
        ext_num.EXTERNAL_RANK = 1
    AND ext_num.CUST_NUM_RANK = 1
    ;


    CREATE OR REPLACE TABLE @DB@.STANDARDIZE_STAGE.@P@cnxi_merged_external_cust_num AS
    SELECT
        ext_num.t_cust_num          AS INDIVIDUAL_ID
    ,   ext_num.t_cust_num          AS CUST_NUM
    ,   ''''merged_external_cust_num''''  AS REC_TYPE 
    ,   ext_num.FEED_INSTANCE_ID
    FROM @DB@.STANDARDIZE_STAGE.@P@cnxi_external_cust_num ext_num
    WHERE
        ext_num.EXTERNAL_RANK > 1
    AND ext_num.CUST_NUM_RANK = 1
    ;


    -- These are new CDP-generated CUST_NUM values
    CREATE OR REPLACE TABLE @DB@.STANDARDIZE_STAGE.@P@cnxi_new_cdp_cust_num AS
    SELECT
        new_ind.INDIVIDUAL_ID
    ,   ROW_NUMBER() 
        OVER ( 
            ORDER BY new_ind.INDIVIDUAL_ID
        ) + max_id.SEED                     AS CUST_NUM
    ,   ''''new_cdp_cust_num''''                  AS REC_TYPE
    ,   new_ind.FEED_INSTANCE_ID
    FROM  @DB@.STANDARDIZE_STAGE.@P@cnxi_new_ind AS new_ind
      ,   @DB@.STANDARDIZE_STAGE.@P@cnxi_maxid   AS max_id
    WHERE new_ind.INDIVIDUAL_ID NOT IN 
    (
        SELECT new_ext.INDIVIDUAL_ID 
        FROM @DB@.STANDARDIZE_STAGE.@P@cnxi_new_external_cust_num AS new_ext
    )
    ;

    
    CREATE OR REPLACE TABLE @DB@.STANDARDIZE_STAGE.@P@CUST_NUM_INDIVIDUAL_XREF
    (
        INDIVIDUAL_ID           NUMBER(38,0)
    ,   CUST_NUM                NUMBER(38,0)
    ,   REC_TYPE                VARCHAR(50)
    ,   CREATE_DATE             TIMESTAMP_NTZ
    ,   CREATE_FEED_INSTANCE_ID NUMBER(38,0)
    )
    ;


    INSERT INTO @DB@.STANDARDIZE_STAGE.@P@CUST_NUM_INDIVIDUAL_XREF ( INDIVIDUAL_ID, CUST_NUM, REC_TYPE, CREATE_DATE, CREATE_FEED_INSTANCE_ID )
    SELECT
        INDIVIDUAL_ID
    ,   CUST_NUM
    ,   REC_TYPE
    ,   CURRENT_TIMESTAMP   AS CREATE_DATE
    ,   FEED_INSTANCE_ID
    FROM
    (
        SELECT INDIVIDUAL_ID, CUST_NUM, REC_TYPE, FEED_INSTANCE_ID
        FROM @DB@.STANDARDIZE_STAGE.@P@cnxi_new_external_cust_num

        UNION

        SELECT INDIVIDUAL_ID, CUST_NUM, REC_TYPE, FEED_INSTANCE_ID
        FROM @DB@.STANDARDIZE_STAGE.@P@cnxi_merged_external_cust_num

        UNION

        SELECT INDIVIDUAL_ID, CUST_NUM, REC_TYPE, FEED_INSTANCE_ID
        FROM @DB@.STANDARDIZE_STAGE.@P@cnxi_new_cdp_cust_num
    ) AS t
    ;


    IF ( EXISTS ( SELECT 1 FROM @DB@.STANDARDIZE_STAGE.@P@CUST_NUM_INDIVIDUAL_XREF GROUP BY CUST_NUM HAVING COUNT(1) > 1 ) ) THEN
        RAISE ex_duplicate_cust_num_02;
    END IF;

    IF ( EXISTS ( SELECT 1 FROM @DB@.STANDARDIZE_STAGE.@P@CUST_NUM_INDIVIDUAL_XREF GROUP BY INDIVIDUAL_ID HAVING COUNT(1) > 1 ) ) THEN
        RAISE ex_duplicate_ind_id_02;
    END IF;    


    IF ( EXISTS (
        SELECT 1
        FROM ( 
            SELECT CUST_NUM FROM @DB@.STANDARDIZE_STAGE.@P@CUST_NUM_INDIVIDUAL_XREF
            UNION ALL
            SELECT CUST_NUM FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF
        ) t
        GROUP BY CUST_NUM HAVING COUNT(1) > 1    
    ) ) THEN
        RAISE ex_duplicate_cust_num_03;
    END IF;
    

    IF ( EXISTS (
        SELECT 1
        FROM ( 
            SELECT INDIVIDUAL_ID FROM @DB@.STANDARDIZE_STAGE.@P@CUST_NUM_INDIVIDUAL_XREF
            UNION ALL
            SELECT INDIVIDUAL_ID FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF
        ) t
        GROUP BY INDIVIDUAL_ID HAVING COUNT(1) > 1    
    ) ) THEN
        RAISE ex_duplicate_ind_id_03;
    END IF;


    IF ( EXISTS (
        SELECT 1
        FROM @DB@.STANDARDIZE_STAGE.@P@CUST_NUM_INDIVIDUAL_XREF
        WHERE CUST_NUM NOT BETWEEN 500000000 AND 599999999
        AND REC_TYPE = ''''new_cdp_cust_num''''
    ) ) THEN
        RAISE ex_cust_num_out_of_range;
    END IF;


    MERGE INTO @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF AS tgt
    USING @DB@.STANDARDIZE_STAGE.@P@CUST_NUM_INDIVIDUAL_XREF src
    ON tgt.INDIVIDUAL_ID = IFNULL(src.INDIVIDUAL_ID,0)
    OR tgt.CUST_NUM = IFNULL(src.CUST_NUM,0)      -- ADDED TO PREVENT CUST_NUM DUPLICATES
    WHEN NOT MATCHED THEN
        INSERT ( INDIVIDUAL_ID, CUST_NUM, CREATE_DATE, REC_TYPE, CREATE_FEED_INSTANCE_ID )
        VALUES ( INDIVIDUAL_ID, CUST_NUM, CREATE_DATE, REC_TYPE, CREATE_FEED_INSTANCE_ID )
    ;

    COMMIT;

    RETURN ''''SUCCESS'''';

EXCEPTION
    WHEN OTHER THEN
    
        ROLLBACK;
        
        CREATE OR REPLACE TABLE @DB@.STANDARDIZE_STAGE.@P@cnxi_new_ind_debug AS
        SELECT DISTINCT INDIVIDUAL_ID FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE
        EXCEPT
        SELECT INDIVIDUAL_ID FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF
        ;
        
        RAISE;
END;
'';', '@DB@', v_db), '@P@', v_prefix);
  INSERT INTO IDENTIFIER(:v_artifacts) SELECT UUID_STRING(),CURRENT_TIMESTAMP(),'DEPLOY_'||:v_step,'RUNNING',:v_sql,SHA2(:v_sql,256),NULL,NULL;
  BEGIN
    EXECUTE IMMEDIATE :v_sql;
    v_query := SQLID;
    UPDATE IDENTIFIER(:v_artifacts) SET STATUS='PASS',QUERY_ID=:v_query WHERE KIND='DEPLOY_'||:v_step AND STATUS='RUNNING';
  EXCEPTION WHEN OTHER THEN
    v_error := OBJECT_CONSTRUCT('sqlcode',SQLCODE,'sqlstate',SQLSTATE,'message',SQLERRM);
    UPDATE IDENTIFIER(:v_artifacts) SET STATUS='FAIL',ERROR=:v_error WHERE KIND='DEPLOY_'||:v_step AND STATUS='RUNNING';
    RETURN 'DEPLOYMENT_FAILED: '||v_step||'. Run 06_export_evidence.sql; use a fresh prefix for a corrected attempt.';
  END;
  v_step := 'AUDIT_HELPER_COMPILE';
  v_sql := REPLACE(REPLACE('CREATE PROCEDURE @DB@.STANDARDIZE_STAGE.@P@WRITE_PROTOTYPE_LOG(P_FEED NUMBER, P_RESULT VARIANT) RETURNS VARCHAR LANGUAGE SQL EXECUTE AS OWNER AS ''BEGIN
  BEGIN TRANSACTION;
  MERGE INTO @DB@.STANDARDIZE_AUDIT.@P@PROTOTYPE_PROCESS_LOG t
  USING (SELECT :P_FEED AS FEED_INSTANCE_ID, :P_RESULT AS RESULT) s
  ON t.FEED_INSTANCE_ID=s.FEED_INSTANCE_ID
  WHEN MATCHED THEN UPDATE SET RESULT=s.RESULT, UPDATED_AT=CURRENT_TIMESTAMP()
  WHEN NOT MATCHED THEN INSERT (FEED_INSTANCE_ID,RESULT,UPDATED_AT)
    VALUES (s.FEED_INSTANCE_ID,s.RESULT,CURRENT_TIMESTAMP());
  COMMIT;
  RETURN ''''SUCCESS'''';
EXCEPTION WHEN OTHER THEN
  ROLLBACK;
  RAISE;
END;
'';', '@DB@', v_db), '@P@', v_prefix);
  INSERT INTO IDENTIFIER(:v_artifacts) SELECT UUID_STRING(),CURRENT_TIMESTAMP(),'DEPLOY_'||:v_step,'RUNNING',:v_sql,SHA2(:v_sql,256),NULL,NULL;
  BEGIN
    EXECUTE IMMEDIATE :v_sql;
    v_query := SQLID;
    UPDATE IDENTIFIER(:v_artifacts) SET STATUS='PASS',QUERY_ID=:v_query WHERE KIND='DEPLOY_'||:v_step AND STATUS='RUNNING';
  EXCEPTION WHEN OTHER THEN
    v_error := OBJECT_CONSTRUCT('sqlcode',SQLCODE,'sqlstate',SQLSTATE,'message',SQLERRM);
    UPDATE IDENTIFIER(:v_artifacts) SET STATUS='FAIL',ERROR=:v_error WHERE KIND='DEPLOY_'||:v_step AND STATUS='RUNNING';
    RETURN 'DEPLOYMENT_FAILED: '||v_step||'. Run 06_export_evidence.sql; use a fresh prefix for a corrected attempt.';
  END;
  v_step := 'CANDIDATE_COMPILE';
  v_sql := REPLACE(REPLACE('CREATE PROCEDURE @DB@.STANDARDIZE_STAGE.@P@GENERATE_CUST_NUMS_PROTOTYPE(FEED_INSTANCE_ID NUMBER(38,0), AUTOMATION_GUID VARCHAR(36), PREVIEW BOOLEAN, RESULT OUT VARIANT) RETURNS VARCHAR LANGUAGE SQL EXECUTE AS OWNER AS ''-- M0 JSON/serialization prototype. It NEVER allocates customer numbers.
DECLARE
  bad_entry EXCEPTION (-20970,''''M0 explicit non-null inputs and no caller transaction required'''');
  bad_gate EXCEPTION (-20971,''''M0 exactly one generation gate row required'''');
  controlled_error EXCEPTION (-20972,''''M0 controlled business-marker error'''');
  bad_fixture EXCEPTION (-20974,''''M0 fixture or environment marker invalid'''');
  v_stage VARCHAR := ''''ENTRY'''';
  v_mode VARCHAR := IFF(PREVIEW,''''PREVIEW'''',''''LIVE'''');
  v_owns_tx BOOLEAN := FALSE;
  v_applied BOOLEAN := FALSE;
  v_committed BOOLEAN := FALSE;
  v_commit_started BOOLEAN := FALSE;
  v_persistence VARCHAR := ''''NOT_ATTEMPTED'''';
  v_n NUMBER;
  v_observed NUMBER;
  v_hold NUMBER;
  v_fail BOOLEAN;
  v_zero BOOLEAN;
  v_requested TIMESTAMP_LTZ;
  v_acquired TIMESTAMP_LTZ;
  v_release_started TIMESTAMP_LTZ;
  v_released TIMESTAMP_LTZ;
  v_result VARIANT;
  v_error VARIANT;
BEGIN
  RESULT := NULL;
  IF (FEED_INSTANCE_ID IS NULL OR AUTOMATION_GUID IS NULL OR AUTOMATION_GUID=''''''''
      OR PREVIEW IS NULL OR CURRENT_TRANSACTION() IS NOT NULL) THEN RAISE bad_entry; END IF;
  SELECT COUNT(*) INTO :v_n FROM @DB@.STANDARDIZE_AUDIT.@P@ENVIRONMENT
    WHERE PACKAGE_VERSION=''''M0-SQL-ONLY-2'''' AND DATABASE_NAME=''''@DB@'''' AND OBJECT_PREFIX=''''@P@'''';
  IF (v_n<>1) THEN RAISE bad_fixture; END IF;
  SELECT COUNT(*) INTO :v_n FROM @DB@.STANDARDIZE_STAGE.@P@SCENARIO s
    WHERE s.FEED_INSTANCE_ID=:FEED_INSTANCE_ID;
  IF (v_n<>1) THEN RAISE bad_fixture; END IF;
  SELECT HOLD_SECONDS,FAIL_AFTER_APPLY,ZERO_WORK INTO :v_hold,:v_fail,:v_zero
    FROM @DB@.STANDARDIZE_STAGE.@P@SCENARIO s WHERE s.FEED_INSTANCE_ID=:FEED_INSTANCE_ID;
  IF (v_hold<0 OR v_hold>30) THEN RAISE bad_fixture; END IF;
  v_stage := ''''GATE'''';
  v_requested := CURRENT_TIMESTAMP();
  BEGIN TRANSACTION;
  v_owns_tx := TRUE;
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@CUST_NUM_PROCESS SET LAST_RUN_ID=:FEED_INSTANCE_ID
    WHERE PROCESS_NAME=''''GENERATE_CUST_NUMS'''';
  v_n := SQLROWCOUNT;
  IF (v_n<>1) THEN RAISE bad_gate; END IF;
  v_acquired := CURRENT_TIMESTAMP();
  v_stage := ''''PREPARE'''';
  TRUNCATE TABLE @DB@.STANDARDIZE_STAGE.@P@PROTOTYPE_WORK;
  SELECT VALUE INTO :v_observed FROM @DB@.STANDARDIZE_CORE.@P@PROTOTYPE_BUSINESS WHERE ID=1;
  INSERT INTO @DB@.STANDARDIZE_STAGE.@P@PROTOTYPE_WORK VALUES (:FEED_INSTANCE_ID,:v_observed);
  -- Audit-only scoped transaction is in the serialized path; no failure injection here.
  v_stage := ''''IN_PROGRESS_LOG'''';
  v_result := OBJECT_CONSTRUCT(''''status'''',''''IN_PROGRESS'''',''''scope'''',''''M0_PROTOTYPE'''',
    ''''sessionId'''',CURRENT_SESSION(),''''gateAcquiredAt'''',v_acquired,''''observedValue'''',v_observed);
  CALL @DB@.STANDARDIZE_STAGE.@P@WRITE_PROTOTYPE_LOG(:FEED_INSTANCE_ID,:v_result);
  IF (v_hold>0) THEN CALL SYSTEM$WAIT(:v_hold,''''SECONDS''''); END IF;
  v_stage := ''''BUSINESS_MARKER'''';
  IF (NOT PREVIEW AND NOT v_zero) THEN
    UPDATE @DB@.STANDARDIZE_CORE.@P@PROTOTYPE_BUSINESS SET VALUE=:v_observed+1 WHERE ID=1;
    v_applied := TRUE;
  END IF;
  IF (v_fail) THEN RAISE controlled_error; END IF;
  DELETE FROM @DB@.STANDARDIZE_STAGE.@P@PROTOTYPE_WORK WHERE RUN_ID=:FEED_INSTANCE_ID;
  v_stage := ''''COMPLETE_TRANSACTION'''';
  v_release_started := CURRENT_TIMESTAMP();
  IF (PREVIEW) THEN ROLLBACK;
  ELSE
    v_commit_started := TRUE;
    COMMIT;
    v_committed := TRUE;
  END IF;
  v_owns_tx := FALSE;
  v_released := CURRENT_TIMESTAMP();
  v_persistence := IFF(v_applied,''''COMMITTED'''',''''NOT_ATTEMPTED'''');
  v_result := OBJECT_CONSTRUCT_KEEP_NULL(''''contractVersion'''',2,''''scope'''',''''M0_PROTOTYPE'''',
    ''''feedInstanceId'''',FEED_INSTANCE_ID,''''automationGuid'''',AUTOMATION_GUID,''''mode'''',v_mode,
    ''''status'''',''''SUCCESS'''',''''persistence'''',v_persistence,''''stage'''',''''COMPLETE'''',''''error'''',NULL,''''action'''',''''CONTINUE'''',
    ''''prototypeEvidence'''',OBJECT_CONSTRUCT_KEEP_NULL(''''sessionId'''',CURRENT_SESSION(),''''observedValue'''',v_observed,
      ''''requestedAt'''',v_requested,''''gateAcquiredAt'''',v_acquired,''''releaseStartedAt'''',v_release_started,''''releasedAt'''',v_released));
  v_stage := ''''FINAL_LOG'''';
  CALL @DB@.STANDARDIZE_STAGE.@P@WRITE_PROTOTYPE_LOG(:FEED_INSTANCE_ID,:v_result);
  RESULT := v_result;
  RETURN ''''SUCCESS'''';
EXCEPTION WHEN OTHER THEN
  -- Capture first; any rollback/logging error must not overwrite this error.
  v_error := OBJECT_CONSTRUCT(''''sqlcode'''',SQLCODE,''''sqlstate'''',SQLSTATE,''''message'''',SQLERRM,''''stage'''',v_stage);
  IF (v_committed) THEN v_persistence := IFF(v_applied,''''COMMITTED'''',''''NOT_ATTEMPTED'''');
  ELSEIF (v_owns_tx) THEN
    v_persistence := IFF(v_applied OR v_commit_started,''''UNKNOWN'''',''''NOT_ATTEMPTED'''');
    BEGIN
      v_release_started := CURRENT_TIMESTAMP();
      ROLLBACK;
      v_owns_tx := FALSE;
      v_released := CURRENT_TIMESTAMP();
      IF (NOT v_commit_started) THEN v_persistence := IFF(v_applied,''''ROLLED_BACK'''',''''NOT_ATTEMPTED''''); END IF;
    EXCEPTION WHEN OTHER THEN NULL;
    END;
  END IF;
  v_result := OBJECT_CONSTRUCT_KEEP_NULL(''''contractVersion'''',2,''''scope'''',''''M0_PROTOTYPE'''',
    ''''feedInstanceId'''',FEED_INSTANCE_ID,''''automationGuid'''',AUTOMATION_GUID,''''mode'''',IFF(PREVIEW IS NULL,NULL,v_mode),
    ''''status'''',''''ERROR'''',''''persistence'''',v_persistence,''''stage'''',v_stage,''''error'''',v_error,
    ''''action'''',IFF(v_persistence IN (''''COMMITTED'''',''''UNKNOWN''''),''''RECONCILE'''',''''STOP''''),
    ''''prototypeEvidence'''',OBJECT_CONSTRUCT_KEEP_NULL(''''sessionId'''',CURRENT_SESSION(),''''observedValue'''',v_observed,
      ''''requestedAt'''',v_requested,''''gateAcquiredAt'''',v_acquired,''''releaseStartedAt'''',v_release_started,''''releasedAt'''',v_released));
  IF (FEED_INSTANCE_ID IS NOT NULL) THEN
    BEGIN
      CALL @DB@.STANDARDIZE_STAGE.@P@WRITE_PROTOTYPE_LOG(:FEED_INSTANCE_ID,:v_result);
    EXCEPTION WHEN OTHER THEN NULL;
    END;
  END IF;
  RESULT := v_result;
  RETURN ''''ERROR'''';
END;
'';', '@DB@', v_db), '@P@', v_prefix);
  INSERT INTO IDENTIFIER(:v_artifacts) SELECT UUID_STRING(),CURRENT_TIMESTAMP(),'DEPLOY_'||:v_step,'RUNNING',:v_sql,SHA2(:v_sql,256),NULL,NULL;
  BEGIN
    EXECUTE IMMEDIATE :v_sql;
    v_query := SQLID;
    UPDATE IDENTIFIER(:v_artifacts) SET STATUS='PASS',QUERY_ID=:v_query WHERE KIND='DEPLOY_'||:v_step AND STATUS='RUNNING';
  EXCEPTION WHEN OTHER THEN
    v_error := OBJECT_CONSTRUCT('sqlcode',SQLCODE,'sqlstate',SQLSTATE,'message',SQLERRM);
    UPDATE IDENTIFIER(:v_artifacts) SET STATUS='FAIL',ERROR=:v_error WHERE KIND='DEPLOY_'||:v_step AND STATUS='RUNNING';
    RETURN 'DEPLOYMENT_FAILED: '||v_step||'. Run 06_export_evidence.sql; use a fresh prefix for a corrected attempt.';
  END;
  v_step := 'CALLER_ADAPTER_COMPILE';
  v_sql := REPLACE(REPLACE('CREATE PROCEDURE @DB@.STANDARDIZE_STAGE.@P@CALLER_ADAPTER(P_FEED NUMBER, P_GUID VARCHAR(36), P_PREVIEW BOOLEAN, RESULT OUT VARIANT) RETURNS VARCHAR LANGUAGE SQL EXECUTE AS CALLER AS ''-- Procedure-specific SQL caller example; not a deployed RPDM framework change.
DECLARE
  v_result VARIANT;
  v_status VARCHAR;
  v_error VARCHAR;
  v_stage VARCHAR;
  v_bad_contract EXCEPTION (-20978,''''Missing or invalid JSON outcome from procedure'''');
BEGIN
  CALL @DB@.STANDARDIZE_STAGE.@P@GENERATE_CUST_NUMS_PROTOTYPE(:P_FEED,:P_GUID,:P_PREVIEW,:v_result);
  IF (v_result IS NULL OR COALESCE(v_result:contractVersion::NUMBER<>2,TRUE)
      OR COALESCE(v_result:status::VARCHAR NOT IN (''''SUCCESS'''',''''ERROR''''),TRUE)
      OR COALESCE(v_result:persistence::VARCHAR NOT IN (''''NOT_ATTEMPTED'''',''''COMMITTED'''',''''ROLLED_BACK'''',''''UNKNOWN''''),TRUE)) THEN RAISE v_bad_contract; END IF;
  v_status := v_result:status::VARCHAR;
  v_stage := v_result:stage::VARCHAR;
  v_error := IFF(v_status=''''ERROR'''',LEFT(TO_JSON(v_result),4000),NULL);
  -- Caller persists outcome AFTER the procedure has closed its business transaction.
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@AUTOMATION_LOG SET AUTOMATION_STATUS=:v_status,
    END_DATE=CURRENT_TIMESTAMP(),LAST_ERROR_STEP_NAME=IFF(:v_status=''''ERROR'''',:v_stage,NULL),LAST_ERROR=:v_error
    WHERE AUTOMATION_GUID=:P_GUID;
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@FEED_INSTANCE SET FEED_PROCESS_RESULT=:v_status,FEED_END_DATE=CURRENT_TIMESTAMP()
    WHERE FEED_INSTANCE_ID=:P_FEED AND AUTOMATION_GUID=:P_GUID;
  IF (v_status=''''ERROR'''') THEN
    INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@CALLER_ACTION SELECT :P_FEED,
      IFF(:v_result:persistence::VARCHAR IN (''''COMMITTED'''',''''UNKNOWN''''),''''RECONCILE'''',''''STOP''''),:v_result,CURRENT_TIMESTAMP();
    RESULT := v_result;
    RETURN ''''ERROR''''; -- exits before the simulated downstream-success branch
  END IF;
  INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@CALLER_ACTION VALUES (:P_FEED,''''CONTINUE'''',:v_result,CURRENT_TIMESTAMP());
  RESULT := v_result;
  -- RPDM must branch on RESULT:status. ERROR stops downstream work.
  -- COMMITTED/UNKNOWN errors require reconciliation; never blindly retry allocation.
  RETURN v_status;
END;
'';', '@DB@', v_db), '@P@', v_prefix);
  INSERT INTO IDENTIFIER(:v_artifacts) SELECT UUID_STRING(),CURRENT_TIMESTAMP(),'DEPLOY_'||:v_step,'RUNNING',:v_sql,SHA2(:v_sql,256),NULL,NULL;
  BEGIN
    EXECUTE IMMEDIATE :v_sql;
    v_query := SQLID;
    UPDATE IDENTIFIER(:v_artifacts) SET STATUS='PASS',QUERY_ID=:v_query WHERE KIND='DEPLOY_'||:v_step AND STATUS='RUNNING';
  EXCEPTION WHEN OTHER THEN
    v_error := OBJECT_CONSTRUCT('sqlcode',SQLCODE,'sqlstate',SQLSTATE,'message',SQLERRM);
    UPDATE IDENTIFIER(:v_artifacts) SET STATUS='FAIL',ERROR=:v_error WHERE KIND='DEPLOY_'||:v_step AND STATUS='RUNNING';
    RETURN 'DEPLOYMENT_FAILED: '||v_step||'. Run 06_export_evidence.sql; use a fresh prefix for a corrected attempt.';
  END;
  v_step := 'RUN_CASE_COMPILE';
  v_sql := REPLACE(REPLACE('CREATE PROCEDURE @DB@.STANDARDIZE_STAGE.@P@RUN_CASE(P_RUN VARCHAR, P_CASE VARCHAR) RETURNS VARCHAR LANGUAGE SQL EXECUTE AS CALLER AS ''DECLARE
  v_fixture VARCHAR; v_execute VARCHAR; v_assert VARCHAR;
  v_disposition VARCHAR; v_expected VARIANT;
  v_feed NUMBER; v_guid VARCHAR := UUID_STRING();
  v_sql VARCHAR; v_phase VARCHAR := ''''LOAD_DEFINITION'''';
  v_code NUMBER; v_state VARCHAR; v_message VARCHAR; v_query VARCHAR;
  v_execute_failed BOOLEAN := FALSE;
BEGIN
  SELECT FIXTURE_SQL,EXECUTE_SQL,ASSERT_SQL,DISPOSITION,EXPECTED
    INTO :v_fixture,:v_execute,:v_assert,:v_disposition,:v_expected
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION WHERE TEST_ID=:P_CASE;
  SELECT @DB@.STANDARDIZE_AUDIT.@P@FEED_SEQUENCE.NEXTVAL INTO :v_feed;
  INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT
    (RUN_ID,TEST_ID,DISPOSITION,STATUS,STARTED_AT,PHASE,FEED_INSTANCE_ID,AUTOMATION_GUID,EXPECTED)
    VALUES (:P_RUN,:P_CASE,:v_disposition,''''RUNNING'''',CURRENT_TIMESTAMP(),:v_phase,:v_feed,:v_guid,:v_expected);
  IF (v_disposition<>''''REQUIRED'''' OR v_execute='''''''') THEN
    UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET STATUS=''''NOT_RUN'''',PHASE=''''PREREQUISITE'''',FINISHED_AT=CURRENT_TIMESTAMP()
      WHERE RUN_ID=:P_RUN AND TEST_ID=:P_CASE;
    RETURN ''''NOT_RUN'''';
  END IF;
  v_phase := ''''FIXTURE'''';
  IF (v_fixture<>'''''''') THEN
    v_sql := REPLACE(REPLACE(REPLACE(REPLACE(v_fixture,''''@RUN@'''',P_RUN),''''@CASE@'''',P_CASE),''''@FEED@'''',v_feed::VARCHAR),''''@GUID@'''',v_guid);
    EXECUTE IMMEDIATE :v_sql;
  END IF;
  v_phase := ''''EXECUTE'''';
  v_sql := REPLACE(REPLACE(REPLACE(REPLACE(v_execute,''''@RUN@'''',P_RUN),''''@CASE@'''',P_CASE),''''@FEED@'''',v_feed::VARCHAR),''''@GUID@'''',v_guid);
  BEGIN
    EXECUTE IMMEDIATE :v_sql;
    v_query := SQLID;
  EXCEPTION WHEN OTHER THEN
    v_code := SQLCODE; v_state := SQLSTATE; v_message := SQLERRM; v_query := SQLID;
    v_execute_failed := TRUE;
    UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET SQLCODE=:v_code,SQLSTATE=:v_state,SQLERRM=:v_message,
      PHASE=''''EXECUTE'''',LAST_QUERY_ID=:v_query WHERE RUN_ID=:P_RUN AND TEST_ID=:P_CASE;
  END;
  v_phase := ''''ASSERT'''';
  v_sql := REPLACE(REPLACE(REPLACE(REPLACE(v_assert,''''@RUN@'''',P_RUN),''''@CASE@'''',P_CASE),''''@FEED@'''',v_feed::VARCHAR),''''@GUID@'''',v_guid);
  EXECUTE IMMEDIATE :v_sql;
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT
    SET STATUS=IFF(COALESCE(ASSERTION_PASS,FALSE),''''PASS'''',''''FAIL''''),FINISHED_AT=CURRENT_TIMESTAMP(),
      PHASE=IFF(:v_execute_failed,''''EXECUTE'''',''''COMPLETE''''),LAST_QUERY_ID=:v_query
    WHERE RUN_ID=:P_RUN AND TEST_ID=:P_CASE;
  RETURN ''''RECORDED'''';
EXCEPTION WHEN OTHER THEN
  v_code := SQLCODE; v_state := SQLSTATE; v_message := SQLERRM; v_query := SQLID;
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET STATUS=''''ERROR'''',FINISHED_AT=CURRENT_TIMESTAMP(),PHASE=:v_phase,
    SQLCODE=:v_code,SQLSTATE=:v_state,SQLERRM=:v_message,LAST_QUERY_ID=:v_query
    WHERE RUN_ID=:P_RUN AND TEST_ID=:P_CASE;
  -- A setup/assertion failure is NEVER an expected procedure error or a passing test.
  RETURN ''''ERROR'''';
END;
'';', '@DB@', v_db), '@P@', v_prefix);
  INSERT INTO IDENTIFIER(:v_artifacts) SELECT UUID_STRING(),CURRENT_TIMESTAMP(),'DEPLOY_'||:v_step,'RUNNING',:v_sql,SHA2(:v_sql,256),NULL,NULL;
  BEGIN
    EXECUTE IMMEDIATE :v_sql;
    v_query := SQLID;
    UPDATE IDENTIFIER(:v_artifacts) SET STATUS='PASS',QUERY_ID=:v_query WHERE KIND='DEPLOY_'||:v_step AND STATUS='RUNNING';
  EXCEPTION WHEN OTHER THEN
    v_error := OBJECT_CONSTRUCT('sqlcode',SQLCODE,'sqlstate',SQLSTATE,'message',SQLERRM);
    UPDATE IDENTIFIER(:v_artifacts) SET STATUS='FAIL',ERROR=:v_error WHERE KIND='DEPLOY_'||:v_step AND STATUS='RUNNING';
    RETURN 'DEPLOYMENT_FAILED: '||v_step||'. Run 06_export_evidence.sql; use a fresh prefix for a corrected attempt.';
  END;
  v_step := 'RUN_SUITE_COMPILE';
  v_sql := REPLACE(REPLACE('CREATE PROCEDURE @DB@.STANDARDIZE_STAGE.@P@RUN_SUITE() RETURNS VARCHAR LANGUAGE SQL EXECUTE AS CALLER AS ''DECLARE
  v_run VARCHAR := UUID_STRING();
  v_case VARCHAR;
  v_n NUMBER;
  v_cases RESULTSET DEFAULT (SELECT TEST_ID FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION ORDER BY TEST_ID);
  v_error VARIANT;
  v_query VARCHAR;
  v_bad EXCEPTION (-20991,''''Duplicate definitions, active run, missing deployment, or caller transaction'''');
BEGIN
  IF (CURRENT_TRANSACTION() IS NOT NULL) THEN RAISE v_bad; END IF;
  SELECT COUNT(*)-COUNT(DISTINCT TEST_ID) INTO :v_n FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION;
  IF (v_n<>0) THEN RAISE v_bad; END IF;
  SELECT COUNT(*) INTO :v_n FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION WHERE SUITE IN (''''BASELINE'''',''''CONTRACT'''',''''RELATIONAL'''');
  IF (v_n<>34) THEN RAISE v_bad; END IF;
  SELECT COUNT(*) INTO :v_n FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RUN WHERE RUN_STATUS=''''RUNNING'''';
  IF (v_n<>0) THEN RAISE v_bad; END IF;
  SELECT COUNT(*) INTO :v_n FROM @DB@.STANDARDIZE_AUDIT.@P@ARTIFACT WHERE KIND=''''DEPLOY_SERIAL_WORKER_COMPILE'''' AND STATUS=''''PASS'''';
  IF (v_n<>1) THEN RAISE v_bad; END IF;
  INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_RUN VALUES (:v_run,''''SEQUENTIAL'''',CURRENT_TIMESTAMP(),NULL,''''RUNNING'''',
    OBJECT_CONSTRUCT(''''account'''',CURRENT_ACCOUNT(),''''database'''',CURRENT_DATABASE(),''''role'''',CURRENT_ROLE(),''''warehouse'''',CURRENT_WAREHOUSE(),''''sessionId'''',CURRENT_SESSION(),''''prefix'''',''''@P@''''),''''M0-SQL-ONLY-2'''');
  FOR rec IN v_cases DO
    v_case := rec.TEST_ID;
    CALL @DB@.STANDARDIZE_STAGE.@P@RUN_CASE(:v_run,:v_case);
  END FOR;
  SELECT COUNT(*) INTO :v_n FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT
    WHERE RUN_ID=:v_run AND STATUS IN (''''FAIL'''',''''ERROR'''',''''RUNNING'''');
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RUN SET FINISHED_AT=CURRENT_TIMESTAMP(),
    RUN_STATUS=IFF(:v_n=0,''''SEQUENTIAL_COMPLETE'''',''''COMPLETED_WITH_FAILURES'''') WHERE RUN_ID=:v_run;
  RETURN v_run;
EXCEPTION WHEN OTHER THEN
  v_error := OBJECT_CONSTRUCT(''''sqlcode'''',SQLCODE,''''sqlstate'''',SQLSTATE,''''message'''',SQLERRM);
  v_query := SQLID;
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RUN SET RUN_STATUS=''''ABORTED'''',FINISHED_AT=CURRENT_TIMESTAMP()
    WHERE RUN_ID=:v_run;
  INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@ARTIFACT SELECT UUID_STRING(),CURRENT_TIMESTAMP(),''''RUNNER_ABORT'''',''''FAIL'''',:v_run,NULL,:v_query,:v_error;
  RAISE;
END;
'';', '@DB@', v_db), '@P@', v_prefix);
  INSERT INTO IDENTIFIER(:v_artifacts) SELECT UUID_STRING(),CURRENT_TIMESTAMP(),'DEPLOY_'||:v_step,'RUNNING',:v_sql,SHA2(:v_sql,256),NULL,NULL;
  BEGIN
    EXECUTE IMMEDIATE :v_sql;
    v_query := SQLID;
    UPDATE IDENTIFIER(:v_artifacts) SET STATUS='PASS',QUERY_ID=:v_query WHERE KIND='DEPLOY_'||:v_step AND STATUS='RUNNING';
  EXCEPTION WHEN OTHER THEN
    v_error := OBJECT_CONSTRUCT('sqlcode',SQLCODE,'sqlstate',SQLSTATE,'message',SQLERRM);
    UPDATE IDENTIFIER(:v_artifacts) SET STATUS='FAIL',ERROR=:v_error WHERE KIND='DEPLOY_'||:v_step AND STATUS='RUNNING';
    RETURN 'DEPLOYMENT_FAILED: '||v_step||'. Run 06_export_evidence.sql; use a fresh prefix for a corrected attempt.';
  END;
  v_step := 'SERIAL_WORKER_COMPILE';
  v_sql := REPLACE(REPLACE('CREATE PROCEDURE @DB@.STANDARDIZE_STAGE.@P@SERIAL_WORKER(P_RUN VARCHAR, P_WORKER VARCHAR) RETURNS VARIANT LANGUAGE SQL EXECUTE AS CALLER AS ''DECLARE
  v_feed NUMBER; v_guid VARCHAR; v_feed_a NUMBER; v_kind VARCHAR;
  v_out VARIANT; v_log VARIANT; v_n NUMBER; v_wait NUMBER := 0;
  v_code NUMBER; v_state VARCHAR; v_message VARCHAR;
  v_bad EXCEPTION (-20993,''''Worker already used, invalid run, A not holding, or sessions not independent'''');
BEGIN
  IF (P_WORKER NOT IN (''''A'''',''''B'''') OR P_WORKER IS NULL) THEN RAISE v_bad; END IF;
  SELECT COUNT(*) INTO :v_n FROM @DB@.STANDARDIZE_AUDIT.@P@SERIAL_PAIR WHERE RUN_ID=:P_RUN;
  IF (v_n<>1) THEN RAISE v_bad; END IF;
  SELECT IFF(:P_WORKER=''''A'''',FEED_A,FEED_B),IFF(:P_WORKER=''''A'''',GUID_A,GUID_B),FEED_A,PAIR_KIND
    INTO :v_feed,:v_guid,:v_feed_a,:v_kind FROM @DB@.STANDARDIZE_AUDIT.@P@SERIAL_PAIR WHERE RUN_ID=:P_RUN;
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET STATUS=''''RUNNING'''',STARTED_AT=CURRENT_TIMESTAMP(),PHASE=''''WAIT_FOR_PEER''''
    WHERE RUN_ID=:P_RUN AND TEST_ID=''''SERIAL-''''||:P_WORKER AND STATUS=''''NOT_RUN'''';
  v_n := SQLROWCOUNT;
  IF (v_n<>1) THEN RAISE v_bad; END IF;
  IF (P_WORKER=''''B'''') THEN
    WHILE (v_wait<90) DO
      SELECT COUNT(*) INTO :v_n FROM @DB@.STANDARDIZE_AUDIT.@P@PROTOTYPE_PROCESS_LOG
        WHERE FEED_INSTANCE_ID=:v_feed_a AND RESULT:status::VARCHAR=''''IN_PROGRESS'''';
      IF (v_n=1) THEN BREAK; END IF;
      CALL SYSTEM$WAIT(1,''''SECONDS'''');
      v_wait := v_wait+1;
    END WHILE;
    IF (v_n<>1) THEN RAISE v_bad; END IF;
    SELECT RESULT INTO :v_log FROM @DB@.STANDARDIZE_AUDIT.@P@PROTOTYPE_PROCESS_LOG WHERE FEED_INSTANCE_ID=:v_feed_a;
    IF (v_log:sessionId::NUMBER=CURRENT_SESSION() OR v_log:status::VARCHAR<>''''IN_PROGRESS'''') THEN RAISE v_bad; END IF;
  END IF;
  CALL @DB@.STANDARDIZE_STAGE.@P@CALLER_ADAPTER(:v_feed,:v_guid,(:P_WORKER=''''A'''' AND :v_kind=''''PREVIEW''''),:v_out);
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET STATUS=''''OBSERVED'''',ACTUAL=:v_out,FINISHED_AT=CURRENT_TIMESTAMP(),PHASE=''''COMPLETE''''
    WHERE RUN_ID=:P_RUN AND TEST_ID=''''SERIAL-''''||:P_WORKER;
  RETURN v_out;
EXCEPTION WHEN OTHER THEN
  v_code := SQLCODE; v_state := SQLSTATE; v_message := SQLERRM;
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET STATUS=''''ERROR'''',SQLCODE=:v_code,SQLSTATE=:v_state,SQLERRM=:v_message,FINISHED_AT=CURRENT_TIMESTAMP()
    WHERE RUN_ID=:P_RUN AND TEST_ID=''''SERIAL-''''||:P_WORKER;
  RETURN OBJECT_CONSTRUCT(''''status'''',''''WORKER_ERROR'''',''''sqlcode'''',v_code,''''sqlstate'''',v_state,''''message'''',v_message);
END;
'';', '@DB@', v_db), '@P@', v_prefix);
  INSERT INTO IDENTIFIER(:v_artifacts) SELECT UUID_STRING(),CURRENT_TIMESTAMP(),'DEPLOY_'||:v_step,'RUNNING',:v_sql,SHA2(:v_sql,256),NULL,NULL;
  BEGIN
    EXECUTE IMMEDIATE :v_sql;
    v_query := SQLID;
    UPDATE IDENTIFIER(:v_artifacts) SET STATUS='PASS',QUERY_ID=:v_query WHERE KIND='DEPLOY_'||:v_step AND STATUS='RUNNING';
  EXCEPTION WHEN OTHER THEN
    v_error := OBJECT_CONSTRUCT('sqlcode',SQLCODE,'sqlstate',SQLSTATE,'message',SQLERRM);
    UPDATE IDENTIFIER(:v_artifacts) SET STATUS='FAIL',ERROR=:v_error WHERE KIND='DEPLOY_'||:v_step AND STATUS='RUNNING';
    RETURN 'DEPLOYMENT_FAILED: '||v_step||'. Run 06_export_evidence.sql; use a fresh prefix for a corrected attempt.';
  END;
  RETURN 'M0_PROTOTYPES_DEPLOYED_NO_ALLOCATOR_MIGRATION';
END;
$$;
