-- Run 00_config.sql in this session first. Start B, then A within 90 seconds.
SET Q_SERIAL_RUN_ID = 'REPLACE_WITH_RUN_ID_FROM_05a';
-- Generated locally; Snowflake compilation/execution NOT_RUN. See README.md.
EXECUTE IMMEDIATE $$
DECLARE
  v_db VARCHAR := $Q_DATABASE;
  v_prefix VARCHAR := $Q_PREFIX;
  v_account VARCHAR := $Q_ACCOUNT;
  v_ack VARCHAR := $Q_ACK;
  v_sql VARCHAR;
  v_n NUMBER;
  v_guard EXCEPTION (-20990, 'Qualification guard failed: check account, database, prefix, marker, and caller transaction');
  v_run VARCHAR := $Q_SERIAL_RUN_ID;
  v_worker VARCHAR := 'B';
  v_rows RESULTSET;
BEGIN
  IF (v_db IS NULL OR v_prefix IS NULL OR v_account IS NULL OR v_ack IS NULL
      OR NOT REGEXP_LIKE(v_db, '^[A-Z][A-Z0-9_]*$')
      OR NOT REGEXP_LIKE(v_prefix, '^M[0-9]+_$')
      OR v_account <> CURRENT_ACCOUNT() OR v_db <> CURRENT_DATABASE()
      OR v_ack <> 'ISOLATED_PREFIX_FIXTURES_ONLY'
      OR CURRENT_TRANSACTION() IS NOT NULL) THEN RAISE v_guard; END IF;
  LET v_marker VARCHAR := v_db || '.STANDARDIZE_AUDIT.' || v_prefix || 'ENVIRONMENT';
  SELECT COUNT(*) INTO :v_n FROM IDENTIFIER(:v_marker) WHERE PACKAGE_VERSION = 'M0-SQL-ONLY-2' AND DATABASE_NAME = :v_db AND OBJECT_PREFIX = :v_prefix AND ACCOUNT_NAME = :v_account;
  IF (v_n <> 1) THEN RAISE v_guard; END IF;
  IF (NOT REGEXP_LIKE(v_run,'^[0-9a-fA-F-]{36}$')) THEN RAISE v_guard; END IF;
  v_sql := 'CALL ' || v_db || '.STANDARDIZE_STAGE.' || v_prefix || 'SERIAL_WORKER(?,?)';
  v_rows := (EXECUTE IMMEDIATE :v_sql USING (v_run,v_worker));
  RETURN TABLE(v_rows);
END;
$$;
