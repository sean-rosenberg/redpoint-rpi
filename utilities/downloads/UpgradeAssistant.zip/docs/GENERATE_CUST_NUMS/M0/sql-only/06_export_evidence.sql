-- Generated locally; Snowflake compilation/execution NOT_RUN. See README.md.
EXECUTE IMMEDIATE $$
DECLARE
  v_db VARCHAR := $Q_DATABASE;
  v_prefix VARCHAR := $Q_PREFIX;
  v_account VARCHAR := $Q_ACCOUNT;
  v_ack VARCHAR := $Q_ACK;
  v_sql VARCHAR;
  v_n NUMBER;
  v_guard EXCEPTION (-20990, 'Qualification guard failed: check account, database, prefix, marker, and caller transaction');
  v_rows RESULTSET;
  v_export RESULTSET;
  v_error VARIANT;
  v_all ARRAY := ARRAY_CONSTRUCT();
BEGIN
  IF (v_db IS NULL OR v_prefix IS NULL OR v_account IS NULL OR v_ack IS NULL
      OR NOT REGEXP_LIKE(v_db, '^[A-Z][A-Z0-9_]*$')
      OR NOT REGEXP_LIKE(v_prefix, '^M[0-9]+_$')
      OR v_account <> CURRENT_ACCOUNT() OR v_db <> CURRENT_DATABASE()
      OR v_ack <> 'ISOLATED_PREFIX_FIXTURES_ONLY'
      OR CURRENT_TRANSACTION() IS NOT NULL) THEN RAISE v_guard; END IF;
  LET v_marker VARCHAR := v_db || '.STANDARDIZE_AUDIT.' || v_prefix || 'ENVIRONMENT';
  SELECT COUNT(*) INTO :v_n FROM IDENTIFIER(:v_marker) WHERE PACKAGE_VERSION = 'M0-SQL-ONLY-2' AND DATABASE_NAME = :v_db AND OBJECT_PREFIX = :v_prefix AND ACCOUNT_NAME = :v_account;
  IF (v_n <> 1) THEN RAISE v_guard; END IF;
  v_sql := REPLACE(REPLACE('SELECT OBJECT_CONSTRUCT_KEEP_NULL(*) AS PAYLOAD FROM (SELECT * FROM @DB@.STANDARDIZE_AUDIT.@P@ENVIRONMENT)', '@DB@', v_db), '@P@', v_prefix);
  BEGIN
    v_rows := (EXECUTE IMMEDIATE :v_sql);
    FOR rec IN v_rows DO
      v_all := ARRAY_APPEND(v_all,OBJECT_CONSTRUCT('section','ENVIRONMENT','row',rec.PAYLOAD));
    END FOR;
  EXCEPTION WHEN OTHER THEN
    v_error := OBJECT_CONSTRUCT('section','ENVIRONMENT','sqlcode',SQLCODE,'sqlstate',SQLSTATE,'message',SQLERRM);
    v_all := ARRAY_APPEND(v_all,OBJECT_CONSTRUCT('section','EVIDENCE_QUERY_ERROR','row',v_error));
  END;
  v_sql := REPLACE(REPLACE('SELECT OBJECT_CONSTRUCT_KEEP_NULL(*) AS PAYLOAD FROM (SELECT RUN_ID,DISPOSITION,STATUS,COUNT(*) AS TEST_COUNT FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT GROUP BY RUN_ID,DISPOSITION,STATUS ORDER BY RUN_ID,DISPOSITION,STATUS)', '@DB@', v_db), '@P@', v_prefix);
  BEGIN
    v_rows := (EXECUTE IMMEDIATE :v_sql);
    FOR rec IN v_rows DO
      v_all := ARRAY_APPEND(v_all,OBJECT_CONSTRUCT('section','SUMMARY','row',rec.PAYLOAD));
    END FOR;
  EXCEPTION WHEN OTHER THEN
    v_error := OBJECT_CONSTRUCT('section','SUMMARY','sqlcode',SQLCODE,'sqlstate',SQLSTATE,'message',SQLERRM);
    v_all := ARRAY_APPEND(v_all,OBJECT_CONSTRUCT('section','EVIDENCE_QUERY_ERROR','row',v_error));
  END;
  v_sql := REPLACE(REPLACE('SELECT OBJECT_CONSTRUCT_KEEP_NULL(*) AS PAYLOAD FROM (SELECT * FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RUN ORDER BY STARTED_AT)', '@DB@', v_db), '@P@', v_prefix);
  BEGIN
    v_rows := (EXECUTE IMMEDIATE :v_sql);
    FOR rec IN v_rows DO
      v_all := ARRAY_APPEND(v_all,OBJECT_CONSTRUCT('section','RUNS','row',rec.PAYLOAD));
    END FOR;
  EXCEPTION WHEN OTHER THEN
    v_error := OBJECT_CONSTRUCT('section','RUNS','sqlcode',SQLCODE,'sqlstate',SQLSTATE,'message',SQLERRM);
    v_all := ARRAY_APPEND(v_all,OBJECT_CONSTRUCT('section','EVIDENCE_QUERY_ERROR','row',v_error));
  END;
  v_sql := REPLACE(REPLACE('SELECT OBJECT_CONSTRUCT_KEEP_NULL(*) AS PAYLOAD FROM (SELECT * FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT ORDER BY RUN_ID,TEST_ID)', '@DB@', v_db), '@P@', v_prefix);
  BEGIN
    v_rows := (EXECUTE IMMEDIATE :v_sql);
    FOR rec IN v_rows DO
      v_all := ARRAY_APPEND(v_all,OBJECT_CONSTRUCT('section','RESULTS','row',rec.PAYLOAD));
    END FOR;
  EXCEPTION WHEN OTHER THEN
    v_error := OBJECT_CONSTRUCT('section','RESULTS','sqlcode',SQLCODE,'sqlstate',SQLSTATE,'message',SQLERRM);
    v_all := ARRAY_APPEND(v_all,OBJECT_CONSTRUCT('section','EVIDENCE_QUERY_ERROR','row',v_error));
  END;
  v_sql := REPLACE(REPLACE('SELECT OBJECT_CONSTRUCT_KEEP_NULL(*) AS PAYLOAD FROM (SELECT * FROM @DB@.STANDARDIZE_AUDIT.@P@ARTIFACT ORDER BY CREATED_AT)', '@DB@', v_db), '@P@', v_prefix);
  BEGIN
    v_rows := (EXECUTE IMMEDIATE :v_sql);
    FOR rec IN v_rows DO
      v_all := ARRAY_APPEND(v_all,OBJECT_CONSTRUCT('section','ARTIFACTS','row',rec.PAYLOAD));
    END FOR;
  EXCEPTION WHEN OTHER THEN
    v_error := OBJECT_CONSTRUCT('section','ARTIFACTS','sqlcode',SQLCODE,'sqlstate',SQLSTATE,'message',SQLERRM);
    v_all := ARRAY_APPEND(v_all,OBJECT_CONSTRUCT('section','EVIDENCE_QUERY_ERROR','row',v_error));
  END;
  v_sql := REPLACE(REPLACE('SELECT OBJECT_CONSTRUCT_KEEP_NULL(*) AS PAYLOAD FROM (SELECT * FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION ORDER BY TEST_ID)', '@DB@', v_db), '@P@', v_prefix);
  BEGIN
    v_rows := (EXECUTE IMMEDIATE :v_sql);
    FOR rec IN v_rows DO
      v_all := ARRAY_APPEND(v_all,OBJECT_CONSTRUCT('section','DEFINITIONS','row',rec.PAYLOAD));
    END FOR;
  EXCEPTION WHEN OTHER THEN
    v_error := OBJECT_CONSTRUCT('section','DEFINITIONS','sqlcode',SQLCODE,'sqlstate',SQLSTATE,'message',SQLERRM);
    v_all := ARRAY_APPEND(v_all,OBJECT_CONSTRUCT('section','EVIDENCE_QUERY_ERROR','row',v_error));
  END;
  v_sql := REPLACE(REPLACE('SELECT OBJECT_CONSTRUCT_KEEP_NULL(*) AS PAYLOAD FROM (SELECT * FROM @DB@.STANDARDIZE_AUDIT.@P@AUTOMATION_LOG ORDER BY AUTOMATION_ID)', '@DB@', v_db), '@P@', v_prefix);
  BEGIN
    v_rows := (EXECUTE IMMEDIATE :v_sql);
    FOR rec IN v_rows DO
      v_all := ARRAY_APPEND(v_all,OBJECT_CONSTRUCT('section','AUTOMATION_LOG','row',rec.PAYLOAD));
    END FOR;
  EXCEPTION WHEN OTHER THEN
    v_error := OBJECT_CONSTRUCT('section','AUTOMATION_LOG','sqlcode',SQLCODE,'sqlstate',SQLSTATE,'message',SQLERRM);
    v_all := ARRAY_APPEND(v_all,OBJECT_CONSTRUCT('section','EVIDENCE_QUERY_ERROR','row',v_error));
  END;
  v_sql := REPLACE(REPLACE('SELECT OBJECT_CONSTRUCT_KEEP_NULL(*) AS PAYLOAD FROM (SELECT * FROM @DB@.STANDARDIZE_AUDIT.@P@FEED_INSTANCE ORDER BY FEED_INSTANCE_ID)', '@DB@', v_db), '@P@', v_prefix);
  BEGIN
    v_rows := (EXECUTE IMMEDIATE :v_sql);
    FOR rec IN v_rows DO
      v_all := ARRAY_APPEND(v_all,OBJECT_CONSTRUCT('section','FEED_INSTANCE','row',rec.PAYLOAD));
    END FOR;
  EXCEPTION WHEN OTHER THEN
    v_error := OBJECT_CONSTRUCT('section','FEED_INSTANCE','sqlcode',SQLCODE,'sqlstate',SQLSTATE,'message',SQLERRM);
    v_all := ARRAY_APPEND(v_all,OBJECT_CONSTRUCT('section','EVIDENCE_QUERY_ERROR','row',v_error));
  END;
  v_sql := REPLACE(REPLACE('SELECT OBJECT_CONSTRUCT_KEEP_NULL(*) AS PAYLOAD FROM (SELECT * FROM @DB@.STANDARDIZE_AUDIT.@P@PROTOTYPE_PROCESS_LOG ORDER BY FEED_INSTANCE_ID)', '@DB@', v_db), '@P@', v_prefix);
  BEGIN
    v_rows := (EXECUTE IMMEDIATE :v_sql);
    FOR rec IN v_rows DO
      v_all := ARRAY_APPEND(v_all,OBJECT_CONSTRUCT('section','PROCESS_LOG','row',rec.PAYLOAD));
    END FOR;
  EXCEPTION WHEN OTHER THEN
    v_error := OBJECT_CONSTRUCT('section','PROCESS_LOG','sqlcode',SQLCODE,'sqlstate',SQLSTATE,'message',SQLERRM);
    v_all := ARRAY_APPEND(v_all,OBJECT_CONSTRUCT('section','EVIDENCE_QUERY_ERROR','row',v_error));
  END;
  v_sql := REPLACE(REPLACE('SELECT OBJECT_CONSTRUCT_KEEP_NULL(*) AS PAYLOAD FROM (SELECT * FROM @DB@.STANDARDIZE_AUDIT.@P@CALLER_ACTION ORDER BY FEED_INSTANCE_ID)', '@DB@', v_db), '@P@', v_prefix);
  BEGIN
    v_rows := (EXECUTE IMMEDIATE :v_sql);
    FOR rec IN v_rows DO
      v_all := ARRAY_APPEND(v_all,OBJECT_CONSTRUCT('section','CALLER_ACTION','row',rec.PAYLOAD));
    END FOR;
  EXCEPTION WHEN OTHER THEN
    v_error := OBJECT_CONSTRUCT('section','CALLER_ACTION','sqlcode',SQLCODE,'sqlstate',SQLSTATE,'message',SQLERRM);
    v_all := ARRAY_APPEND(v_all,OBJECT_CONSTRUCT('section','EVIDENCE_QUERY_ERROR','row',v_error));
  END;
  v_sql := REPLACE(REPLACE('SELECT OBJECT_CONSTRUCT_KEEP_NULL(*) AS PAYLOAD FROM (SELECT * FROM @DB@.STANDARDIZE_AUDIT.@P@SERIAL_PAIR ORDER BY CREATED_AT)', '@DB@', v_db), '@P@', v_prefix);
  BEGIN
    v_rows := (EXECUTE IMMEDIATE :v_sql);
    FOR rec IN v_rows DO
      v_all := ARRAY_APPEND(v_all,OBJECT_CONSTRUCT('section','SERIAL_PAIRS','row',rec.PAYLOAD));
    END FOR;
  EXCEPTION WHEN OTHER THEN
    v_error := OBJECT_CONSTRUCT('section','SERIAL_PAIRS','sqlcode',SQLCODE,'sqlstate',SQLSTATE,'message',SQLERRM);
    v_all := ARRAY_APPEND(v_all,OBJECT_CONSTRUCT('section','EVIDENCE_QUERY_ERROR','row',v_error));
  END;
  v_export := (SELECT VALUE:section::VARCHAR AS SECTION, VALUE:row AS EVIDENCE FROM TABLE(FLATTEN(INPUT=>:v_all)));
  RETURN TABLE(v_export);
END;
$$;
