-- Run after 04 completes. Repeat for COMMIT, ROLLBACK, PREVIEW; never overlap pairs.
SET Q_PAIR_KIND = 'COMMIT';
-- Generated locally; Snowflake compilation/execution NOT_RUN. See README.md.
EXECUTE IMMEDIATE $$
DECLARE
  v_db VARCHAR := $Q_DATABASE;
  v_prefix VARCHAR := $Q_PREFIX;
  v_account VARCHAR := $Q_ACCOUNT;
  v_ack VARCHAR := $Q_ACK;
  v_sql VARCHAR;
  v_n NUMBER;
  v_guard EXCEPTION (-20990, 'Qualification guard failed: check account, database, prefix, marker, and caller transaction');
  v_rows RESULTSET;
BEGIN
  IF (v_db IS NULL OR v_prefix IS NULL OR v_account IS NULL OR v_ack IS NULL
      OR NOT REGEXP_LIKE(v_db, '^[A-Z][A-Z0-9_]*$')
      OR NOT REGEXP_LIKE(v_prefix, '^M[0-9]+_$')
      OR v_account <> CURRENT_ACCOUNT() OR v_db <> CURRENT_DATABASE()
      OR v_ack <> 'ISOLATED_PREFIX_FIXTURES_ONLY'
      OR CURRENT_TRANSACTION() IS NOT NULL) THEN RAISE v_guard; END IF;
  LET v_marker VARCHAR := v_db || '.STANDARDIZE_AUDIT.' || v_prefix || 'ENVIRONMENT';
  SELECT COUNT(*) INTO :v_n FROM IDENTIFIER(:v_marker) WHERE PACKAGE_VERSION = 'M0-SQL-ONLY-2' AND DATABASE_NAME = :v_db AND OBJECT_PREFIX = :v_prefix AND ACCOUNT_NAME = :v_account;
  IF (v_n <> 1) THEN RAISE v_guard; END IF;
  v_sql := REPLACE(REPLACE('DECLARE
  v_kind VARCHAR := $Q_PAIR_KIND;
  v_run VARCHAR := UUID_STRING();
  v_feed_a NUMBER; v_feed_b NUMBER;
  v_guid_a VARCHAR := UUID_STRING(); v_guid_b VARCHAR := UUID_STRING();
  v_initial NUMBER; v_n NUMBER;
  v_bad EXCEPTION (-20992,''Invalid pair kind, active run, or deployment not complete'');
BEGIN
  IF (v_kind NOT IN (''COMMIT'',''ROLLBACK'',''PREVIEW'') OR v_kind IS NULL) THEN RAISE v_bad; END IF;
  SELECT COUNT(*) INTO :v_n FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RUN WHERE RUN_STATUS=''RUNNING'';
  IF (v_n<>0) THEN RAISE v_bad; END IF;
  SELECT @DB@.STANDARDIZE_AUDIT.@P@FEED_SEQUENCE.NEXTVAL,@DB@.STANDARDIZE_AUDIT.@P@FEED_SEQUENCE.NEXTVAL INTO :v_feed_a,:v_feed_b;
  SELECT VALUE INTO :v_initial FROM @DB@.STANDARDIZE_CORE.@P@PROTOTYPE_BUSINESS WHERE ID=1;
  INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_RUN VALUES (:v_run,''SERIALIZATION'',CURRENT_TIMESTAMP(),NULL,''RUNNING'',
    OBJECT_CONSTRUCT(''account'',CURRENT_ACCOUNT(),''database'',CURRENT_DATABASE(),''role'',CURRENT_ROLE(),''warehouse'',CURRENT_WAREHOUSE(),''prefix'',''@P@''),''M0-SQL-ONLY-2'');
  INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@SERIAL_PAIR VALUES (:v_run,:v_kind,:v_feed_a,:v_feed_b,:v_guid_a,:v_guid_b,:v_initial,CURRENT_TIMESTAMP());
  INSERT INTO @DB@.STANDARDIZE_STAGE.@P@SCENARIO
    SELECT :v_feed_a,30,:v_kind=''ROLLBACK'',FALSE UNION ALL SELECT :v_feed_b,0,FALSE,FALSE;
  INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@AUTOMATION_LOG (AUTOMATION_GUID,AUTOMATION_NAME,START_DATE,AUTOMATION_STATUS)
    SELECT :v_guid_a,''M0_SERIAL_A'',CURRENT_TIMESTAMP(),''RUNNING''
    UNION ALL SELECT :v_guid_b,''M0_SERIAL_B'',CURRENT_TIMESTAMP(),''RUNNING'';
  INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@FEED_INSTANCE
    SELECT :v_feed_a,:v_guid_a,99,140,''RUNNING'',CURRENT_TIMESTAMP(),NULL,CURRENT_TIMESTAMP()
    UNION ALL SELECT :v_feed_b,:v_guid_b,99,140,''RUNNING'',CURRENT_TIMESTAMP(),NULL,CURRENT_TIMESTAMP();
  INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT (RUN_ID,TEST_ID,DISPOSITION,STATUS,FEED_INSTANCE_ID,AUTOMATION_GUID)
    SELECT :v_run,''SERIAL-A'',''REQUIRED'',''NOT_RUN'',:v_feed_a,:v_guid_a
    UNION ALL SELECT :v_run,''SERIAL-B'',''REQUIRED'',''NOT_RUN'',:v_feed_b,:v_guid_b;
  RETURN OBJECT_CONSTRUCT(''runId'',v_run,''pairKind'',v_kind,''instruction'',''Copy runId into 05b/05c/05d. Start B in independent session, then A within 90 seconds.'');
END;
', '@DB@', v_db), '@P@', v_prefix);
  v_rows := (EXECUTE IMMEDIATE :v_sql);
  RETURN TABLE(v_rows);
END;
$$;
