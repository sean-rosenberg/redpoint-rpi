# Approved reduced qualification scope

On October 19 the user approved the JSON OUT/caller contract and accepted removing permission/ownership, transaction, timeout, logging-error, and locking tests except where necessary to validate serialization. This revises qualification coverage; it does not remove implementation requirements for atomicity, supported caller settings, owner execution, logging, or error preservation.

| Coverage | Disposition |
| --- | --- |
| Production baseline compilation and PB01–PB20 synthetic results | Required in this M0 revision. Original oracles preserved; expected errors must arise during invocation. Compare multiplicity and preserve all original XREF fields. |
| JSON SUCCESS/error/identity/preview/zero-work and caller logging/action | Required M0 prototype checks. Caught business errors return JSON; escaping errors are retained by the runner. |
| Exactly-one-row gate, no legacy/default-argument bypass | Required serialization/entry prerequisites. No real old allocator is installed under the prototype name. |
| Two sessions, A commit/rollback/preview, B waits and observes fresh state | Required M0 serialization; future actual allocator overlap remains deferred T18. Includes preparation/cleanup/audit-helper path necessary to assess early lock release. |
| Permission/ownership/grant matrix, non-owner privileges | EXCLUDED; execution NOT_RUN. Existing role privileges remain a prerequisite. Signature-specific production grants/cutover remain deployment work. |
| Caller-transaction/AUTOCOMMIT matrix, transactional truncate/cleanup/rollback fault injection | EXCLUDED; execution NOT_RUN. Normal preview and the rollback necessary to validate serialization remain. |
| Exact 60-second timeout and additional lock/acquisition failures | EXCLUDED; execution NOT_RUN. Configure the documented timeout; no timeout qualification claim. |
| Audit initialization/secondary logging/rollback failure and post-commit uncertainty fault injection | EXCLUDED; execution NOT_RUN. Preserve original-error/truthful-persistence/no-blind-retry requirements; they are not fully qualified by normal JSON tests. |
| Target PB01–PB20, target T01–T23 retained portions | DEFERRED until actual allocator/migration exists; no implementation is substituted by the M0 marker. T16/T17/T21 fault suites are excluded. T01/T19/T20/T22 retain only their revised portions; T18 remains required. |
| Actual RPDM argument binding, deployed callers/consumers, metadata and historical reservation reconstruction | Outstanding integration/migration dependencies. M0 mock success does not prove these facts. |
| Representative workload, including first-run blocked/unused reservation growth | Future T23; NOT_RUN. Keep baseline/target coverage and workload volumes separate; no performance claim from tiny fixtures. |

The original M0 gate is not retroactively satisfied. The **reduced M0 gate** requires the new local identity checks, successful target-account deployment, all executable sequential checks, all three serialization checks, saved raw evidence, and a reviewed disposition of failures. Exclusions are never counted as passes. Deferred real allocator work remains a later gate. No production execution, grant changes, migration, or release is authorized by a reduced M0 pass.

The old registry includes two parser-generated header rows (`TARGET-Target`, `TARGET-Test`) that are not real check IDs. They are omitted from this revision, with the original registry preserved. Genuine historical check IDs and PB oracles remain traceable. CR1's original ten modeled results are still [historical evidence](../fixtures/historical-cr1-ten-results.md), not the production baseline or current execution evidence.
