# Local review and limitations

The review checked prefix routing, nested SQL quoting, explicit OUT binding, original-error capture before secondary handling, caller logging/error branching, exactly-one-row gate enforcement, independent log access, and two-session evidence conditions. The prototype gate precedes work truncation and the marker read. No real allocation, reservation, or migration code was added. The mock caller records full JSON plus an explicit CONTINUE/STOP/RECONCILE action; the real RPDM integration remains outstanding.

All original M0 artifacts and both supplied procedures are unchanged. The five edited documents have byte-preserved pre-revision copies and exact final diffs. The new baseline changes reverse exactly to the existing normalized baseline after removing identifier substitutions. Original production behavior is not edited to match target expectations. PB14 remains conditional on effective null ordering and PB15 records the production conversion behavior; Snowflake observations may reveal an oracle/environment discrepancy that must be retained and reviewed.

The first local validation attempt failed on validator path/Windows text-decoding assumptions and an added final newline in the generated baseline template. Those were corrected; the failed report remains in `attempts/`. No failing Snowflake output exists because no Snowflake operation was performed. Local lexical checks are not a SQL parser/compiler and do not establish server compatibility.

The package manifest excludes itself, the current local-validation report, mutable `attempts/`, and future `runs/` directories. It includes the authoring sources, emitted SQL, fixtures, input identities, before-document snapshots, and documentation diffs. It separately hashes the five current documents. The local validation report records the manifest hash. Each database deployment records the exact rendered SQL/hash independently; each test definition records a hash of its three rendered SQL texts joined with ASCII character 31. Keep raw failures alongside later successes.

Snowflake documentation checked during preparation:

- [SQL procedure output arguments](https://docs.snowflake.com/en/developer-guide/stored-procedure/stored-procedures-snowflake-scripting#using-output-arguments-to-return-values): local scripting-variable OUT capture and SQL-only support.
- [Dynamic SQL](https://docs.snowflake.com/en/sql-reference/sql/execute-immediate): single statements/blocks, procedure calls, and bind variables.
- [RESULTSETs](https://docs.snowflake.com/en/developer-guide/snowflake-scripting/resultsets): dynamic result capture and RETURN TABLE for worksheet export.
- [Transactions](https://docs.snowflake.com/en/sql-reference/transactions): scoped transactions, DDL commit boundaries, and lock release behavior.

These references support the design; they are not evidence that this package has compiled or run in the user's account.
