-- Select the approved test database/role/warehouse in your worksheet first.
-- Run this in EVERY session. Replace both REPLACE values; use a new unused prefix.
-- This file creates no database/schema, changes no role/grants, and runs no tests.
SELECT CURRENT_ACCOUNT() AS ACCOUNT_LOCATOR, CURRENT_DATABASE(), CURRENT_ROLE(), CURRENT_WAREHOUSE(), CURRENT_SESSION();
SET Q_ACCOUNT = 'REPLACE_WITH_ACCOUNT_LOCATOR';
SET Q_DATABASE = 'REPLACE_WITH_TEST_DATABASE';
SET Q_PREFIX = 'M0_';
SET Q_ACK = 'ISOLATED_PREFIX_FIXTURES_ONLY';
-- Generated locally; Snowflake compilation/execution NOT_RUN. See README.md.
EXECUTE IMMEDIATE $$
DECLARE
  v_db VARCHAR := $Q_DATABASE;
  v_prefix VARCHAR := $Q_PREFIX;
  v_account VARCHAR := $Q_ACCOUNT;
  v_ack VARCHAR := $Q_ACK;
  v_sql VARCHAR;
  v_n NUMBER;
  v_guard EXCEPTION (-20990, 'Qualification guard failed: check account, database, prefix, marker, and caller transaction');
BEGIN
  IF (v_db IS NULL OR v_prefix IS NULL OR v_account IS NULL OR v_ack IS NULL
      OR NOT REGEXP_LIKE(v_db, '^[A-Z][A-Z0-9_]*$')
      OR NOT REGEXP_LIKE(v_prefix, '^M[0-9]+_$')
      OR v_account <> CURRENT_ACCOUNT() OR v_db <> CURRENT_DATABASE()
      OR v_ack <> 'ISOLATED_PREFIX_FIXTURES_ONLY'
      OR CURRENT_TRANSACTION() IS NOT NULL) THEN RAISE v_guard; END IF;
  EXECUTE IMMEDIATE 'ALTER SESSION SET AUTOCOMMIT = TRUE';
  EXECUTE IMMEDIATE 'ALTER SESSION SET LOCK_TIMEOUT = 60';
  EXECUTE IMMEDIATE 'ALTER SESSION SET DEFAULT_NULL_ORDERING = LAST';
  EXECUTE IMMEDIATE 'ALTER SESSION SET QUERY_TAG = ''M0-SQL-ONLY-2''';
  RETURN 'CONFIGURATION_VALIDATED';
END;
$$;

SHOW PARAMETERS LIKE 'AUTOCOMMIT' IN SESSION;
SHOW PARAMETERS LIKE 'LOCK_TIMEOUT' IN SESSION;
SHOW PARAMETERS LIKE 'DEFAULT_NULL_ORDERING' IN SESSION;
