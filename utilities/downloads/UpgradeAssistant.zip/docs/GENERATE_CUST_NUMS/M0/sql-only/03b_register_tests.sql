-- Generated locally; Snowflake compilation/execution NOT_RUN. See README.md.
EXECUTE IMMEDIATE $$
DECLARE
  v_db VARCHAR := $Q_DATABASE;
  v_prefix VARCHAR := $Q_PREFIX;
  v_account VARCHAR := $Q_ACCOUNT;
  v_ack VARCHAR := $Q_ACK;
  v_sql VARCHAR;
  v_n NUMBER;
  v_guard EXCEPTION (-20990, 'Qualification guard failed: check account, database, prefix, marker, and caller transaction');
BEGIN
  IF (v_db IS NULL OR v_prefix IS NULL OR v_account IS NULL OR v_ack IS NULL
      OR NOT REGEXP_LIKE(v_db, '^[A-Z][A-Z0-9_]*$')
      OR NOT REGEXP_LIKE(v_prefix, '^M[0-9]+_$')
      OR v_account <> CURRENT_ACCOUNT() OR v_db <> CURRENT_DATABASE()
      OR v_ack <> 'ISOLATED_PREFIX_FIXTURES_ONLY'
      OR CURRENT_TRANSACTION() IS NOT NULL) THEN RAISE v_guard; END IF;
  LET v_marker VARCHAR := v_db || '.STANDARDIZE_AUDIT.' || v_prefix || 'ENVIRONMENT';
  SELECT COUNT(*) INTO :v_n FROM IDENTIFIER(:v_marker) WHERE PACKAGE_VERSION = 'M0-SQL-ONLY-2' AND DATABASE_NAME = :v_db AND OBJECT_PREFIX = :v_prefix AND ACCOUNT_NAME = :v_account;
  IF (v_n <> 1) THEN RAISE v_guard; END IF;
  LET v_defs VARCHAR := v_db || '.STANDARDIZE_AUDIT.' || v_prefix || 'TEST_DEFINITION';
  SELECT COUNT(*) INTO :v_n FROM IDENTIFIER(:v_defs);
  IF (v_n<>0) THEN RAISE v_guard; END IF;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''BASELINE-PB01'',''BASELINE'',''Exact NON_ACTIVE is a new target block'',''REQUIRED'',''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE (SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID) VALUES (''''10'''',100000000007,''''42'''',''''NON_ACTIVE'''',''''2026-10-02 00:00:00'''',''''ICON'''',701);
END;'',''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;'',''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',PARSE_JSON(''{"newAssignments":[[100000000007,42,"new_external_cust_num",701]],"error":null,"newReservations":[],"note":"","rows":[[100000000007,42,"new_external_cust_num",701]],"retainedRows":[]}''),''03 deployment successful; no concurrent suite on this prefix'',SHA2(''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE (SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID) VALUES (''''10'''',100000000007,''''42'''',''''NON_ACTIVE'''',''''2026-10-02 00:00:00'''',''''ICON'''',701);
END;''||CHR(31)||''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;''||CHR(31)||''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-PB01'',''TARGET'',''Exact NON_ACTIVE is a new target block'',''DEFERRED'','''','''','''',PARSE_JSON(''{"newAssignments":[[100000000007,500000001,"new_cdp_cust_num",701]],"error":null,"newReservations":[{"custNum":42,"recType":"nonactive_external_cust_num","createDate":"CURRENT_INVOCATION_TIME","createFeedInstanceId":900001,"originatingFeedInstanceId":701,"sourcePartyProfileId":"10"}],"note":""}''),''M1-M4 allocator and reconciled reservation baseline; M0 wrapper is NOT this implementation'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''BASELINE-PB02'',''BASELINE'',''Global leading-zero block across ICON and MAO'',''REQUIRED'',''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE (SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID) VALUES (''''10'''',100000000007,''''00042'''',''''NON_ACTIVE'''',''''2026-10-02 00:00:00'''',''''ICON'''',701),(''''2'''',100000000008,''''42'''',''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''MAO'''',702);
END;'',''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;'',''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',PARSE_JSON(''{"newAssignments":[[100000000007,42,"new_external_cust_num",701],[100000000008,500000001,"new_cdp_cust_num",702]],"error":null,"newReservations":[],"note":"","rows":[[100000000007,42,"new_external_cust_num",701],[100000000008,500000001,"new_cdp_cust_num",702]],"retainedRows":[]}''),''03 deployment successful; no concurrent suite on this prefix'',SHA2(''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE (SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID) VALUES (''''10'''',100000000007,''''00042'''',''''NON_ACTIVE'''',''''2026-10-02 00:00:00'''',''''ICON'''',701),(''''2'''',100000000008,''''42'''',''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''MAO'''',702);
END;''||CHR(31)||''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;''||CHR(31)||''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-PB02'',''TARGET'',''Global leading-zero block across ICON and MAO'',''DEFERRED'','''','''','''',PARSE_JSON(''{"newAssignments":[[100000000007,500000001,"new_cdp_cust_num",701],[100000000008,500000002,"new_cdp_cust_num",702]],"error":null,"newReservations":[{"custNum":42,"recType":"nonactive_external_cust_num","createDate":"CURRENT_INVOCATION_TIME","createFeedInstanceId":900001,"originatingFeedInstanceId":701,"sourcePartyProfileId":"10"}],"note":""}''),''M1-M4 allocator and reconciled reservation baseline; M0 wrapper is NOT this implementation'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''BASELINE-PB03'',''BASELINE'',''Preserve original no fallback: loser has 102'',''REQUIRED'',''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE (SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID) VALUES (''''10'''',100000000007,''''101'''',''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''ICON'''',701),(''''10'''',100000000008,''''101'''',''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''ICON'''',701),(''''2'''',100000000008,''''102'''',''''ACTIVE'''',''''2026-10-01 00:00:00'''',''''ICON'''',702);
END;'',''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;'',''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',PARSE_JSON(''{"newAssignments":[[100000000007,101,"new_external_cust_num",701],[100000000008,500000001,"new_cdp_cust_num",702]],"error":null,"newReservations":[[102,102,"merged_external_cust_num",702]],"note":"","rows":[[100000000007,101,"new_external_cust_num",701],[100000000008,500000001,"new_cdp_cust_num",702],[102,102,"merged_external_cust_num",702]],"retainedRows":[]}''),''03 deployment successful; no concurrent suite on this prefix'',SHA2(''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE (SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID) VALUES (''''10'''',100000000007,''''101'''',''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''ICON'''',701),(''''10'''',100000000008,''''101'''',''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''ICON'''',701),(''''2'''',100000000008,''''102'''',''''ACTIVE'''',''''2026-10-01 00:00:00'''',''''ICON'''',702);
END;''||CHR(31)||''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;''||CHR(31)||''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-PB03'',''TARGET'',''Preserve original no fallback: loser has 102'',''DEFERRED'','''','''','''',PARSE_JSON(''{"newAssignments":[[100000000007,101,"new_external_cust_num",701],[100000000008,500000001,"new_cdp_cust_num",702]],"error":null,"newReservations":[{"custNum":102,"recType":"merged_external_cust_num","createDate":"CURRENT_INVOCATION_TIME","createFeedInstanceId":900001,"originatingFeedInstanceId":702,"sourcePartyProfileId":"2"}],"note":""}''),''M1-M4 allocator and reconciled reservation baseline; M0 wrapper is NOT this implementation'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''BASELINE-PB04'',''BASELINE'',''No rebalancing: lower ID owns losing alternative'',''REQUIRED'',''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE (SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID) VALUES (''''10'''',100000000007,''''101'''',''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''ICON'''',701),(''''2'''',100000000007,''''102'''',''''ACTIVE'''',''''2026-10-01 00:00:00'''',''''ICON'''',701),(''''10'''',100000000008,''''102'''',''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''ICON'''',701);
END;'',''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;'',''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',PARSE_JSON(''{"newAssignments":[[100000000007,101,"new_external_cust_num",701],[100000000008,500000001,"new_cdp_cust_num",701]],"error":null,"newReservations":[[102,102,"merged_external_cust_num",701]],"note":"","rows":[[100000000007,101,"new_external_cust_num",701],[100000000008,500000001,"new_cdp_cust_num",701],[102,102,"merged_external_cust_num",701]],"retainedRows":[]}''),''03 deployment successful; no concurrent suite on this prefix'',SHA2(''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE (SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID) VALUES (''''10'''',100000000007,''''101'''',''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''ICON'''',701),(''''2'''',100000000007,''''102'''',''''ACTIVE'''',''''2026-10-01 00:00:00'''',''''ICON'''',701),(''''10'''',100000000008,''''102'''',''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''ICON'''',701);
END;''||CHR(31)||''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;''||CHR(31)||''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-PB04'',''TARGET'',''No rebalancing: lower ID owns losing alternative'',''DEFERRED'','''','''','''',PARSE_JSON(''{"newAssignments":[[100000000007,101,"new_external_cust_num",701],[100000000008,500000001,"new_cdp_cust_num",701]],"error":null,"newReservations":[{"custNum":102,"recType":"merged_external_cust_num","createDate":"CURRENT_INVOCATION_TIME","createFeedInstanceId":900001,"originatingFeedInstanceId":701,"sourcePartyProfileId":"2"}],"note":""}''),''M1-M4 allocator and reconciled reservation baseline; M0 wrapper is NOT this implementation'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''BASELINE-PB05'',''BASELINE'',''Mapped individual carries newly unused external 77'',''REQUIRED'',''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE (SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID) VALUES (''''10'''',100000000007,''''77'''',''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''ICON'''',701);
INSERT INTO @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF (INDIVIDUAL_ID,CUST_NUM,REC_TYPE,CREATE_DATE,CREATE_FEED_INSTANCE_ID) VALUES (100000000007,42,''''new_external_cust_num'''',''''2026-10-01 00:00:00'''',690);
END;'',''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;'',''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',PARSE_JSON(''{"newAssignments":[],"error":null,"newReservations":[],"note":"Existing assignment unchanged; 77 not reserved","rows":[[100000000007,42,"new_external_cust_num",690]],"retainedRows":[[100000000007,42,"new_external_cust_num","2026-10-01 00:00:00",690]]}''),''03 deployment successful; no concurrent suite on this prefix'',SHA2(''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE (SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID) VALUES (''''10'''',100000000007,''''77'''',''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''ICON'''',701);
INSERT INTO @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF (INDIVIDUAL_ID,CUST_NUM,REC_TYPE,CREATE_DATE,CREATE_FEED_INSTANCE_ID) VALUES (100000000007,42,''''new_external_cust_num'''',''''2026-10-01 00:00:00'''',690);
END;''||CHR(31)||''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;''||CHR(31)||''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-PB05'',''TARGET'',''Mapped individual carries newly unused external 77'',''DEFERRED'','''','''','''',PARSE_JSON(''{"newAssignments":[],"error":null,"newReservations":[{"custNum":77,"recType":"unused_external_cust_num","createDate":"CURRENT_INVOCATION_TIME","createFeedInstanceId":900001,"originatingFeedInstanceId":701,"sourcePartyProfileId":"10"}],"note":"Existing assignment unchanged; fresh reservation, not migrated history"}''),''M1-M4 allocator and reconciled reservation baseline; M0 wrapper is NOT this implementation'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''BASELINE-PB06'',''BASELINE'',''Current NON_ACTIVE must not revoke existing assignment'',''REQUIRED'',''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE (SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID) VALUES (''''10'''',100000000007,''''42'''',''''NON_ACTIVE'''',''''2026-10-02 00:00:00'''',''''ICON'''',701);
INSERT INTO @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF (INDIVIDUAL_ID,CUST_NUM,REC_TYPE,CREATE_DATE,CREATE_FEED_INSTANCE_ID) VALUES (100000000007,42,''''new_external_cust_num'''',''''2026-10-01 00:00:00'''',690);
END;'',''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;'',''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',PARSE_JSON(''{"newAssignments":[],"error":null,"newReservations":[],"note":"","rows":[[100000000007,42,"new_external_cust_num",690]],"retainedRows":[[100000000007,42,"new_external_cust_num","2026-10-01 00:00:00",690]]}''),''03 deployment successful; no concurrent suite on this prefix'',SHA2(''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE (SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID) VALUES (''''10'''',100000000007,''''42'''',''''NON_ACTIVE'''',''''2026-10-02 00:00:00'''',''''ICON'''',701);
INSERT INTO @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF (INDIVIDUAL_ID,CUST_NUM,REC_TYPE,CREATE_DATE,CREATE_FEED_INSTANCE_ID) VALUES (100000000007,42,''''new_external_cust_num'''',''''2026-10-01 00:00:00'''',690);
END;''||CHR(31)||''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;''||CHR(31)||''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-PB06'',''TARGET'',''Current NON_ACTIVE must not revoke existing assignment'',''DEFERRED'','''','''','''',PARSE_JSON(''{"newAssignments":[],"error":null,"newReservations":[],"note":"Preserve all existing assignment fields; no overlapping reservation"}''),''M1-M4 allocator and reconciled reservation baseline; M0 wrapper is NOT this implementation'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''BASELINE-PB07'',''BASELINE'',''Empty generated history; non-ICON discovery'',''REQUIRED'',''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE (SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID) VALUES (''''10'''',100000000007,NULL,''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''OTHER'''',701);
END;'',''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;'',''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',PARSE_JSON(''{"newAssignments":[[100000000007,500000001,"new_cdp_cust_num",701]],"error":null,"newReservations":[],"note":"","rows":[[100000000007,500000001,"new_cdp_cust_num",701]],"retainedRows":[]}''),''03 deployment successful; no concurrent suite on this prefix'',SHA2(''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE (SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID) VALUES (''''10'''',100000000007,NULL,''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''OTHER'''',701);
END;''||CHR(31)||''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;''||CHR(31)||''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-PB07'',''TARGET'',''Empty generated history; non-ICON discovery'',''DEFERRED'','''','''','''',PARSE_JSON(''{"newAssignments":[[100000000007,500000001,"new_cdp_cust_num",701]],"error":null,"newReservations":[],"note":""}''),''M1-M4 allocator and reconciled reservation baseline; M0 wrapper is NOT this implementation'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''BASELINE-PB08'',''BASELINE'',''Generated exhaustion'',''REQUIRED'',''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE (SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID) VALUES (''''10'''',100000000008,NULL,''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''OTHER'''',701);
INSERT INTO @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF (INDIVIDUAL_ID,CUST_NUM,REC_TYPE,CREATE_DATE,CREATE_FEED_INSTANCE_ID) VALUES (100000000007,599999999,''''new_cdp_cust_num'''',''''2026-10-01 00:00:00'''',690);
END;'',''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;'',''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',PARSE_JSON(''{"newAssignments":[],"error":"-20005","newReservations":[],"note":"Range check after staging, not -20008; no CORE insert, permanent work/debug can persist","rows":[[100000000007,599999999,"new_cdp_cust_num",690]],"retainedRows":[[100000000007,599999999,"new_cdp_cust_num","2026-10-01 00:00:00",690]]}''),''03 deployment successful; no concurrent suite on this prefix'',SHA2(''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE (SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID) VALUES (''''10'''',100000000008,NULL,''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''OTHER'''',701);
INSERT INTO @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF (INDIVIDUAL_ID,CUST_NUM,REC_TYPE,CREATE_DATE,CREATE_FEED_INSTANCE_ID) VALUES (100000000007,599999999,''''new_cdp_cust_num'''',''''2026-10-01 00:00:00'''',690);
END;''||CHR(31)||''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;''||CHR(31)||''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-PB08'',''TARGET'',''Generated exhaustion'',''DEFERRED'','''','''','''',PARSE_JSON(''{"newAssignments":[],"error":"GENERATED_CAPACITY","newReservations":[],"note":"Fail before apply; no numeric target error code assigned in M0"}''),''M1-M4 allocator and reconciled reservation baseline; M0 wrapper is NOT this implementation'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''BASELINE-PB09'',''BASELINE'',''Invalid CORE ID occupies only external key'',''REQUIRED'',''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE (SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID) VALUES (''''10'''',100000000007,''''42'''',''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''ICON'''',701);
INSERT INTO @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF (INDIVIDUAL_ID,CUST_NUM,REC_TYPE,CREATE_DATE,CREATE_FEED_INSTANCE_ID) VALUES (42,500000001,''''new_cdp_cust_num'''',''''2026-10-01 00:00:00'''',690);
END;'',''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;'',''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',PARSE_JSON(''{"newAssignments":[[100000000007,500000002,"new_cdp_cust_num",701]],"error":null,"newReservations":[],"note":"42 unavailable by either-key occupancy; no completeness -20007","rows":[[42,500000001,"new_cdp_cust_num",690],[100000000007,500000002,"new_cdp_cust_num",701]],"retainedRows":[[42,500000001,"new_cdp_cust_num","2026-10-01 00:00:00",690]]}''),''03 deployment successful; no concurrent suite on this prefix'',SHA2(''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE (SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID) VALUES (''''10'''',100000000007,''''42'''',''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''ICON'''',701);
INSERT INTO @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF (INDIVIDUAL_ID,CUST_NUM,REC_TYPE,CREATE_DATE,CREATE_FEED_INSTANCE_ID) VALUES (42,500000001,''''new_cdp_cust_num'''',''''2026-10-01 00:00:00'''',690);
END;''||CHR(31)||''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;''||CHR(31)||''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-PB09'',''TARGET'',''Invalid CORE ID occupies only external key'',''DEFERRED'','''','''','''',PARSE_JSON(''{"newAssignments":[],"error":"CORE_INTEGRITY","newReservations":[],"note":""}''),''M1-M4 allocator and reconciled reservation baseline; M0 wrapper is NOT this implementation'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''BASELINE-PB10'',''BASELINE'',''Invalid real ID collides with merged reservation'',''REQUIRED'',''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE (SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID) VALUES (''''10'''',100000000007,''''11'''',''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''ICON'''',701),(''''10'''',100000000007,''''42'''',''''ACTIVE'''',''''2026-10-01 00:00:00'''',''''ICON'''',701),(''''10'''',42,NULL,''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''OTHER'''',701);
END;'',''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;'',''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',PARSE_JSON(''{"newAssignments":[],"error":"-20013","newReservations":[],"note":"","rows":[],"retainedRows":[]}''),''03 deployment successful; no concurrent suite on this prefix'',SHA2(''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE (SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID) VALUES (''''10'''',100000000007,''''11'''',''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''ICON'''',701),(''''10'''',100000000007,''''42'''',''''ACTIVE'''',''''2026-10-01 00:00:00'''',''''ICON'''',701),(''''10'''',42,NULL,''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''OTHER'''',701);
END;''||CHR(31)||''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;''||CHR(31)||''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-PB10'',''TARGET'',''Invalid real ID collides with merged reservation'',''DEFERRED'','''','''','''',PARSE_JSON(''{"newAssignments":[],"error":"SOURCE_ID_VALIDITY","newReservations":[],"note":""}''),''M1-M4 allocator and reconciled reservation baseline; M0 wrapper is NOT this implementation'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''BASELINE-PB11'',''BASELINE'',''Legacy reservation masks invalid individual 42'',''REQUIRED'',''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE (SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID) VALUES (''''10'''',42,NULL,''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''OTHER'''',701);
INSERT INTO @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF (INDIVIDUAL_ID,CUST_NUM,REC_TYPE,CREATE_DATE,CREATE_FEED_INSTANCE_ID) VALUES (42,42,''''merged_external_cust_num'''',''''2026-10-01 00:00:00'''',690);
END;'',''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;'',''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',PARSE_JSON(''{"newAssignments":[],"error":null,"newReservations":[],"note":"No new assignment","rows":[[42,42,"merged_external_cust_num",690]],"retainedRows":[[42,42,"merged_external_cust_num","2026-10-01 00:00:00",690]]}''),''03 deployment successful; no concurrent suite on this prefix'',SHA2(''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE (SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID) VALUES (''''10'''',42,NULL,''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''OTHER'''',701);
INSERT INTO @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF (INDIVIDUAL_ID,CUST_NUM,REC_TYPE,CREATE_DATE,CREATE_FEED_INSTANCE_ID) VALUES (42,42,''''merged_external_cust_num'''',''''2026-10-01 00:00:00'''',690);
END;''||CHR(31)||''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;''||CHR(31)||''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-PB11'',''TARGET'',''Legacy reservation masks invalid individual 42'',''DEFERRED'','''','''','''',PARSE_JSON(''{"newAssignments":[],"error":"SOURCE_ID_VALIDITY","newReservations":[],"note":"Reservation itself requires separate historical lineage migration checks"}''),''M1-M4 allocator and reconciled reservation baseline; M0 wrapper is NOT this implementation'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''BASELINE-PB12'',''BASELINE'',''NULL source with CORE zero differs from historical reference'',''REQUIRED'',''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE (SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID) VALUES (''''10'''',NULL,NULL,''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''OTHER'''',701);
INSERT INTO @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF (INDIVIDUAL_ID,CUST_NUM,REC_TYPE,CREATE_DATE,CREATE_FEED_INSTANCE_ID) VALUES (0,600000001,''''new_external_cust_num'''',''''2026-10-01 00:00:00'''',690);
END;'',''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;'',''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',PARSE_JSON(''{"newAssignments":[],"error":null,"newReservations":[],"note":"NOT IN UNKNOWN removes source before generated planning; no OR-MERGE proposal exists","rows":[[0,600000001,"new_external_cust_num",690]],"retainedRows":[[0,600000001,"new_external_cust_num","2026-10-01 00:00:00",690]]}''),''03 deployment successful; no concurrent suite on this prefix'',SHA2(''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE (SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID) VALUES (''''10'''',NULL,NULL,''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''OTHER'''',701);
INSERT INTO @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF (INDIVIDUAL_ID,CUST_NUM,REC_TYPE,CREATE_DATE,CREATE_FEED_INSTANCE_ID) VALUES (0,600000001,''''new_external_cust_num'''',''''2026-10-01 00:00:00'''',690);
END;''||CHR(31)||''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;''||CHR(31)||''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-PB12'',''TARGET'',''NULL source with CORE zero differs from historical reference'',''DEFERRED'','''','''','''',PARSE_JSON(''{"newAssignments":[],"error":"CORE_INTEGRITY or SOURCE_ID_VALIDITY","newReservations":[],"note":"Both violations must stop before planning; first failing check ordering is not fixed"}''),''M1-M4 allocator and reconciled reservation baseline; M0 wrapper is NOT this implementation'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''BASELINE-PB13'',''BASELINE'',''NULL source with empty CORE'',''REQUIRED'',''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE (SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID) VALUES (''''10'''',NULL,NULL,''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''OTHER'''',701);
END;'',''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;'',''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',PARSE_JSON(''{"newAssignments":[],"error":"NOT_NULL_CONSTRAINT","newReservations":[],"note":"NOT IN empty relation admits NULL; staged NULL generated ID then fails supplied CORE constraint; capture actual SQL code","rows":[],"retainedRows":[]}''),''03 deployment successful; no concurrent suite on this prefix'',SHA2(''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE (SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID) VALUES (''''10'''',NULL,NULL,''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''OTHER'''',701);
END;''||CHR(31)||''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;''||CHR(31)||''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-PB13'',''TARGET'',''NULL source with empty CORE'',''DEFERRED'','''','''','''',PARSE_JSON(''{"newAssignments":[],"error":"SOURCE_ID_VALIDITY","newReservations":[],"note":""}''),''M1-M4 allocator and reconciled reservation baseline; M0 wrapper is NOT this implementation'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''BASELINE-PB14'',''BASELINE'',''Known date vs NULL under default owner-account null ordering'',''REQUIRED'',''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE (SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID) VALUES (''''10'''',100000000007,''''101'''',''''ACTIVE'''',NULL,''''ICON'''',701),(''''2'''',100000000007,''''102'''',''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''ICON'''',701);
END;'',''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;'',''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',PARSE_JSON(''{"newAssignments":[[100000000007,101,"new_external_cust_num",701]],"error":null,"newReservations":[[102,102,"merged_external_cust_num",701]],"note":"Conditional on effective DEFAULT_NULL_ORDERING=LAST; reverse expected 101/102 under FIRST","rows":[[100000000007,101,"new_external_cust_num",701],[102,102,"merged_external_cust_num",701]],"retainedRows":[]}''),''03 deployment successful; no concurrent suite on this prefix'',SHA2(''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE (SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID) VALUES (''''10'''',100000000007,''''101'''',''''ACTIVE'''',NULL,''''ICON'''',701),(''''2'''',100000000007,''''102'''',''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''ICON'''',701);
END;''||CHR(31)||''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;''||CHR(31)||''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-PB14'',''TARGET'',''Known date vs NULL under default owner-account null ordering'',''DEFERRED'','''','''','''',PARSE_JSON(''{"newAssignments":[[100000000007,102,"new_external_cust_num",701]],"error":null,"newReservations":[{"custNum":101,"recType":"merged_external_cust_num","createDate":"CURRENT_INVOCATION_TIME","createFeedInstanceId":900001,"originatingFeedInstanceId":701,"sourcePartyProfileId":"10"}],"note":"Known date wins under either session default"}''),''M1-M4 allocator and reconciled reservation baseline; M0 wrapper is NOT this implementation'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''BASELINE-PB15'',''BASELINE'',''Fractional PK1 rounds under production cast'',''REQUIRED'',''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE (SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID) VALUES (''''10'''',100000000007,''''42.4'''',''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''ICON'''',701);
END;'',''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;'',''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',PARSE_JSON(''{"newAssignments":[[100000000007,42,"new_external_cust_num",701]],"error":null,"newReservations":[],"note":"Target account TRY_CAST rounding must be observed","rows":[[100000000007,42,"new_external_cust_num",701]],"retainedRows":[]}''),''03 deployment successful; no concurrent suite on this prefix'',SHA2(''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE (SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID) VALUES (''''10'''',100000000007,''''42.4'''',''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''ICON'''',701);
END;''||CHR(31)||''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;''||CHR(31)||''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-PB15'',''TARGET'',''Fractional PK1 rounds under production cast'',''DEFERRED'','''','''','''',PARSE_JSON(''{"newAssignments":[[100000000007,500000001,"new_cdp_cust_num",701]],"error":null,"newReservations":[],"note":"Invalid PK1; no reservation for rounded 42"}''),''M1-M4 allocator and reconciled reservation baseline; M0 wrapper is NOT this implementation'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''BASELINE-PB16'',''BASELINE'',''Valid legacy reservation coexists with valid real ID'',''REQUIRED'',''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE (SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID) VALUES (''''10'''',100000000042,''''42'''',''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''ICON'''',701);
INSERT INTO @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF (INDIVIDUAL_ID,CUST_NUM,REC_TYPE,CREATE_DATE,CREATE_FEED_INSTANCE_ID) VALUES (42,42,''''merged_external_cust_num'''',''''2026-10-01 00:00:00'''',690);
END;'',''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;'',''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',PARSE_JSON(''{"newAssignments":[[100000000042,500000001,"new_cdp_cust_num",701]],"error":null,"newReservations":[],"note":"","rows":[[42,42,"merged_external_cust_num",690],[100000000042,500000001,"new_cdp_cust_num",701]],"retainedRows":[[42,42,"merged_external_cust_num","2026-10-01 00:00:00",690]]}''),''03 deployment successful; no concurrent suite on this prefix'',SHA2(''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE (SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID) VALUES (''''10'''',100000000042,''''42'''',''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''ICON'''',701);
INSERT INTO @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF (INDIVIDUAL_ID,CUST_NUM,REC_TYPE,CREATE_DATE,CREATE_FEED_INSTANCE_ID) VALUES (42,42,''''merged_external_cust_num'''',''''2026-10-01 00:00:00'''',690);
END;''||CHR(31)||''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;''||CHR(31)||''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-PB16'',''TARGET'',''Valid legacy reservation coexists with valid real ID'',''DEFERRED'','''','''','''',PARSE_JSON(''{"newAssignments":[[100000000042,500000001,"new_cdp_cust_num",701]],"error":null,"newReservations":[],"note":"Run after verified migration of 42; no new reservation counted; missing lineage blocks migration first"}''),''M1-M4 allocator and reconciled reservation baseline; M0 wrapper is NOT this implementation'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''BASELINE-PB17'',''BASELINE'',''Generated gap not reclaimed'',''REQUIRED'',''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE (SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID) VALUES (''''10'''',100000000008,NULL,''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''OTHER'''',701);
INSERT INTO @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF (INDIVIDUAL_ID,CUST_NUM,REC_TYPE,CREATE_DATE,CREATE_FEED_INSTANCE_ID) VALUES (100000000007,500000010,''''new_cdp_cust_num'''',''''2026-10-01 00:00:00'''',690);
END;'',''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;'',''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',PARSE_JSON(''{"newAssignments":[[100000000008,500000011,"new_cdp_cust_num",701]],"error":null,"newReservations":[],"note":"","rows":[[100000000007,500000010,"new_cdp_cust_num",690],[100000000008,500000011,"new_cdp_cust_num",701]],"retainedRows":[[100000000007,500000010,"new_cdp_cust_num","2026-10-01 00:00:00",690]]}''),''03 deployment successful; no concurrent suite on this prefix'',SHA2(''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE (SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID) VALUES (''''10'''',100000000008,NULL,''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''OTHER'''',701);
INSERT INTO @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF (INDIVIDUAL_ID,CUST_NUM,REC_TYPE,CREATE_DATE,CREATE_FEED_INSTANCE_ID) VALUES (100000000007,500000010,''''new_cdp_cust_num'''',''''2026-10-01 00:00:00'''',690);
END;''||CHR(31)||''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;''||CHR(31)||''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-PB17'',''TARGET'',''Generated gap not reclaimed'',''DEFERRED'','''','''','''',PARSE_JSON(''{"newAssignments":[[100000000008,500000011,"new_cdp_cust_num",701]],"error":null,"newReservations":[],"note":""}''),''M1-M4 allocator and reconciled reservation baseline; M0 wrapper is NOT this implementation'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''BASELINE-PB18'',''BASELINE'',''Duplicate source selected mapping; assignment feed remains individual maximum'',''REQUIRED'',''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE (SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID) VALUES (''''10'''',100000000007,''''42'''',''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''ICON'''',701),(''''2'''',100000000007,''''42'''',''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''ICON'''',799);
END;'',''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;'',''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',PARSE_JSON(''{"newAssignments":[[100000000007,42,"new_external_cust_num",799]],"error":null,"newReservations":[],"note":"One mapping, not duplicate outputs","rows":[[100000000007,42,"new_external_cust_num",799]],"retainedRows":[]}''),''03 deployment successful; no concurrent suite on this prefix'',SHA2(''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE (SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID) VALUES (''''10'''',100000000007,''''42'''',''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''ICON'''',701),(''''2'''',100000000007,''''42'''',''''ACTIVE'''',''''2026-10-02 00:00:00'''',''''ICON'''',799);
END;''||CHR(31)||''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;''||CHR(31)||''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-PB18'',''TARGET'',''Duplicate source selected mapping; assignment feed remains individual maximum'',''DEFERRED'','''','''','''',PARSE_JSON(''{"newAssignments":[[100000000007,42,"new_external_cust_num",799]],"error":null,"newReservations":[],"note":"Reservation-specific lineage correction does not change genuine assignment attribution"}''),''M1-M4 allocator and reconciled reservation baseline; M0 wrapper is NOT this implementation'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''BASELINE-PB19'',''BASELINE'',''Blocked reservation source string order and same-row feed'',''REQUIRED'',''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE (SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID) VALUES (''''10'''',100000000007,''''42'''',''''NON_ACTIVE'''',''''2026-10-02 00:00:00'''',''''ICON'''',701),(''''2'''',100000000007,''''42'''',''''NON_ACTIVE'''',''''2026-10-02 00:00:00'''',''''ICON'''',799);
END;'',''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;'',''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',PARSE_JSON(''{"newAssignments":[[100000000007,42,"new_external_cust_num",799]],"error":null,"newReservations":[],"note":"","rows":[[100000000007,42,"new_external_cust_num",799]],"retainedRows":[]}''),''03 deployment successful; no concurrent suite on this prefix'',SHA2(''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE (SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID) VALUES (''''10'''',100000000007,''''42'''',''''NON_ACTIVE'''',''''2026-10-02 00:00:00'''',''''ICON'''',701),(''''2'''',100000000007,''''42'''',''''NON_ACTIVE'''',''''2026-10-02 00:00:00'''',''''ICON'''',799);
END;''||CHR(31)||''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;''||CHR(31)||''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-PB19'',''TARGET'',''Blocked reservation source string order and same-row feed'',''DEFERRED'','''','''','''',PARSE_JSON(''{"newAssignments":[[100000000007,500000001,"new_cdp_cust_num",799]],"error":null,"newReservations":[{"custNum":42,"recType":"nonactive_external_cust_num","createDate":"CURRENT_INVOCATION_TIME","createFeedInstanceId":900001,"originatingFeedInstanceId":701,"sourcePartyProfileId":"10"}],"note":""}''),''M1-M4 allocator and reconciled reservation baseline; M0 wrapper is NOT this implementation'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''BASELINE-PB20'',''BASELINE'',''Existing genuine invalid lower generated boundary is not repaired'',''REQUIRED'',''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF (INDIVIDUAL_ID,CUST_NUM,REC_TYPE,CREATE_DATE,CREATE_FEED_INSTANCE_ID) VALUES (100000000007,500000000,''''new_cdp_cust_num'''',''''2026-10-01 00:00:00'''',690);
END;'',''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;'',''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',PARSE_JSON(''{"newAssignments":[],"error":null,"newReservations":[],"note":"Production does not range-check retained genuine assignments","rows":[[100000000007,500000000,"new_cdp_cust_num",690]],"retainedRows":[[100000000007,500000000,"new_cdp_cust_num","2026-10-01 00:00:00",690]]}''),''03 deployment successful; no concurrent suite on this prefix'',SHA2(''BEGIN
DELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;
DELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
INSERT INTO @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF (INDIVIDUAL_ID,CUST_NUM,REC_TYPE,CREATE_DATE,CREATE_FEED_INSTANCE_ID) VALUES (100000000007,500000000,''''new_cdp_cust_num'''',''''2026-10-01 00:00:00'''',690);
END;''||CHR(31)||''DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;''||CHR(31)||''DECLARE
  v_expected VARIANT;
  v_actual ARRAY;
  v_diff NUMBER;
  v_preserved NUMBER;
  v_expected_error VARCHAR;
  v_error_ok BOOLEAN;
BEGIN
  SELECT EXPECTED INTO :v_expected FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  SELECT COALESCE(ARRAY_AGG(ARRAY_CONSTRUCT(INDIVIDUAL_ID,CUST_NUM,
    COALESCE(TO_VARIANT(REC_TYPE),PARSE_JSON(''''null'''')),COALESCE(TO_VARIANT(CREATE_FEED_INSTANCE_ID),PARSE_JSON(''''null''''))))
    WITHIN GROUP (ORDER BY INDIVIDUAL_ID,CUST_NUM),ARRAY_CONSTRUCT()) INTO :v_actual
    FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;
  -- Compare multisets, including nulls and multiplicity. New CREATE_DATE is nondeterministic.
  WITH a AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_actual)) GROUP BY VALUE),
       e AS (SELECT VALUE AS ROW_VALUE,COUNT(*) AS N FROM TABLE(FLATTEN(INPUT=>:v_expected:rows)) GROUP BY VALUE),
       missing AS (SELECT * FROM e MINUS SELECT * FROM a),
       extra AS (SELECT * FROM a MINUS SELECT * FROM e)
  SELECT (SELECT COUNT(*) FROM missing)+(SELECT COUNT(*) FROM extra) INTO :v_diff;
  -- Existing assignments/reservations retain all five original fields, including date.
  SELECT COUNT(*) INTO :v_preserved FROM TABLE(FLATTEN(INPUT=>:v_expected:retainedRows)) e
    WHERE NOT EXISTS (SELECT 1 FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF x
      WHERE x.INDIVIDUAL_ID=e.VALUE[0]::NUMBER AND x.CUST_NUM=e.VALUE[1]::NUMBER
      AND EQUAL_NULL(x.REC_TYPE,e.VALUE[2]::VARCHAR) AND x.CREATE_DATE=e.VALUE[3]::TIMESTAMP_NTZ
      AND EQUAL_NULL(x.CREATE_FEED_INSTANCE_ID,e.VALUE[4]::NUMBER));
  v_expected_error := v_expected:error::VARCHAR;
  SELECT CASE WHEN :v_expected_error IS NULL THEN SQLCODE IS NULL AND ACTUAL:returnValue::VARCHAR=''''SUCCESS''''
    WHEN :v_expected_error=''''NOT_NULL_CONSTRAINT'''' THEN SQLCODE IS NOT NULL AND PHASE=''''EXECUTE''''
      AND SQLERRM ILIKE ''''%NULL%'''' AND SQLERRM ILIKE ''''%INDIVIDUAL_ID%''''
    ELSE SQLCODE=TRY_TO_NUMBER(:v_expected_error) AND PHASE=''''EXECUTE'''' END INTO :v_error_ok
    FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET
    ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''rows'''',:v_actual,''''differenceGroups'''',:v_diff,''''changedOriginalRows'''',:v_preserved,
      ''''returnValue'''',ACTUAL:returnValue,''''errorCode'''',SQLCODE,''''errorState'''',SQLSTATE,''''errorMessage'''',SQLERRM),
    ASSERTION_PASS=(:v_diff=0 AND :v_preserved=0 AND COALESCE(:v_error_ok,FALSE))
    WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';
END;
'',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-PB20'',''TARGET'',''Existing genuine invalid lower generated boundary is not repaired'',''DEFERRED'','''','''','''',PARSE_JSON(''{"newAssignments":[],"error":"CORE_INTEGRITY","newReservations":[],"note":"No repair/revocation; reject invocation"}''),''M1-M4 allocator and reconciled reservation baseline; M0 wrapper is NOT this implementation'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''JSON-LIVE'',''CONTRACT'',''OUT JSON and caller action: JSON-LIVE'',''REQUIRED'',''BEGIN
INSERT INTO @DB@.STANDARDIZE_STAGE.@P@SCENARIO VALUES (@FEED@,0,FALSE,FALSE);
INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@AUTOMATION_LOG (AUTOMATION_GUID,AUTOMATION_NAME,START_DATE,AUTOMATION_STATUS) VALUES (''''@GUID@'''',''''M0_CALLER'''',CURRENT_TIMESTAMP(),''''RUNNING'''');
INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@FEED_INSTANCE VALUES (@FEED@,''''@GUID@'''',99,140,''''RUNNING'''',CURRENT_TIMESTAMP(),NULL,CURRENT_TIMESTAMP());
END;'',''DECLARE v_out VARIANT; v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@CALLER_ADAPTER(@FEED@,''''@GUID@'''',FALSE,:v_out) INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''result'''',:v_out,''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;'',''UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ASSERTION_PASS=(ACTUAL:result:status::VARCHAR=''''SUCCESS'''' AND ACTUAL:returnValue::VARCHAR=''''SUCCESS'''' AND ACTUAL:result:persistence::VARCHAR=''''COMMITTED'''' AND ACTUAL:result:scope::VARCHAR=''''M0_PROTOTYPE'''' AND ACTUAL:result:contractVersion::NUMBER=2 AND IS_NULL_VALUE(ACTUAL:result:error) AND ACTUAL:result:feedInstanceId::NUMBER=FEED_INSTANCE_ID AND ACTUAL:result:automationGuid::VARCHAR=AUTOMATION_GUID AND (SELECT COUNT(*) FROM @DB@.STANDARDIZE_AUDIT.@P@FEED_INSTANCE WHERE FEED_INSTANCE_ID=@FEED@ AND FEED_PROCESS_RESULT=''''SUCCESS'''')=1 AND (SELECT COUNT(*) FROM @DB@.STANDARDIZE_AUDIT.@P@AUTOMATION_LOG WHERE AUTOMATION_GUID=''''@GUID@'''' AND AUTOMATION_STATUS=''''SUCCESS'''')=1 AND (SELECT COUNT(*) FROM @DB@.STANDARDIZE_AUDIT.@P@CALLER_ACTION WHERE FEED_INSTANCE_ID=@FEED@ AND ACTION=''''CONTINUE'''')=1) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';'',PARSE_JSON(''{"status":"SUCCESS","persistence":"COMMITTED","sqlcode":null}''),''03 deployment successful; no concurrent suite on this prefix'',SHA2(''BEGIN
INSERT INTO @DB@.STANDARDIZE_STAGE.@P@SCENARIO VALUES (@FEED@,0,FALSE,FALSE);
INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@AUTOMATION_LOG (AUTOMATION_GUID,AUTOMATION_NAME,START_DATE,AUTOMATION_STATUS) VALUES (''''@GUID@'''',''''M0_CALLER'''',CURRENT_TIMESTAMP(),''''RUNNING'''');
INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@FEED_INSTANCE VALUES (@FEED@,''''@GUID@'''',99,140,''''RUNNING'''',CURRENT_TIMESTAMP(),NULL,CURRENT_TIMESTAMP());
END;''||CHR(31)||''DECLARE v_out VARIANT; v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@CALLER_ADAPTER(@FEED@,''''@GUID@'''',FALSE,:v_out) INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''result'''',:v_out,''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;''||CHR(31)||''UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ASSERTION_PASS=(ACTUAL:result:status::VARCHAR=''''SUCCESS'''' AND ACTUAL:returnValue::VARCHAR=''''SUCCESS'''' AND ACTUAL:result:persistence::VARCHAR=''''COMMITTED'''' AND ACTUAL:result:scope::VARCHAR=''''M0_PROTOTYPE'''' AND ACTUAL:result:contractVersion::NUMBER=2 AND IS_NULL_VALUE(ACTUAL:result:error) AND ACTUAL:result:feedInstanceId::NUMBER=FEED_INSTANCE_ID AND ACTUAL:result:automationGuid::VARCHAR=AUTOMATION_GUID AND (SELECT COUNT(*) FROM @DB@.STANDARDIZE_AUDIT.@P@FEED_INSTANCE WHERE FEED_INSTANCE_ID=@FEED@ AND FEED_PROCESS_RESULT=''''SUCCESS'''')=1 AND (SELECT COUNT(*) FROM @DB@.STANDARDIZE_AUDIT.@P@AUTOMATION_LOG WHERE AUTOMATION_GUID=''''@GUID@'''' AND AUTOMATION_STATUS=''''SUCCESS'''')=1 AND (SELECT COUNT(*) FROM @DB@.STANDARDIZE_AUDIT.@P@CALLER_ACTION WHERE FEED_INSTANCE_ID=@FEED@ AND ACTION=''''CONTINUE'''')=1) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';'',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''JSON-PREVIEW'',''CONTRACT'',''OUT JSON and caller action: JSON-PREVIEW'',''REQUIRED'',''BEGIN
INSERT INTO @DB@.STANDARDIZE_STAGE.@P@SCENARIO VALUES (@FEED@,0,FALSE,FALSE);
INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@AUTOMATION_LOG (AUTOMATION_GUID,AUTOMATION_NAME,START_DATE,AUTOMATION_STATUS) VALUES (''''@GUID@'''',''''M0_CALLER'''',CURRENT_TIMESTAMP(),''''RUNNING'''');
INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@FEED_INSTANCE VALUES (@FEED@,''''@GUID@'''',99,140,''''RUNNING'''',CURRENT_TIMESTAMP(),NULL,CURRENT_TIMESTAMP());
END;'',''DECLARE v_out VARIANT; v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@CALLER_ADAPTER(@FEED@,''''@GUID@'''',TRUE,:v_out) INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''result'''',:v_out,''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;'',''UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ASSERTION_PASS=(ACTUAL:result:status::VARCHAR=''''SUCCESS'''' AND ACTUAL:returnValue::VARCHAR=''''SUCCESS'''' AND ACTUAL:result:persistence::VARCHAR=''''NOT_ATTEMPTED'''' AND ACTUAL:result:scope::VARCHAR=''''M0_PROTOTYPE'''' AND ACTUAL:result:contractVersion::NUMBER=2 AND IS_NULL_VALUE(ACTUAL:result:error) AND ACTUAL:result:feedInstanceId::NUMBER=FEED_INSTANCE_ID AND ACTUAL:result:automationGuid::VARCHAR=AUTOMATION_GUID AND (SELECT COUNT(*) FROM @DB@.STANDARDIZE_AUDIT.@P@FEED_INSTANCE WHERE FEED_INSTANCE_ID=@FEED@ AND FEED_PROCESS_RESULT=''''SUCCESS'''')=1 AND (SELECT COUNT(*) FROM @DB@.STANDARDIZE_AUDIT.@P@AUTOMATION_LOG WHERE AUTOMATION_GUID=''''@GUID@'''' AND AUTOMATION_STATUS=''''SUCCESS'''')=1 AND (SELECT COUNT(*) FROM @DB@.STANDARDIZE_AUDIT.@P@CALLER_ACTION WHERE FEED_INSTANCE_ID=@FEED@ AND ACTION=''''CONTINUE'''')=1) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';'',PARSE_JSON(''{"status":"SUCCESS","persistence":"NOT_ATTEMPTED","sqlcode":null}''),''03 deployment successful; no concurrent suite on this prefix'',SHA2(''BEGIN
INSERT INTO @DB@.STANDARDIZE_STAGE.@P@SCENARIO VALUES (@FEED@,0,FALSE,FALSE);
INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@AUTOMATION_LOG (AUTOMATION_GUID,AUTOMATION_NAME,START_DATE,AUTOMATION_STATUS) VALUES (''''@GUID@'''',''''M0_CALLER'''',CURRENT_TIMESTAMP(),''''RUNNING'''');
INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@FEED_INSTANCE VALUES (@FEED@,''''@GUID@'''',99,140,''''RUNNING'''',CURRENT_TIMESTAMP(),NULL,CURRENT_TIMESTAMP());
END;''||CHR(31)||''DECLARE v_out VARIANT; v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@CALLER_ADAPTER(@FEED@,''''@GUID@'''',TRUE,:v_out) INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''result'''',:v_out,''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;''||CHR(31)||''UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ASSERTION_PASS=(ACTUAL:result:status::VARCHAR=''''SUCCESS'''' AND ACTUAL:returnValue::VARCHAR=''''SUCCESS'''' AND ACTUAL:result:persistence::VARCHAR=''''NOT_ATTEMPTED'''' AND ACTUAL:result:scope::VARCHAR=''''M0_PROTOTYPE'''' AND ACTUAL:result:contractVersion::NUMBER=2 AND IS_NULL_VALUE(ACTUAL:result:error) AND ACTUAL:result:feedInstanceId::NUMBER=FEED_INSTANCE_ID AND ACTUAL:result:automationGuid::VARCHAR=AUTOMATION_GUID AND (SELECT COUNT(*) FROM @DB@.STANDARDIZE_AUDIT.@P@FEED_INSTANCE WHERE FEED_INSTANCE_ID=@FEED@ AND FEED_PROCESS_RESULT=''''SUCCESS'''')=1 AND (SELECT COUNT(*) FROM @DB@.STANDARDIZE_AUDIT.@P@AUTOMATION_LOG WHERE AUTOMATION_GUID=''''@GUID@'''' AND AUTOMATION_STATUS=''''SUCCESS'''')=1 AND (SELECT COUNT(*) FROM @DB@.STANDARDIZE_AUDIT.@P@CALLER_ACTION WHERE FEED_INSTANCE_ID=@FEED@ AND ACTION=''''CONTINUE'''')=1) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';'',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''JSON-ZERO-WORK'',''CONTRACT'',''OUT JSON and caller action: JSON-ZERO-WORK'',''REQUIRED'',''BEGIN
INSERT INTO @DB@.STANDARDIZE_STAGE.@P@SCENARIO VALUES (@FEED@,0,FALSE,TRUE);
INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@AUTOMATION_LOG (AUTOMATION_GUID,AUTOMATION_NAME,START_DATE,AUTOMATION_STATUS) VALUES (''''@GUID@'''',''''M0_CALLER'''',CURRENT_TIMESTAMP(),''''RUNNING'''');
INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@FEED_INSTANCE VALUES (@FEED@,''''@GUID@'''',99,140,''''RUNNING'''',CURRENT_TIMESTAMP(),NULL,CURRENT_TIMESTAMP());
END;'',''DECLARE v_out VARIANT; v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@CALLER_ADAPTER(@FEED@,''''@GUID@'''',FALSE,:v_out) INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''result'''',:v_out,''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;'',''UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ASSERTION_PASS=(ACTUAL:result:status::VARCHAR=''''SUCCESS'''' AND ACTUAL:returnValue::VARCHAR=''''SUCCESS'''' AND ACTUAL:result:persistence::VARCHAR=''''NOT_ATTEMPTED'''' AND ACTUAL:result:scope::VARCHAR=''''M0_PROTOTYPE'''' AND ACTUAL:result:contractVersion::NUMBER=2 AND IS_NULL_VALUE(ACTUAL:result:error) AND ACTUAL:result:feedInstanceId::NUMBER=FEED_INSTANCE_ID AND ACTUAL:result:automationGuid::VARCHAR=AUTOMATION_GUID AND (SELECT COUNT(*) FROM @DB@.STANDARDIZE_AUDIT.@P@FEED_INSTANCE WHERE FEED_INSTANCE_ID=@FEED@ AND FEED_PROCESS_RESULT=''''SUCCESS'''')=1 AND (SELECT COUNT(*) FROM @DB@.STANDARDIZE_AUDIT.@P@AUTOMATION_LOG WHERE AUTOMATION_GUID=''''@GUID@'''' AND AUTOMATION_STATUS=''''SUCCESS'''')=1 AND (SELECT COUNT(*) FROM @DB@.STANDARDIZE_AUDIT.@P@CALLER_ACTION WHERE FEED_INSTANCE_ID=@FEED@ AND ACTION=''''CONTINUE'''')=1) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';'',PARSE_JSON(''{"status":"SUCCESS","persistence":"NOT_ATTEMPTED","sqlcode":null}''),''03 deployment successful; no concurrent suite on this prefix'',SHA2(''BEGIN
INSERT INTO @DB@.STANDARDIZE_STAGE.@P@SCENARIO VALUES (@FEED@,0,FALSE,TRUE);
INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@AUTOMATION_LOG (AUTOMATION_GUID,AUTOMATION_NAME,START_DATE,AUTOMATION_STATUS) VALUES (''''@GUID@'''',''''M0_CALLER'''',CURRENT_TIMESTAMP(),''''RUNNING'''');
INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@FEED_INSTANCE VALUES (@FEED@,''''@GUID@'''',99,140,''''RUNNING'''',CURRENT_TIMESTAMP(),NULL,CURRENT_TIMESTAMP());
END;''||CHR(31)||''DECLARE v_out VARIANT; v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@CALLER_ADAPTER(@FEED@,''''@GUID@'''',FALSE,:v_out) INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''result'''',:v_out,''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;''||CHR(31)||''UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ASSERTION_PASS=(ACTUAL:result:status::VARCHAR=''''SUCCESS'''' AND ACTUAL:returnValue::VARCHAR=''''SUCCESS'''' AND ACTUAL:result:persistence::VARCHAR=''''NOT_ATTEMPTED'''' AND ACTUAL:result:scope::VARCHAR=''''M0_PROTOTYPE'''' AND ACTUAL:result:contractVersion::NUMBER=2 AND IS_NULL_VALUE(ACTUAL:result:error) AND ACTUAL:result:feedInstanceId::NUMBER=FEED_INSTANCE_ID AND ACTUAL:result:automationGuid::VARCHAR=AUTOMATION_GUID AND (SELECT COUNT(*) FROM @DB@.STANDARDIZE_AUDIT.@P@FEED_INSTANCE WHERE FEED_INSTANCE_ID=@FEED@ AND FEED_PROCESS_RESULT=''''SUCCESS'''')=1 AND (SELECT COUNT(*) FROM @DB@.STANDARDIZE_AUDIT.@P@AUTOMATION_LOG WHERE AUTOMATION_GUID=''''@GUID@'''' AND AUTOMATION_STATUS=''''SUCCESS'''')=1 AND (SELECT COUNT(*) FROM @DB@.STANDARDIZE_AUDIT.@P@CALLER_ACTION WHERE FEED_INSTANCE_ID=@FEED@ AND ACTION=''''CONTINUE'''')=1) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';'',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''JSON-ERROR'',''CONTRACT'',''OUT JSON and caller action: JSON-ERROR'',''REQUIRED'',''BEGIN
INSERT INTO @DB@.STANDARDIZE_STAGE.@P@SCENARIO VALUES (@FEED@,0,TRUE,FALSE);
INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@AUTOMATION_LOG (AUTOMATION_GUID,AUTOMATION_NAME,START_DATE,AUTOMATION_STATUS) VALUES (''''@GUID@'''',''''M0_CALLER'''',CURRENT_TIMESTAMP(),''''RUNNING'''');
INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@FEED_INSTANCE VALUES (@FEED@,''''@GUID@'''',99,140,''''RUNNING'''',CURRENT_TIMESTAMP(),NULL,CURRENT_TIMESTAMP());
END;'',''DECLARE v_out VARIANT; v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@CALLER_ADAPTER(@FEED@,''''@GUID@'''',FALSE,:v_out) INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''result'''',:v_out,''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;'',''UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ASSERTION_PASS=(ACTUAL:result:status::VARCHAR=''''ERROR'''' AND ACTUAL:returnValue::VARCHAR=''''ERROR'''' AND ACTUAL:result:persistence::VARCHAR=''''ROLLED_BACK'''' AND ACTUAL:result:scope::VARCHAR=''''M0_PROTOTYPE'''' AND ACTUAL:result:contractVersion::NUMBER=2 AND ACTUAL:result:error:sqlcode::NUMBER=-20972 AND ACTUAL:result:error:sqlstate::VARCHAR=''''P0001'''' AND LENGTH(ACTUAL:result:error:message::VARCHAR)>0 AND ACTUAL:result:feedInstanceId::NUMBER=FEED_INSTANCE_ID AND ACTUAL:result:automationGuid::VARCHAR=AUTOMATION_GUID AND (SELECT COUNT(*) FROM @DB@.STANDARDIZE_AUDIT.@P@FEED_INSTANCE WHERE FEED_INSTANCE_ID=@FEED@ AND FEED_PROCESS_RESULT=''''ERROR'''')=1 AND (SELECT COUNT(*) FROM @DB@.STANDARDIZE_AUDIT.@P@AUTOMATION_LOG WHERE AUTOMATION_GUID=''''@GUID@'''' AND AUTOMATION_STATUS=''''ERROR'''')=1 AND (SELECT COUNT(*) FROM @DB@.STANDARDIZE_AUDIT.@P@AUTOMATION_LOG WHERE AUTOMATION_GUID=''''@GUID@'''' AND LAST_ERROR_STEP_NAME=''''BUSINESS_MARKER'''' AND LAST_ERROR ILIKE ''''%-20972%'''')=1 AND (SELECT COUNT(*) FROM @DB@.STANDARDIZE_AUDIT.@P@CALLER_ACTION WHERE FEED_INSTANCE_ID=@FEED@ AND ACTION=''''STOP'''')=1) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';'',PARSE_JSON(''{"status":"ERROR","persistence":"ROLLED_BACK","sqlcode":-20972}''),''03 deployment successful; no concurrent suite on this prefix'',SHA2(''BEGIN
INSERT INTO @DB@.STANDARDIZE_STAGE.@P@SCENARIO VALUES (@FEED@,0,TRUE,FALSE);
INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@AUTOMATION_LOG (AUTOMATION_GUID,AUTOMATION_NAME,START_DATE,AUTOMATION_STATUS) VALUES (''''@GUID@'''',''''M0_CALLER'''',CURRENT_TIMESTAMP(),''''RUNNING'''');
INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@FEED_INSTANCE VALUES (@FEED@,''''@GUID@'''',99,140,''''RUNNING'''',CURRENT_TIMESTAMP(),NULL,CURRENT_TIMESTAMP());
END;''||CHR(31)||''DECLARE v_out VARIANT; v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@CALLER_ADAPTER(@FEED@,''''@GUID@'''',FALSE,:v_out) INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''result'''',:v_out,''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;''||CHR(31)||''UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ASSERTION_PASS=(ACTUAL:result:status::VARCHAR=''''ERROR'''' AND ACTUAL:returnValue::VARCHAR=''''ERROR'''' AND ACTUAL:result:persistence::VARCHAR=''''ROLLED_BACK'''' AND ACTUAL:result:scope::VARCHAR=''''M0_PROTOTYPE'''' AND ACTUAL:result:contractVersion::NUMBER=2 AND ACTUAL:result:error:sqlcode::NUMBER=-20972 AND ACTUAL:result:error:sqlstate::VARCHAR=''''P0001'''' AND LENGTH(ACTUAL:result:error:message::VARCHAR)>0 AND ACTUAL:result:feedInstanceId::NUMBER=FEED_INSTANCE_ID AND ACTUAL:result:automationGuid::VARCHAR=AUTOMATION_GUID AND (SELECT COUNT(*) FROM @DB@.STANDARDIZE_AUDIT.@P@FEED_INSTANCE WHERE FEED_INSTANCE_ID=@FEED@ AND FEED_PROCESS_RESULT=''''ERROR'''')=1 AND (SELECT COUNT(*) FROM @DB@.STANDARDIZE_AUDIT.@P@AUTOMATION_LOG WHERE AUTOMATION_GUID=''''@GUID@'''' AND AUTOMATION_STATUS=''''ERROR'''')=1 AND (SELECT COUNT(*) FROM @DB@.STANDARDIZE_AUDIT.@P@AUTOMATION_LOG WHERE AUTOMATION_GUID=''''@GUID@'''' AND LAST_ERROR_STEP_NAME=''''BUSINESS_MARKER'''' AND LAST_ERROR ILIKE ''''%-20972%'''')=1 AND (SELECT COUNT(*) FROM @DB@.STANDARDIZE_AUDIT.@P@CALLER_ACTION WHERE FEED_INSTANCE_ID=@FEED@ AND ACTION=''''STOP'''')=1) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';'',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''JSON-NULL-FEED'',''CONTRACT'',''OUT JSON and caller action: JSON-NULL-FEED'',''REQUIRED'',''BEGIN
INSERT INTO @DB@.STANDARDIZE_STAGE.@P@SCENARIO VALUES (@FEED@,0,FALSE,FALSE);
INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@AUTOMATION_LOG (AUTOMATION_GUID,AUTOMATION_NAME,START_DATE,AUTOMATION_STATUS) VALUES (''''@GUID@'''',''''M0_CALLER'''',CURRENT_TIMESTAMP(),''''RUNNING'''');
INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@FEED_INSTANCE VALUES (@FEED@,''''@GUID@'''',99,140,''''RUNNING'''',CURRENT_TIMESTAMP(),NULL,CURRENT_TIMESTAMP());
END;'',''DECLARE v_out VARIANT; v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@GENERATE_CUST_NUMS_PROTOTYPE(NULL,''''@GUID@'''',FALSE,:v_out) INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''result'''',:v_out,''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;'',''UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ASSERTION_PASS=(ACTUAL:result:status::VARCHAR=''''ERROR'''' AND ACTUAL:returnValue::VARCHAR=''''ERROR'''' AND ACTUAL:result:persistence::VARCHAR=''''NOT_ATTEMPTED'''' AND ACTUAL:result:scope::VARCHAR=''''M0_PROTOTYPE'''' AND ACTUAL:result:contractVersion::NUMBER=2 AND ACTUAL:result:error:sqlcode::NUMBER=-20970 AND ACTUAL:result:error:sqlstate::VARCHAR=''''P0001'''' AND LENGTH(ACTUAL:result:error:message::VARCHAR)>0 AND ACTUAL:result:automationGuid::VARCHAR=AUTOMATION_GUID) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';'',PARSE_JSON(''{"status":"ERROR","persistence":"NOT_ATTEMPTED","sqlcode":-20970}''),''03 deployment successful; no concurrent suite on this prefix'',SHA2(''BEGIN
INSERT INTO @DB@.STANDARDIZE_STAGE.@P@SCENARIO VALUES (@FEED@,0,FALSE,FALSE);
INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@AUTOMATION_LOG (AUTOMATION_GUID,AUTOMATION_NAME,START_DATE,AUTOMATION_STATUS) VALUES (''''@GUID@'''',''''M0_CALLER'''',CURRENT_TIMESTAMP(),''''RUNNING'''');
INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@FEED_INSTANCE VALUES (@FEED@,''''@GUID@'''',99,140,''''RUNNING'''',CURRENT_TIMESTAMP(),NULL,CURRENT_TIMESTAMP());
END;''||CHR(31)||''DECLARE v_out VARIANT; v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@GENERATE_CUST_NUMS_PROTOTYPE(NULL,''''@GUID@'''',FALSE,:v_out) INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''result'''',:v_out,''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;''||CHR(31)||''UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ASSERTION_PASS=(ACTUAL:result:status::VARCHAR=''''ERROR'''' AND ACTUAL:returnValue::VARCHAR=''''ERROR'''' AND ACTUAL:result:persistence::VARCHAR=''''NOT_ATTEMPTED'''' AND ACTUAL:result:scope::VARCHAR=''''M0_PROTOTYPE'''' AND ACTUAL:result:contractVersion::NUMBER=2 AND ACTUAL:result:error:sqlcode::NUMBER=-20970 AND ACTUAL:result:error:sqlstate::VARCHAR=''''P0001'''' AND LENGTH(ACTUAL:result:error:message::VARCHAR)>0 AND ACTUAL:result:automationGuid::VARCHAR=AUTOMATION_GUID) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';'',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''JSON-NULL-GUID'',''CONTRACT'',''OUT JSON and caller action: JSON-NULL-GUID'',''REQUIRED'',''BEGIN
INSERT INTO @DB@.STANDARDIZE_STAGE.@P@SCENARIO VALUES (@FEED@,0,FALSE,FALSE);
INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@AUTOMATION_LOG (AUTOMATION_GUID,AUTOMATION_NAME,START_DATE,AUTOMATION_STATUS) VALUES (''''@GUID@'''',''''M0_CALLER'''',CURRENT_TIMESTAMP(),''''RUNNING'''');
INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@FEED_INSTANCE VALUES (@FEED@,''''@GUID@'''',99,140,''''RUNNING'''',CURRENT_TIMESTAMP(),NULL,CURRENT_TIMESTAMP());
END;'',''DECLARE v_out VARIANT; v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@GENERATE_CUST_NUMS_PROTOTYPE(@FEED@,NULL,FALSE,:v_out) INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''result'''',:v_out,''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;'',''UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ASSERTION_PASS=(ACTUAL:result:status::VARCHAR=''''ERROR'''' AND ACTUAL:returnValue::VARCHAR=''''ERROR'''' AND ACTUAL:result:persistence::VARCHAR=''''NOT_ATTEMPTED'''' AND ACTUAL:result:scope::VARCHAR=''''M0_PROTOTYPE'''' AND ACTUAL:result:contractVersion::NUMBER=2 AND ACTUAL:result:error:sqlcode::NUMBER=-20970 AND ACTUAL:result:error:sqlstate::VARCHAR=''''P0001'''' AND LENGTH(ACTUAL:result:error:message::VARCHAR)>0 AND ACTUAL:result:feedInstanceId::NUMBER=FEED_INSTANCE_ID) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';'',PARSE_JSON(''{"status":"ERROR","persistence":"NOT_ATTEMPTED","sqlcode":-20970}''),''03 deployment successful; no concurrent suite on this prefix'',SHA2(''BEGIN
INSERT INTO @DB@.STANDARDIZE_STAGE.@P@SCENARIO VALUES (@FEED@,0,FALSE,FALSE);
INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@AUTOMATION_LOG (AUTOMATION_GUID,AUTOMATION_NAME,START_DATE,AUTOMATION_STATUS) VALUES (''''@GUID@'''',''''M0_CALLER'''',CURRENT_TIMESTAMP(),''''RUNNING'''');
INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@FEED_INSTANCE VALUES (@FEED@,''''@GUID@'''',99,140,''''RUNNING'''',CURRENT_TIMESTAMP(),NULL,CURRENT_TIMESTAMP());
END;''||CHR(31)||''DECLARE v_out VARIANT; v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@GENERATE_CUST_NUMS_PROTOTYPE(@FEED@,NULL,FALSE,:v_out) INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''result'''',:v_out,''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;''||CHR(31)||''UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ASSERTION_PASS=(ACTUAL:result:status::VARCHAR=''''ERROR'''' AND ACTUAL:returnValue::VARCHAR=''''ERROR'''' AND ACTUAL:result:persistence::VARCHAR=''''NOT_ATTEMPTED'''' AND ACTUAL:result:scope::VARCHAR=''''M0_PROTOTYPE'''' AND ACTUAL:result:contractVersion::NUMBER=2 AND ACTUAL:result:error:sqlcode::NUMBER=-20970 AND ACTUAL:result:error:sqlstate::VARCHAR=''''P0001'''' AND LENGTH(ACTUAL:result:error:message::VARCHAR)>0 AND ACTUAL:result:feedInstanceId::NUMBER=FEED_INSTANCE_ID) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';'',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''JSON-NULL-MODE'',''CONTRACT'',''OUT JSON and caller action: JSON-NULL-MODE'',''REQUIRED'',''BEGIN
INSERT INTO @DB@.STANDARDIZE_STAGE.@P@SCENARIO VALUES (@FEED@,0,FALSE,FALSE);
INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@AUTOMATION_LOG (AUTOMATION_GUID,AUTOMATION_NAME,START_DATE,AUTOMATION_STATUS) VALUES (''''@GUID@'''',''''M0_CALLER'''',CURRENT_TIMESTAMP(),''''RUNNING'''');
INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@FEED_INSTANCE VALUES (@FEED@,''''@GUID@'''',99,140,''''RUNNING'''',CURRENT_TIMESTAMP(),NULL,CURRENT_TIMESTAMP());
END;'',''DECLARE v_out VARIANT; v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@GENERATE_CUST_NUMS_PROTOTYPE(@FEED@,''''@GUID@'''',NULL,:v_out) INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''result'''',:v_out,''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;'',''UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ASSERTION_PASS=(ACTUAL:result:status::VARCHAR=''''ERROR'''' AND ACTUAL:returnValue::VARCHAR=''''ERROR'''' AND ACTUAL:result:persistence::VARCHAR=''''NOT_ATTEMPTED'''' AND ACTUAL:result:scope::VARCHAR=''''M0_PROTOTYPE'''' AND ACTUAL:result:contractVersion::NUMBER=2 AND ACTUAL:result:error:sqlcode::NUMBER=-20970 AND ACTUAL:result:error:sqlstate::VARCHAR=''''P0001'''' AND LENGTH(ACTUAL:result:error:message::VARCHAR)>0 AND ACTUAL:result:feedInstanceId::NUMBER=FEED_INSTANCE_ID AND ACTUAL:result:automationGuid::VARCHAR=AUTOMATION_GUID) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';'',PARSE_JSON(''{"status":"ERROR","persistence":"NOT_ATTEMPTED","sqlcode":-20970}''),''03 deployment successful; no concurrent suite on this prefix'',SHA2(''BEGIN
INSERT INTO @DB@.STANDARDIZE_STAGE.@P@SCENARIO VALUES (@FEED@,0,FALSE,FALSE);
INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@AUTOMATION_LOG (AUTOMATION_GUID,AUTOMATION_NAME,START_DATE,AUTOMATION_STATUS) VALUES (''''@GUID@'''',''''M0_CALLER'''',CURRENT_TIMESTAMP(),''''RUNNING'''');
INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@FEED_INSTANCE VALUES (@FEED@,''''@GUID@'''',99,140,''''RUNNING'''',CURRENT_TIMESTAMP(),NULL,CURRENT_TIMESTAMP());
END;''||CHR(31)||''DECLARE v_out VARIANT; v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@GENERATE_CUST_NUMS_PROTOTYPE(@FEED@,''''@GUID@'''',NULL,:v_out) INTO :v_return; UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT_KEEP_NULL(''''result'''',:v_out,''''returnValue'''',:v_return) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;''||CHR(31)||''UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ASSERTION_PASS=(ACTUAL:result:status::VARCHAR=''''ERROR'''' AND ACTUAL:returnValue::VARCHAR=''''ERROR'''' AND ACTUAL:result:persistence::VARCHAR=''''NOT_ATTEMPTED'''' AND ACTUAL:result:scope::VARCHAR=''''M0_PROTOTYPE'''' AND ACTUAL:result:contractVersion::NUMBER=2 AND ACTUAL:result:error:sqlcode::NUMBER=-20970 AND ACTUAL:result:error:sqlstate::VARCHAR=''''P0001'''' AND LENGTH(ACTUAL:result:error:message::VARCHAR)>0 AND ACTUAL:result:feedInstanceId::NUMBER=FEED_INSTANCE_ID AND ACTUAL:result:automationGuid::VARCHAR=AUTOMATION_GUID) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';'',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''JSON-LEGACY-ABSENT'',''CONTRACT'',''Zero-argument prototype cannot invoke an allocator'',''REQUIRED'','''',''CALL @DB@.STANDARDIZE_STAGE.@P@GENERATE_CUST_NUMS_PROTOTYPE();'',''UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ASSERTION_PASS=(SQLCODE IS NOT NULL AND PHASE=''''EXECUTE'''' AND (SQLERRM ILIKE ''''%argument%'''' OR SQLERRM ILIKE ''''%signature%'''' OR SQLERRM ILIKE ''''%Unknown%'''')) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';'',PARSE_JSON(''{"error":"SIGNATURE_ERROR"}''),''03 deployment successful; no concurrent suite on this prefix'',SHA2(''''||CHR(31)||''CALL @DB@.STANDARDIZE_STAGE.@P@GENERATE_CUST_NUMS_PROTOTYPE();''||CHR(31)||''UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ASSERTION_PASS=(SQLCODE IS NOT NULL AND PHASE=''''EXECUTE'''' AND (SQLERRM ILIKE ''''%argument%'''' OR SQLERRM ILIKE ''''%signature%'''' OR SQLERRM ILIKE ''''%Unknown%'''')) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';'',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''JSON-MISSING-MODE'',''CONTRACT'',''Missing required argument cannot allocate'',''REQUIRED'','''',''CALL @DB@.STANDARDIZE_STAGE.@P@GENERATE_CUST_NUMS_PROTOTYPE(@FEED@,''''@GUID@'''');'',''UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ASSERTION_PASS=(SQLCODE IS NOT NULL AND PHASE=''''EXECUTE'''' AND (SQLERRM ILIKE ''''%argument%'''' OR SQLERRM ILIKE ''''%signature%'''' OR SQLERRM ILIKE ''''%Unknown%'''')) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';'',PARSE_JSON(''{"error":"SIGNATURE_ERROR"}''),''03 deployment successful; no concurrent suite on this prefix'',SHA2(''''||CHR(31)||''CALL @DB@.STANDARDIZE_STAGE.@P@GENERATE_CUST_NUMS_PROTOTYPE(@FEED@,''''@GUID@'''');''||CHR(31)||''UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ASSERTION_PASS=(SQLCODE IS NOT NULL AND PHASE=''''EXECUTE'''' AND (SQLERRM ILIKE ''''%argument%'''' OR SQLERRM ILIKE ''''%signature%'''' OR SQLERRM ILIKE ''''%Unknown%'''')) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';'',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''JSON-MISSING-OUTPUT'',''CONTRACT'',''Missing required argument cannot allocate'',''REQUIRED'','''',''CALL @DB@.STANDARDIZE_STAGE.@P@GENERATE_CUST_NUMS_PROTOTYPE(@FEED@,''''@GUID@'''',FALSE);'',''UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ASSERTION_PASS=(SQLCODE IS NOT NULL AND PHASE=''''EXECUTE'''' AND (SQLERRM ILIKE ''''%argument%'''' OR SQLERRM ILIKE ''''%signature%'''' OR SQLERRM ILIKE ''''%Unknown%'''')) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';'',PARSE_JSON(''{"error":"SIGNATURE_ERROR"}''),''03 deployment successful; no concurrent suite on this prefix'',SHA2(''''||CHR(31)||''CALL @DB@.STANDARDIZE_STAGE.@P@GENERATE_CUST_NUMS_PROTOTYPE(@FEED@,''''@GUID@'''',FALSE);''||CHR(31)||''UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ASSERTION_PASS=(SQLCODE IS NOT NULL AND PHASE=''''EXECUTE'''' AND (SQLERRM ILIKE ''''%argument%'''' OR SQLERRM ILIKE ''''%signature%'''' OR SQLERRM ILIKE ''''%Unknown%'''')) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';'',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''GATE-MISSING'',''CONTRACT'',''Serialization requires exactly one gate row'',''REQUIRED'',''BEGIN DELETE FROM @DB@.STANDARDIZE_AUDIT.@P@CUST_NUM_PROCESS;
INSERT INTO @DB@.STANDARDIZE_STAGE.@P@SCENARIO VALUES (@FEED@,0,FALSE,FALSE); END;'',''DECLARE v_out VARIANT; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@GENERATE_CUST_NUMS_PROTOTYPE(@FEED@,''''@GUID@'''',FALSE,:v_out); UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=:v_out WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;'',''BEGIN UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ASSERTION_PASS=(ACTUAL:status::VARCHAR=''''ERROR'''' AND ACTUAL:error:sqlcode::NUMBER=-20971 AND ACTUAL:stage::VARCHAR=''''GATE'''' AND ACTUAL:persistence::VARCHAR=''''NOT_ATTEMPTED'''') WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; DELETE FROM @DB@.STANDARDIZE_AUDIT.@P@CUST_NUM_PROCESS; INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@CUST_NUM_PROCESS VALUES (''''GENERATE_CUST_NUMS'''',NULL); END;'',PARSE_JSON(''{"status":"ERROR","sqlcode":-20971}''),''03 deployment successful; no concurrent suite on this prefix'',SHA2(''BEGIN DELETE FROM @DB@.STANDARDIZE_AUDIT.@P@CUST_NUM_PROCESS;
INSERT INTO @DB@.STANDARDIZE_STAGE.@P@SCENARIO VALUES (@FEED@,0,FALSE,FALSE); END;''||CHR(31)||''DECLARE v_out VARIANT; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@GENERATE_CUST_NUMS_PROTOTYPE(@FEED@,''''@GUID@'''',FALSE,:v_out); UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=:v_out WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;''||CHR(31)||''BEGIN UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ASSERTION_PASS=(ACTUAL:status::VARCHAR=''''ERROR'''' AND ACTUAL:error:sqlcode::NUMBER=-20971 AND ACTUAL:stage::VARCHAR=''''GATE'''' AND ACTUAL:persistence::VARCHAR=''''NOT_ATTEMPTED'''') WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; DELETE FROM @DB@.STANDARDIZE_AUDIT.@P@CUST_NUM_PROCESS; INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@CUST_NUM_PROCESS VALUES (''''GENERATE_CUST_NUMS'''',NULL); END;'',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''GATE-DUPLICATE'',''CONTRACT'',''Serialization requires exactly one gate row'',''REQUIRED'',''BEGIN DELETE FROM @DB@.STANDARDIZE_AUDIT.@P@CUST_NUM_PROCESS;
INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@CUST_NUM_PROCESS VALUES (''''GENERATE_CUST_NUMS'''',NULL),(''''GENERATE_CUST_NUMS'''',NULL);
INSERT INTO @DB@.STANDARDIZE_STAGE.@P@SCENARIO VALUES (@FEED@,0,FALSE,FALSE); END;'',''DECLARE v_out VARIANT; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@GENERATE_CUST_NUMS_PROTOTYPE(@FEED@,''''@GUID@'''',FALSE,:v_out); UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=:v_out WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;'',''BEGIN UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ASSERTION_PASS=(ACTUAL:status::VARCHAR=''''ERROR'''' AND ACTUAL:error:sqlcode::NUMBER=-20971 AND ACTUAL:stage::VARCHAR=''''GATE'''' AND ACTUAL:persistence::VARCHAR=''''NOT_ATTEMPTED'''') WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; DELETE FROM @DB@.STANDARDIZE_AUDIT.@P@CUST_NUM_PROCESS; INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@CUST_NUM_PROCESS VALUES (''''GENERATE_CUST_NUMS'''',NULL); END;'',PARSE_JSON(''{"status":"ERROR","sqlcode":-20971}''),''03 deployment successful; no concurrent suite on this prefix'',SHA2(''BEGIN DELETE FROM @DB@.STANDARDIZE_AUDIT.@P@CUST_NUM_PROCESS;
INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@CUST_NUM_PROCESS VALUES (''''GENERATE_CUST_NUMS'''',NULL),(''''GENERATE_CUST_NUMS'''',NULL);
INSERT INTO @DB@.STANDARDIZE_STAGE.@P@SCENARIO VALUES (@FEED@,0,FALSE,FALSE); END;''||CHR(31)||''DECLARE v_out VARIANT; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@GENERATE_CUST_NUMS_PROTOTYPE(@FEED@,''''@GUID@'''',FALSE,:v_out); UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=:v_out WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; END;''||CHR(31)||''BEGIN UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ASSERTION_PASS=(ACTUAL:status::VARCHAR=''''ERROR'''' AND ACTUAL:error:sqlcode::NUMBER=-20971 AND ACTUAL:stage::VARCHAR=''''GATE'''' AND ACTUAL:persistence::VARCHAR=''''NOT_ATTEMPTED'''') WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@''''; DELETE FROM @DB@.STANDARDIZE_AUDIT.@P@CUST_NUM_PROCESS; INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@CUST_NUM_PROCESS VALUES (''''GENERATE_CUST_NUMS'''',NULL); END;'',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''REL-NULL-NOT-IN'',''RELATIONAL'',''NULL NOT IN differs from NOT EXISTS'',''REQUIRED'','''',''UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''notIn'''',(SELECT COUNT(*) FROM (SELECT 7 AS ID) S WHERE ID NOT IN (SELECT NULL::NUMBER)), ''''notExists'''',(SELECT COUNT(*) FROM (SELECT 7 AS ID) S WHERE NOT EXISTS (SELECT 1 FROM (SELECT NULL::NUMBER AS ID) T WHERE T.ID=S.ID))) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';'',''UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ASSERTION_PASS=(ACTUAL:notIn::NUMBER=0 AND ACTUAL:notExists::NUMBER=1) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';'',PARSE_JSON(''{"notIn":0,"notExists":1}''),''03 deployment successful; no concurrent suite on this prefix'',SHA2(''''||CHR(31)||''UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''notIn'''',(SELECT COUNT(*) FROM (SELECT 7 AS ID) S WHERE ID NOT IN (SELECT NULL::NUMBER)), ''''notExists'''',(SELECT COUNT(*) FROM (SELECT 7 AS ID) S WHERE NOT EXISTS (SELECT 1 FROM (SELECT NULL::NUMBER AS ID) T WHERE T.ID=S.ID))) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';''||CHR(31)||''UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ASSERTION_PASS=(ACTUAL:notIn::NUMBER=0 AND ACTUAL:notExists::NUMBER=1) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';'',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''REL-OR-SENTINEL'',''RELATIONAL'',''OR/null-to-zero matching can suppress a proposed row'',''REQUIRED'','''',''UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''legacyMatch'''',(SELECT COUNT(*) FROM (SELECT 0 AS ID, 10 AS NUM) T JOIN (SELECT NULL::NUMBER AS ID, 20 AS NUM) S ON T.ID=IFNULL(S.ID,0) OR T.NUM=IFNULL(S.NUM,0)), ''''directMatch'''',(SELECT COUNT(*) FROM (SELECT 0 AS ID, 10 AS NUM) T JOIN (SELECT NULL::NUMBER AS ID, 20 AS NUM) S ON T.ID=S.ID OR T.NUM=S.NUM)) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';'',''UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ASSERTION_PASS=(ACTUAL:legacyMatch::NUMBER=1 AND ACTUAL:directMatch::NUMBER=0) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';'',PARSE_JSON(''{"legacyMatch":1,"directMatch":0}''),''03 deployment successful; no concurrent suite on this prefix'',SHA2(''''||CHR(31)||''UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=OBJECT_CONSTRUCT(''''legacyMatch'''',(SELECT COUNT(*) FROM (SELECT 0 AS ID, 10 AS NUM) T JOIN (SELECT NULL::NUMBER AS ID, 20 AS NUM) S ON T.ID=IFNULL(S.ID,0) OR T.NUM=IFNULL(S.NUM,0)), ''''directMatch'''',(SELECT COUNT(*) FROM (SELECT 0 AS ID, 10 AS NUM) T JOIN (SELECT NULL::NUMBER AS ID, 20 AS NUM) S ON T.ID=S.ID OR T.NUM=S.NUM)) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';''||CHR(31)||''UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ASSERTION_PASS=(ACTUAL:legacyMatch::NUMBER=1 AND ACTUAL:directMatch::NUMBER=0) WHERE RUN_ID=''''@RUN@'''' AND TEST_ID=''''@CASE@'''';'',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''SERIAL-COMMIT'',''SERIALIZATION'',''Two independent sessions; COMMIT'',''REQUIRED'','''','''','''',PARSE_JSON(''{"ordering":"B requests during A hold; B acquires after A release; fresh marker; distinct sessions"}''),''Run 05a/05b/05c/05d separately for COMMIT'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''SERIAL-ROLLBACK'',''SERIALIZATION'',''Two independent sessions; ROLLBACK'',''REQUIRED'','''','''','''',PARSE_JSON(''{"ordering":"B requests during A hold; B acquires after A release; fresh marker; distinct sessions"}''),''Run 05a/05b/05c/05d separately for ROLLBACK'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''SERIAL-PREVIEW'',''SERIALIZATION'',''Two independent sessions; PREVIEW'',''REQUIRED'','''','''','''',PARSE_JSON(''{"ordering":"B requests during A hold; B acquires after A release; fresh marker; distinct sessions"}''),''Run 05a/05b/05c/05d separately for PREVIEW'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''EXCLUDED-PERMISSIONS-OWNERSHIP'',''EXCLUDED'',''PERMISSIONS-OWNERSHIP'',''EXCLUDED'','''','''','''',PARSE_JSON(''{"execution":"NOT_RUN","riskAcceptedByUser":"2026-10-19"}''),''Explicitly removed from qualification scope; not a passing test'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''EXCLUDED-TRANSACTION-MATRIX'',''EXCLUDED'',''TRANSACTION-MATRIX'',''EXCLUDED'','''','''','''',PARSE_JSON(''{"execution":"NOT_RUN","riskAcceptedByUser":"2026-10-19"}''),''Explicitly removed from qualification scope; not a passing test'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''EXCLUDED-TIMEOUT-LIMIT'',''EXCLUDED'',''TIMEOUT-LIMIT'',''EXCLUDED'','''','''','''',PARSE_JSON(''{"execution":"NOT_RUN","riskAcceptedByUser":"2026-10-19"}''),''Explicitly removed from qualification scope; not a passing test'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''EXCLUDED-LOGGING-FAILURES'',''EXCLUDED'',''LOGGING-FAILURES'',''EXCLUDED'','''','''','''',PARSE_JSON(''{"execution":"NOT_RUN","riskAcceptedByUser":"2026-10-19"}''),''Explicitly removed from qualification scope; not a passing test'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''EXCLUDED-LOCKING-BEYOND-SERIALIZATION'',''EXCLUDED'',''LOCKING-BEYOND-SERIALIZATION'',''EXCLUDED'','''','''','''',PARSE_JSON(''{"execution":"NOT_RUN","riskAcceptedByUser":"2026-10-19"}''),''Explicitly removed from qualification scope; not a passing test'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-T01'',''FUTURE_TARGET'',''Compile baseline and target SQL and validate objects/membership. Permission/ownership tests excluded; database binding remains a guarded deployment requirement.'',''DEFERRED'','''','''','''',PARSE_JSON(''{"approvedExpectation":"Compile baseline and target SQL and validate objects/membership. Permission/ownership tests excluded; database binding remains a guarded deployment requirement.","historicalExpectation":"Verified production export normalization and complete candidate `EXECUTE AS OWNER` wrapper/client compile in isolation; candidate join preserves blocked/unblocked membership and row counts; harmless preview runs. Verify required owner/caller grants and authorized non-owner invocation under D05.5, including compatibility of entry checks and D07 logging; callers need not have direct table privileges. Under D05.6, call the fully qualified procedure from a session with a different current database/schema and verify all data access, startup truncation, cleanup, and helper/reporting operations remain in the procedure''''s environment. Every referenced work table is predeployed; inspect all runtime/exception paths for DDL."}''),''Future allocator; reduced-scope coverage in COVERAGE.md'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-T02'',''FUTURE_TARGET'',''Capture, then insert/update/delete source rows from another session. Every subsequent source decision/check uses the capture. Include external values on mapped individuals and non-ICON/MAO discovery.'',''DEFERRED'','''','''','''',PARSE_JSON(''{"approvedExpectation":"Capture, then insert/update/delete source rows from another session. Every subsequent source decision/check uses the capture. Include external values on mapped individuals and non-ICON/MAO discovery.","historicalExpectation":"Capture, then insert/update/delete source rows from another session. Every subsequent source decision/check uses the capture. Include external values on mapped individuals and non-ICON/MAO discovery."}''),''Future allocator; reduced-scope coverage in COVERAGE.md'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-T03'',''FUTURE_TARGET'',''Verify the settled D01 truth table: exclude exact `NON_ACTIVE` only; accept NULL, empty/whitespace strings, hyphen, arbitrary strings, case variants, and padded variants under the status rule. A qualifying exact `NON_ACTIVE` occurrence globally blocks the same numeric PK1 across individuals and ICON/MAO, including leading-zero forms, despite other eligible statuses. Existing mappings are not revoked.'',''DEFERRED'','''','''','''',PARSE_JSON(''{"approvedExpectation":"Verify the settled D01 truth table: exclude exact `NON_ACTIVE` only; accept NULL, empty/whitespace strings, hyphen, arbitrary strings, case variants, and padded variants under the status rule. A qualifying exact `NON_ACTIVE` occurrence globally blocks the same numeric PK1 across individuals and ICON/MAO, including leading-zero forms, despite other eligible statuses. Existing mappings are not revoked.","historicalExpectation":"Verify the settled D01 truth table: exclude exact `NON_ACTIVE` only; accept NULL, empty/whitespace strings, hyphen, arbitrary strings, case variants, and padded variants under the status rule. A qualifying exact `NON_ACTIVE` occurrence globally blocks the same numeric PK1 across individuals and ICON/MAO, including leading-zero forms, despite other eligible statuses. Existing mappings are not revoked."}''),''Future allocator; reduced-scope coverage in COVERAGE.md'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-T04'',''FUTURE_TARGET'',''Accept both real-ID endpoints; reject neighboring values, null, zero, and non-integer inputs where representable before conversion. Include mapped individuals and invalid-PK1 rows; no invalid ID is filtered away. No null/zero equality.'',''DEFERRED'','''','''','''',PARSE_JSON(''{"approvedExpectation":"Accept both real-ID endpoints; reject neighboring values, null, zero, and non-integer inputs where representable before conversion. Include mapped individuals and invalid-PK1 rows; no invalid ID is filtered away. No null/zero equality.","historicalExpectation":"Accept both real-ID endpoints; reject neighboring values, null, zero, and non-integer inputs where representable before conversion. Include mapped individuals and invalid-PK1 rows; no invalid ID is filtered away. No null/zero equality."}''),''Future allocator; reduced-scope coverage in COVERAGE.md'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-T05'',''FUTURE_TARGET'',''Invalid genuine IDs, malformed legacy equal-key reservations, missing/unknown record type, required-field violations, and duplicate/conflicting keys fail both modes before planning/business writes. Valid `(42,42)` legacy reservation coexists with genuine ID `100000000042`; separately remediated data passes later.'',''DEFERRED'','''','''','''',PARSE_JSON(''{"approvedExpectation":"Invalid genuine IDs, malformed legacy equal-key reservations, missing/unknown record type, required-field violations, and duplicate/conflicting keys fail both modes before planning/business writes. Valid `(42,42)` legacy reservation coexists with genuine ID `100000000042`; separately remediated data passes later.","historicalExpectation":"Invalid genuine IDs, malformed legacy equal-key reservations, missing/unknown record type, required-field violations, and duplicate/conflicting keys fail both modes before planning/business writes. Valid `(42,42)` legacy reservation coexists with genuine ID `100000000042`; separately remediated data passes later."}''),''Future allocator; reduced-scope coverage in COVERAGE.md'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-T06'',''FUTURE_TARGET'',''Accept digits/leading zeros and test specified surrounding whitespace; reject signs, decimals, exponents, embedded spaces, empty/NULL, and overflow. Test 0, 1, 499999999, 500000000, 599999999, 600000000, 999999999, 1000000000. No rounded adoption/retirement; valid people with invalid PK1 can receive generated numbers.'',''DEFERRED'','''','''','''',PARSE_JSON(''{"approvedExpectation":"Accept digits/leading zeros and test specified surrounding whitespace; reject signs, decimals, exponents, embedded spaces, empty/NULL, and overflow. Test 0, 1, 499999999, 500000000, 599999999, 600000000, 999999999, 1000000000. No rounded adoption/retirement; valid people with invalid PK1 can receive generated numbers.","historicalExpectation":"Accept digits/leading zeros and test specified surrounding whitespace; reject signs, decimals, exponents, embedded spaces, empty/NULL, and overflow. Test 0, 1, 499999999, 500000000, 599999999, 600000000, 999999999, 1000000000. No rounded adoption/retirement; valid people with invalid PK1 can receive generated numbers."}''),''Future allocator; reduced-scope coverage in COVERAGE.md'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-T07'',''FUTURE_TARGET'',''Both prefer 101 and individual 8 has alternative 102: individual 7 wins 101, individual 8 receives a generated number, and 102 is reserved. Also test individual 7 preferring 101 with lower-ranked 102 while individual 8 has only 102: retain the original two-rank result, with no reranking to free 102 for individual 8. Cover multiple conflicts and occupied/blocked/reserved candidates. Verify both-rank eligibility, no fallback/rebalancing, and post-selection retirement.'',''DEFERRED'','''','''','''',PARSE_JSON(''{"approvedExpectation":"Both prefer 101 and individual 8 has alternative 102: individual 7 wins 101, individual 8 receives a generated number, and 102 is reserved. Also test individual 7 preferring 101 with lower-ranked 102 while individual 8 has only 102: retain the original two-rank result, with no reranking to free 102 for individual 8. Cover multiple conflicts and occupied/blocked/reserved candidates. Verify both-rank eligibility, no fallback/rebalancing, and post-selection retirement.","historicalExpectation":"Both prefer 101 and individual 8 has alternative 102: individual 7 wins 101, individual 8 receives a generated number, and 102 is reserved. Also test individual 7 preferring 101 with lower-ranked 102 while individual 8 has only 102: retain the original two-rank result, with no reranking to free 102 for individual 8. Cover multiple conflicts and occupied/blocked/reserved candidates. Verify both-rank eligibility, no fallback/rebalancing, and post-selection retirement."}''),''Future allocator; reduced-scope coverage in COVERAGE.md'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-T08'',''FUTURE_TARGET'',''Known dates beat nulls for preference and ownership under different session defaults. Test equal dates, duplicate occurrences, input order changes, SOR ties, and selected-source evidence.'',''DEFERRED'','''','''','''',PARSE_JSON(''{"approvedExpectation":"Known dates beat nulls for preference and ownership under different session defaults. Test equal dates, duplicate occurrences, input order changes, SOR ties, and selected-source evidence.","historicalExpectation":"Known dates beat nulls for preference and ownership under different session defaults. Test equal dates, duplicate occurrences, input order changes, SOR ties, and selected-source evidence."}''),''Future allocator; reduced-scope coverage in COVERAGE.md'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-T09'',''FUTURE_TARGET'',''Empty history starts at 500000001; reject 500000000. Test internal gaps, exact capacity, exhaustion at 599999999, deterministic individual order, retained-XREF seed after highest-row deletion (verify generation continues without a history-loss check or special response, including when loss is known, and demonstrate possible reuse under D04.2), and preview followed by another live run.'',''DEFERRED'','''','''','''',PARSE_JSON(''{"approvedExpectation":"Empty history starts at 500000001; reject 500000000. Test internal gaps, exact capacity, exhaustion at 599999999, deterministic individual order, retained-XREF seed after highest-row deletion (verify generation continues without a history-loss check or special response, including when loss is known, and demonstrate possible reuse under D04.2), and preview followed by another live run.","historicalExpectation":"Empty history starts at 500000001; reject 500000000. Test internal gaps, exact capacity, exhaustion at 599999999, deterministic individual order, retained-XREF seed after highest-row deletion (verify generation continues without a history-loss check or special response, including when loss is known, and demonstrate possible reuse under D04.2), and preview followed by another live run."}''),''Future allocator; reduced-scope coverage in COVERAGE.md'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-T10'',''FUTURE_TARGET'',''Final unused eligible numbers become CORE reservations and remain unavailable after source removal/later feeds. Include mapped individuals and newly blocked occurrences. Verify exact D03.2 reason values, the merged predicate, non-active/merged/unused classification, and one reason per newly reserved number. A committed `NON_ACTIVE` reservation remains unavailable after the blocking status changes or its source profile is corrected/deleted; no release path runs. Assignments and reservations never overlap.'',''DEFERRED'','''','''','''',PARSE_JSON(''{"approvedExpectation":"Final unused eligible numbers become CORE reservations and remain unavailable after source removal/later feeds. Include mapped individuals and newly blocked occurrences. Verify exact D03.2 reason values, the merged predicate, non-active/merged/unused classification, and one reason per newly reserved number. A committed `NON_ACTIVE` reservation remains unavailable after the blocking status changes or its source profile is corrected/deleted; no release path runs. Assignments and reservations never overlap.","historicalExpectation":"Final unused eligible numbers become CORE reservations and remain unavailable after source removal/later feeds. Include mapped individuals and newly blocked occurrences. Verify exact D03.2 reason values, the merged predicate, non-active/merged/unused classification, and one reason per newly reserved number. A committed `NON_ACTIVE` reservation remains unavailable after the blocking status changes or its source profile is corrected/deleted; no release path runs. Assignments and reservations never overlap."}''),''Future allocator; reduced-scope coverage in COVERAGE.md'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-T11'',''FUTURE_TARGET'',''Exactly one genuine assignment per new individual and one approved disposition per external value. Verify generation audit feed versus originating source feed and require both source fields to come from the same selected row. Include duplicate IDs ordered as strings (`''''10''''` before `''''2''''`), mixed null/non-null IDs, and failure when no required source identifier can be established. Verify reservation-specific attribution corrections separately from unchanged assignment attribution; compare multiplicity, not only sets.'',''DEFERRED'','''','''','''',PARSE_JSON(''{"approvedExpectation":"Exactly one genuine assignment per new individual and one approved disposition per external value. Verify generation audit feed versus originating source feed and require both source fields to come from the same selected row. Include duplicate IDs ordered as strings (`''''10''''` before `''''2''''`), mixed null/non-null IDs, and failure when no required source identifier can be established. Verify reservation-specific attribution corrections separately from unchanged assignment attribution; compare multiplicity, not only sets.","historicalExpectation":"Exactly one genuine assignment per new individual and one approved disposition per external value. Verify generation audit feed versus originating source feed and require both source fields to come from the same selected row. Include duplicate IDs ordered as strings (`''''10''''` before `''''2''''`), mixed null/non-null IDs, and failure when no required source identifier can be established. Verify reservation-specific attribution corrections separately from unchanged assignment attribution; compare multiplicity, not only sets."}''),''Future allocator; reduced-scope coverage in COVERAGE.md'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-T12'',''FUTURE_TARGET'',''Reprocess unchanged committed input: no duplicate mapping/reservation, no unnecessary generated consumption, no conversion of existing assignments to unused reservations. Each invocation still has its own report identity. Existing reservation rows retain all six D03.4 values, including original reason, creation audit, and source feed/identifier, even when later source evidence changes; no refresh or duplicate row is permitted.'',''DEFERRED'','''','''','''',PARSE_JSON(''{"approvedExpectation":"Reprocess unchanged committed input: no duplicate mapping/reservation, no unnecessary generated consumption, no conversion of existing assignments to unused reservations. Each invocation still has its own report identity. Existing reservation rows retain all six D03.4 values, including original reason, creation audit, and source feed/identifier, even when later source evidence changes; no refresh or duplicate row is permitted.","historicalExpectation":"Reprocess unchanged committed input: no duplicate mapping/reservation, no unnecessary generated consumption, no conversion of existing assignments to unused reservations. Each invocation still has its own report identity. Existing reservation rows retain all six D03.4 values, including original reason, creation audit, and source feed/identifier, even when later source evidence changes; no refresh or duplicate row is permitted."}''),''Future allocator; reduced-scope coverage in COVERAGE.md'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-T13'',''FUTURE_TARGET'',''Record-type/domain classification, unknown-row blocking, before/after mapping and reservation reconciliation, D08.1 consumer behavior against separate assignment/reservation stores without a temporary compatibility view, repeatable deployment, and preservation of the captured mappings/reservations through migration and recovery. Verify affected consumer versions are ready before callers are re-enabled. Do not require detection or reconstruction of earlier lost generated assignments under D04.2. Verify D03.5 preserves original creation timestamps and reconstructs actual historical generation invocation IDs separately from source feed/ID. Confirm merged reservations are attributable to the supplied producer; other legacy reasons require independent provenance. Distinguish newly created blocked/unused reservations from historical migration, preserving existing genuine assignments. Test missing and ambiguous history: neither migration audit values nor guessed source-attribution IDs may substitute; acceptance/cutover remains blocked until resolution. Retain reconstruction evidence.'',''DEFERRED'','''','''','''',PARSE_JSON(''{"approvedExpectation":"Record-type/domain classification, unknown-row blocking, before/after mapping and reservation reconciliation, D08.1 consumer behavior against separate assignment/reservation stores without a temporary compatibility view, repeatable deployment, and preservation of the captured mappings/reservations through migration and recovery. Verify affected consumer versions are ready before callers are re-enabled. Do not require detection or reconstruction of earlier lost generated assignments under D04.2. Verify D03.5 preserves original creation timestamps and reconstructs actual historical generation invocation IDs separately from source feed/ID. Confirm merged reservations are attributable to the supplied producer; other legacy reasons require independent provenance. Distinguish newly created blocked/unused reservations from historical migration, preserving existing genuine assignments. Test missing and ambiguous history: neither migration audit values nor guessed source-attribution IDs may substitute; acceptance/cutover remains blocked until resolution. Retain reconstruction evidence.","historicalExpectation":"Record-type/domain classification, unknown-row blocking, before/after mapping and reservation reconciliation, D08.1 consumer behavior against separate assignment/reservation stores without a temporary compatibility view, repeatable deployment, and preservation of the captured mappings/reservations through migration and recovery. Verify affected consumer versions are ready before callers are re-enabled. Do not require detection or reconstruction of earlier lost generated assignments under D04.2. Verify D03.5 preserves original creation timestamps and reconstructs actual historical generation invocation IDs separately from source feed/ID. Confirm merged reservations are attributable to the supplied producer; other legacy reasons require independent provenance. Distinguish newly created blocked/unused reservations from historical migration, preserving existing genuine assignments. Test missing and ambiguous history: neither migration audit values nor guessed source-attribution IDs may substitute; acceptance/cutover remains blocked until resolution. Retain reconstruction evidence."}''),''Future allocator; reduced-scope coverage in COVERAGE.md'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-T14'',''FUTURE_TARGET'',''Inject unexpected skipped assignments/reservations, duplicate/conflicting outputs, and count mismatch; fail before commit. Model production NOT IN and OR-MERGE/sentinel behavior separately, including nulls where schema permits and controlled invalid fixtures where it does not; verify target preflight/direct-key logic fails or assigns as specified without silent loss. Compare applied external/generated/reservation counts individually; prohibit unexpected business updates/deletes.'',''DEFERRED'','''','''','''',PARSE_JSON(''{"approvedExpectation":"Inject unexpected skipped assignments/reservations, duplicate/conflicting outputs, and count mismatch; fail before commit. Model production NOT IN and OR-MERGE/sentinel behavior separately, including nulls where schema permits and controlled invalid fixtures where it does not; verify target preflight/direct-key logic fails or assigns as specified without silent loss. Compare applied external/generated/reservation counts individually; prohibit unexpected business updates/deletes.","historicalExpectation":"Inject unexpected skipped assignments/reservations, duplicate/conflicting outputs, and count mismatch; fail before commit. Model production NOT IN and OR-MERGE/sentinel behavior separately, including nulls where schema permits and controlled invalid fixtures where it does not; verify target preflight/direct-key logic fails or assigns as specified without silent loss. Compare applied external/generated/reservation counts individually; prohibit unexpected business updates/deletes."}''),''Future allocator; reduced-scope coverage in COVERAGE.md'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-T15'',''FUTURE_TARGET'',''Full applicable validation, provisional plan counts, no persistent business changes, no allocation advance. Zero-work success requires all applicable checks and error-free execution; every mode still acquires the gate.'',''DEFERRED'','''','''','''',PARSE_JSON(''{"approvedExpectation":"Full applicable validation, provisional plan counts, no persistent business changes, no allocation advance. Zero-work success requires all applicable checks and error-free execution; every mode still acquires the gate.","historicalExpectation":"Full applicable validation, provisional plan counts, no persistent business changes, no allocation advance. Zero-work success requires all applicable checks and error-free execution; every mode still acquires the gate."}''),''Future allocator; reduced-scope coverage in COVERAGE.md'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-T16'',''FUTURE_TARGET'',''Transaction/AUTOCOMMIT/caller-transaction fault matrix excluded. Only serialization lifecycle remains required under T18.'',''EXCLUDED'','''','''','''',PARSE_JSON(''{"approvedExpectation":"Transaction/AUTOCOMMIT/caller-transaction fault matrix excluded. Only serialization lifecycle remains required under T18.","historicalExpectation":"Inject failures after each business DML and before commit. Assignments and reservations roll back together; the XREF-derived seed therefore remains unchanged; durable report survives. Exercise `AUTOCOMMIT = TRUE` with no open caller transaction. Under D05.4, verify FALSE cannot proceed into generation work and is not silently changed to TRUE. Under D05.3, verify live and preview calls with an open caller transaction fail before gate acquisition/truncation/preparation; the caller transaction remains open and its prior work remains under caller control."}''),''Future allocator; reduced-scope coverage in COVERAGE.md'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-T17'',''FUTURE_TARGET'',''Rollback/logging failure injection excluded. Original caught business error in JSON and caller STOP are required under T22.'',''EXCLUDED'','''','''','''',PARSE_JSON(''{"approvedExpectation":"Rollback/logging failure injection excluded. Original caught business error in JSON and caller STOP are required under T22.","historicalExpectation":"Trigger a primary SQL error followed by rollback failure and/or logging failure. Original code/state/message reach the harness; no generic debug extract or persistent samples are required. Test inability to initialize reporting before apply."}''),''Future allocator; reduced-scope coverage in COVERAGE.md'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-T18'',''FUTURE_TARGET'',''Two sessions: same individual, shared seed, competing external number, preview/live overlap. B waits at process-row update and reads A''''s committed state only after acquiring the gate; repeat with A rollback.'',''DEFERRED'','''','''','''',PARSE_JSON(''{"approvedExpectation":"Two sessions: same individual, shared seed, competing external number, preview/live overlap. B waits at process-row update and reads A''''s committed state only after acquiring the gate; repeat with A rollback.","historicalExpectation":"Two sessions: same individual, shared seed, competing external number, preview/live overlap. B waits at process-row update and reads A''''s committed state only after acquiring the gate; repeat with A rollback."}''),''Future allocator; reduced-scope coverage in COVERAGE.md'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-T19'',''FUTURE_TARGET'',''Exactly-one-row gate and no bypass remain serialization prerequisites; exact timeout/acquisition fault suite excluded.'',''DEFERRED'','''','''','''',PARSE_JSON(''{"approvedExpectation":"Exactly-one-row gate and no bypass remain serialization prerequisites; exact timeout/acquisition fault suite excluded.","historicalExpectation":"Hold the gate beyond 60 seconds and verify D05.1 times out without beginning preparation/allocation; release it before the limit and verify the waiting invocation can proceed. Cover live and preview, missing/duplicate control row, acquisition error, and release on commit/rollback. Failures cannot fall through to allocation. Observe outside writers as accepted-risk evidence, not required prevention."}''),''Future allocator; reduced-scope coverage in COVERAGE.md'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-T20'',''FUTURE_TARGET'',''Retain stage/run isolation during serialization and ordinary successful cleanup; transactional truncation/cleanup failure matrix excluded.'',''DEFERRED'','''','''','''',PARSE_JSON(''{"approvedExpectation":"Retain stage/run isolation during serialization and ordinary successful cleanup; transactional truncation/cleanup failure matrix excluded.","historicalExpectation":"Distinct runs cannot mix stage rows in joins/reads/writes. Seed stale rows under multiple run IDs and verify D05.2 startup truncation clears every inventoried dedicated work table only after gate acquisition. A waiting/timed-out invocation must not truncate active-run work. Verify successful live runs leave no work rows, report values survive final cleanup, and cleanup failures roll back business changes. Preview/failure rollback restores any pre-existing stale rows and removes new work rows. Source, CORE, process control, and audit/reporting tables must never be cleanup targets. Rolled-back stage rows are not the durable diagnostic mechanism."}''),''Future allocator; reduced-scope coverage in COVERAGE.md'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-T21'',''FUTURE_TARGET'',''Commit-uncertainty/post-commit logging failure injection excluded; contract still requires truthful persistence and no blind retry.'',''EXCLUDED'','''','''','''',PARSE_JSON(''{"approvedExpectation":"Commit-uncertainty/post-commit logging failure injection excluded; contract still requires truthful persistence and no blind retry.","historicalExpectation":"Commit response uncertainty yields unresolved persistence, never assumed success/rollback. Audit failure after confirmed commit surfaces without reapplying. Verify D07 audit writes do not release the gate or deadlock with business work."}''),''Future allocator; reduced-scope coverage in COVERAGE.md'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-T22'',''FUTURE_TARGET'',''Explicit feed/GUID/preview plus RESULT OUT VARIANT; supplied identity roundtrip, contractVersion/status/error/persistence/action, caller logging and STOP on ERROR, no legacy bypass. Missing/default inputs cannot allocate. Permission/grant and logging-fault tests excluded. Actual RPDM binding remains required before cutover.'',''DEFERRED'','''','''','''',PARSE_JSON(''{"approvedExpectation":"Explicit feed/GUID/preview plus RESULT OUT VARIANT; supplied identity roundtrip, contractVersion/status/error/persistence/action, caller logging and STOP on ERROR, no legacy bypass. Missing/default inputs cannot allocate. Permission/grant and logging-fault tests excluded. Actual RPDM binding remains required before cutover.","historicalExpectation":"Verify D06.1 binds both supplied identifiers and the explicit Boolean preview flag through updated procedure-specific callers and the existing harness; verify signature-specific grants, old zero-argument calls cannot allocate, and no legacy overload bypasses the gate; missing identifiers or null/omitted mode cannot start generation or default to live. No identifier is generated internally or obtained from a feed lookup. One log row per invocation; distinct retry GUID/feed/log IDs; no cross-attempt correlation requirement. Column/JSON equality including nulls, validated counts retained after later failure, required NOT_RUN checks, strict allowed metrics, settled D06.2 `VARCHAR(36)` binding and unchanged identifier propagation, and D06.3 return behavior. Verify successful preview/live/zero-work calls return exactly `SUCCESS`, details are accessible by supplied feed ID, and validation/execution/reporting failures raise errors instead of returning success, including post-commit reporting failure. No extra UUID-format validation or width-discovery gate is required."}''),''Future allocator; reduced-scope coverage in COVERAGE.md'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  v_sql := REPLACE(REPLACE('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT ''TARGET-T23'',''FUTURE_TARGET'',''Representative data volumes, elapsed time, scans, sort/spill, and cost compared with the verified production baseline outside routine reporting: seven success-path permanent work tables and two success-path source reads, plus one debug table/source read on failure. Include first-run blocked/unused reservation growth and source coverage on mapped individuals; the target does more validation, retirement, and reporting work. Confirm improvements preserve behavior and provenance; no unmeasured speedup promise.'',''DEFERRED'','''','''','''',PARSE_JSON(''{"approvedExpectation":"Representative data volumes, elapsed time, scans, sort/spill, and cost compared with the verified production baseline outside routine reporting: seven success-path permanent work tables and two success-path source reads, plus one debug table/source read on failure. Include first-run blocked/unused reservation growth and source coverage on mapped individuals; the target does more validation, retirement, and reporting work. Confirm improvements preserve behavior and provenance; no unmeasured speedup promise.","historicalExpectation":"Representative data volumes, elapsed time, scans, sort/spill, and cost compared with the verified production baseline outside routine reporting: seven success-path permanent work tables and two success-path source reads, plus one debug table/source read on failure. Include first-run blocked/unused reservation growth and source coverage on mapped individuals; the target does more validation, retirement, and reporting work. Confirm improvements preserve behavior and provenance; no unmeasured speedup promise."}''),''Future allocator; reduced-scope coverage in COVERAGE.md'',SHA2(''''||CHR(31)||''''||CHR(31)||'''',256);', '@DB@', v_db), '@P@', v_prefix);
  EXECUTE IMMEDIATE :v_sql;
  RETURN 'TESTS_REGISTERED';
END;
$$;
