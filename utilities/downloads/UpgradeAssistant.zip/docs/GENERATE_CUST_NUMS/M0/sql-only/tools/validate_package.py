"""Offline validation only. No SQL engine/connector/network execution.

Checks authoring integrity and isolation, not Snowflake compilation/semantics.
Every attempt is retained; --seal refreshes the package file manifest.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import ast
import difflib
import hashlib
import json
import re
import subprocess
import sys
from collections import Counter

ROOT=Path(__file__).resolve().parents[1]
DOCS=ROOT.parents[1]
REPO=DOCS.parents[1]
DOC_NAMES=['implementation-plan.md','REPORTING.md','README.md','plan-refactoring.md','Reviews/CR1.md']

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def scan_sql(s):
    """Lexical string/comment balance, with decoded literals for nested SQL checks."""
    out=[]; strings=[]; i=0
    while i<len(s):
        if s.startswith('--',i):
            j=s.find('\n',i); i=len(s) if j<0 else j; out.append(' ')
        elif s.startswith('/*',i):
            j=s.find('*/',i+2)
            if j<0: raise ValueError('Unclosed block comment')
            i=j+2; out.append(' ')
        elif s.startswith('$$',i):
            j=s.find('$$',i+2)
            if j<0: raise ValueError('Unclosed dollar string')
            code,nested=scan_sql(s[i+2:j]); out.append(code); strings.extend(nested); i=j+2
        elif s[i]=="'":
            buf=[]; i+=1
            while i<len(s):
                if s[i]=="'":
                    if i+1<len(s) and s[i+1]=="'": buf.append("'"); i+=2
                    else: i+=1; break
                else: buf.append(s[i]); i+=1
            else: raise ValueError('Unclosed single-quoted literal')
            strings.append(''.join(buf)); out.append(' ')
        else: out.append(s[i]); i+=1
    return ''.join(out),strings

def main():
    parser=argparse.ArgumentParser(); parser.add_argument('--seal',action='store_true'); args=parser.parse_args()
    results=[]
    def check(id,fn):
        try:
            detail=fn(); results.append(dict(checkId=id,status='PASS',detail=detail))
        except Exception as ex:
            results.append(dict(checkId=id,status='FAIL',detail=str(ex)))
    # Rebuild exact final documentation diffs from preserved pre-revision bytes.
    for name in DOC_NAMES:
        old=(ROOT/'evidence/before-docs'/name).read_text(encoding='utf-8')
        new=(DOCS/name).read_text(encoding='utf-8')
        diff=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=name+' (before)',tofile=name+' (approved revision)'))
        p=ROOT/'evidence/documentation-diffs'/(name.replace('/','_')+'.diff')
        p.parent.mkdir(exist_ok=True,parents=True); p.write_text(diff,encoding='utf-8',newline='\n')
    def preservation():
        entries=json.loads((ROOT/'evidence/revision-inputs.json').read_text(encoding='utf-8'))
        changed=[]; n=0
        docs_set={'docs/GENERATE_CUST_NUMS/'+x for x in DOC_NAMES}
        for name,h in entries.items():
            if name in docs_set: continue
            n+=1
            if sha(REPO/name)!=h: changed.append(name)
        assert not changed,changed
        return f'{n} original M0/input/procedure files unchanged; five authorized documents have before snapshots and diffs.'
    check('LOCAL-PRESERVATION',preservation)
    def python_sources():
        paths=list((ROOT/'tools').glob('*.py'))
        for p in paths: ast.parse(p.read_text(encoding='utf-8'),filename=str(p))
        return f'{len(paths)} local authoring/validation scripts parse; no database connector used.'
    check('LOCAL-PYTHON',python_sources)
    def deterministic():
        paths=list(ROOT.glob('*.sql'))+[ROOT/'fixtures/check-registry.json',ROOT/'src/baseline.prefixed.sql.template',ROOT/'evidence/baseline-prefix.diff']
        before={str(p):sha(p) for p in paths}
        run=subprocess.run([sys.executable,str(ROOT/'tools/build_package.py')],capture_output=True,text=True)
        assert run.returncode==0,run.stdout+run.stderr
        assert before=={str(p):sha(p) for p in paths},'Generated output changed; inspect and rerun validation.'
        return f'{len(paths)} generated artifacts reproduce byte-for-byte.'
    check('LOCAL-GENERATION',deterministic)
    def baseline():
        original=(ROOT.parent/'scripts/sql/baseline.normalized.sql').read_text(encoding='utf-8')
        mapped=(ROOT/'src/baseline.prefixed.sql.template').read_text(encoding='utf-8')
        restored=mapped.replace('@DB@.','').replace('.@P@','.')
        restored=restored.replace('CREATE PROCEDURE STANDARDIZE_STAGE.BASELINE_GENERATE_CUST_NUMS()', 'CREATE OR REPLACE PROCEDURE "GENERATE_CUST_NUMS"()',1)
        assert restored==original,'Baseline has non-identifier changes'
        return 'Baseline prefix adaptation reverses exactly to normalized input; original normalization diff retained.'
    check('LOCAL-BASELINE',baseline)
    def registry():
        data=json.loads((ROOT/'fixtures/check-registry.json').read_text(encoding='utf-8'))['checks']
        ids=[x['testId'] for x in data]
        assert len(ids)==len(set(ids)),'Duplicate check IDs'
        assert all(x['status']=='NOT_RUN' for x in data)
        counts=Counter(x['disposition'] for x in data)
        seq=[x for x in data if x['suite'] in {'BASELINE','CONTRACT','RELATIONAL'}]
        assert len(seq)==34,len(seq)
        assert len([x for x in data if x['suite']=='SERIALIZATION'])==3
        old=json.loads((ROOT.parent/'fixtures/behavior-cases.json').read_text(encoding='utf-8'))['cases']
        by_id={x['testId']:x for x in data}
        for case in old:
            actual=by_id['BASELINE-'+case['id']]['expected']
            for key,val in case['productionBaseline'].items(): assert actual[key]==val,(case['id'],key)
            assert by_id['TARGET-'+case['id']]['expected']==case['approvedTarget'],case['id']
        assert 'TARGET-Target' not in ids and 'TARGET-Test' not in ids
        return {'checks':len(data),'dispositions':dict(counts),'sequentialExecutable':34,'serializationRequired':3,'oracles':'20 baseline/target pairs preserved'}
    check('LOCAL-REGISTRY',registry)
    def lexical():
        todo=[(p.relative_to(ROOT).as_posix(),p.read_text(encoding='utf-8')) for p in ROOT.glob('*.sql')]
        todo += [(p.relative_to(ROOT).as_posix(),p.read_text(encoding='utf-8')) for p in (ROOT/'src').glob('*') if p.is_file()]
        seen=set(); count=0
        while todo:
            name,sql=todo.pop(); key=hashlib.sha256(sql.encode()).hexdigest()
            if key in seen: continue
            seen.add(key); count+=1
            code,strings=scan_sql(sql)
            # Executable table/procedure identifiers must be rendered or prefix templates.
            assert not re.search(r'(?<![.\w])(STANDARDIZE_(?:CORE|STAGE|AUDIT))\.[A-Za-z_]',code),name+' has unprefixed dependency'
            assert not re.search(r'\b(?:GRANT|REVOKE|USE\s+ROLE|DROP\s+(?:DATABASE|SCHEMA))\b',code,re.I),name+' changes deployment privileges/environment'
            if name.endswith('.sql') and '/' not in name:
                assert '@DB@' not in code and '@P@' not in code,name+' has unresolved executable identifiers'
                assert 'CURRENT_ACCOUNT()' in code and 'CURRENT_TRANSACTION()' in code,name+' missing guard'
            for value in strings:
                if re.match(r'^\s*(?:--[^\n]*\n\s*)*(?:DECLARE|BEGIN|CREATE\s|INSERT\s|UPDATE\s|DELETE\s|CALL\s|SELECT\s)',value,re.I):
                    todo.append((name+'::literal',value))
        return f'{count} distinct SQL/literal layers checked for balanced quoting and unprefixed references; this is NOT SQL compilation.'
    check('LOCAL-SQL-LEXICAL-ISOLATION',lexical)
    def fixtures():
        setup=(ROOT/'01_mock_current_state.sql').read_text(encoding='utf-8')
        for table in ['CUST_NUM_INDIVIDUAL_XREF','PARTY_PROFILE','AUTOMATION_LOG','FEED_INSTANCE','SOURCE_LOOKUP','SOURCE_FEED_LOOKUP']:
            assert '.@P@'+table+' (' in setup,table
        xref=(REPO/'dw/STANDARDIZE_CORE/Tables/CUST_NUM_INDIVIDUAL_XREF.sql').read_text(encoding='utf-8')
        orig=re.search(r'\((.*)\)',xref,re.S).group(1)
        cols=re.search(r'@P@CUST_NUM_INDIVIDUAL_XREF \((.*?)\);',setup,re.S).group(1)
        normalize=lambda s:re.sub(r'\s+','',s).upper()
        assert normalize(orig)==normalize(cols),'XREF columns/type/nullability differ'
        return 'All six mocks present; full XREF column/type/nullability matches repository DDL.'
    check('LOCAL-FIXTURES',fixtures)
    def history():
        rows=[line for line in (ROOT.parent/'fixtures/historical-cr1-ten-results.md').read_text(encoding='utf-8').splitlines() if line.startswith('|')]
        current=(DOCS/'Reviews/CR1.md').read_text(encoding='utf-8')
        assert len(rows)==12,len(rows)
        assert all(row in current for row in rows),'Historical CR1 rows altered'
        return 'All ten original modeled results remain verbatim; they are not new execution evidence.'
    check('LOCAL-HISTORY',history)
    def contracts():
        for name in DOC_NAMES:
            s=(DOCS/name).read_text(encoding='utf-8')
            assert 'RESULT OUT VARIANT' in s,name
            assert 'reduced M0 gate remains NOT MET' in s,name
            for obsolete in ['do not add a structured response','raise failures. Obtain mode/counts','unchanged VARCHAR SUCCESS']:
                assert obsolete not in s,(name,obsolete)
        adapter=(ROOT/'src/adapter.sql').read_text(encoding='utf-8')
        assert adapter.index("IF (v_status='ERROR')") < adapter.index("VALUES (:P_FEED,'CONTINUE'")
        assert "RETURN 'ERROR'" in adapter
        assert 'EXCLUDED' in (ROOT/'COVERAGE.md').read_text(encoding='utf-8')
        return 'Five documents agree on JSON/caller contract and reduced gate; error branch precedes downstream continuation.'
    check('LOCAL-CONTRACTS',contracts)
    def guard_cases():
        prefix=lambda s: bool(re.fullmatch(r'M[0-9]+_',s))
        assert all(prefix(x) for x in ['M0_','M1_','M001_'])
        assert not any(prefix(x) for x in ['', 'M#_', 'M0', 'M0_;DROP', '../M0_', 'M0_ X'])
        candidate=(ROOT/'src/candidate.sql').read_text(encoding='utf-8')
        assert candidate.index('UPDATE @DB@.STANDARDIZE_AUDIT.@P@CUST_NUM_PROCESS') < candidate.index('TRUNCATE TABLE') < candidate.index('SELECT VALUE INTO')
        assert 'ROWCOUNT' in candidate and 'v_n<>1' in candidate
        return 'Identifier allowlist rejects invalid prefixes; candidate reads/truncates business work only after gate update.'
    check('LOCAL-GUARDS',guard_cases)
    # Expected output paths exist before link validation; reports are finalized below.
    for name in ['local-validation.json','package-manifest.json']:
        p=ROOT/'evidence'/name
        if not p.exists(): p.write_text('{}\n')
    def links():
        paths=list(ROOT.glob('*.md'))+[DOCS/name for name in DOC_NAMES]
        n=0; missing=[]
        for p in paths:
            for target in re.findall(r'\[[^\]]*\]\(([^\n)]+)\)',p.read_text(encoding='utf-8')):
                if target.startswith(('http:','https:','#','mailto:')): continue
                target=target.split('#')[0].strip('<>')
                if not target: continue
                n+=1
                if not (p.parent/target).exists(): missing.append(str(p)+': '+target)
        assert not missing,missing
        return f'{n} local file links resolve (external links/anchors are not a database check).'
    check('LOCAL-LINKS',links)
    excluded={'evidence/package-manifest.json','evidence/local-validation.json'}
    files={str(p.relative_to(ROOT)).replace('\\','/'):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(ROOT.rglob('*'))
      if p.is_file() and str(p.relative_to(ROOT)).replace('\\','/') not in excluded
      and not any(x in p.parts for x in ['__pycache__','attempts','runs'])}
    manifest={'version':'M0-SQL-ONLY-2','files':files,'externalDocuments':{name:sha(DOCS/name) for name in DOC_NAMES}}
    mpath=ROOT/'evidence/package-manifest.json'
    if args.seal: mpath.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    def manifest_check():
        assert json.loads(mpath.read_text(encoding='utf-8'))==manifest,'Manifest mismatch; review changes before --seal.'
        return f'{len(files)} package files and five revised documents match manifest.'
    check('LOCAL-MANIFEST',manifest_check)
    now=datetime.now(timezone.utc)
    report={'timestampUtc':now.isoformat(),'scope':'LOCAL_ONLY_NOT_SNOWFLAKE_COMPILATION','checks':results,
      'allLocalPassed':all(x['status']=='PASS' for x in results),'snowflakeExecution':'NOT_RUN','reducedM0Gate':'NOT_MET','packageManifestSha256':sha(mpath)}
    payload=json.dumps(report,indent=2)+'\n'
    (ROOT/'evidence/local-validation.json').write_text(payload,encoding='utf-8')
    attempts=ROOT/'evidence/attempts'; attempts.mkdir(exist_ok=True)
    (attempts/(now.strftime('%Y%m%dT%H%M%S%fZ')+'.json')).write_text(payload,encoding='utf-8')
    print(json.dumps(report,indent=2))
    return 0 if report['allLocalPassed'] else 1

if __name__=='__main__': sys.exit(main())
