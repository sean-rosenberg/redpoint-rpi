"""Apply the user-approved documentation revision once, preserving before bytes/diffs."""
from pathlib import Path
import difflib
import hashlib
import json
import re

HERE = Path(__file__).resolve().parents[1]
DOCS = HERE.parents[1]
REPO = DOCS.parents[1]
FILES = ['implementation-plan.md','REPORTING.md','README.md','plan-refactoring.md','Reviews/CR1.md']
STAMP = 'SQL-only qualification and JSON outcome revision (October 19)'

D06 = ('**D06.3 revised decision (October 19, user-approved SQL-only revision):** Add a required fourth argument '
       '`RESULT OUT VARIANT`. It returns the versioned JSON outcome specified in REPORTING.md: supplied invocation '
       'identity, mode, SUCCESS/ERROR status, business persistence, stage, original error details, and caller action. '
       'Handled failures return ERROR JSON; successful calls return SUCCESS JSON. The scalar VARCHAR return mirrors '
       'the JSON status as SUCCESS or ERROR. A successfully executed CALL is not sufficient evidence of business success. '
       'The harness/RPDM must inspect and log the JSON, stop downstream processing on ERROR, and reconcile COMMITTED '
       'or UNKNOWN errors before any retry. Errors outside the handler still use the SQL-error path. This supersedes '
       'the earlier SUCCESS-only/no-structured-response and mandatory rethrow contract. Procedure-specific caller '
       'binding and outcome handling are in scope; shared harness framework redesign remains out of scope.')
D07 = ('**D07.1 retained implementation decision; reduced verification (October 19):** Keep the dedicated audit-only '
       'scoped-transaction helper for all CUST_NUM_PROCESS_LOG writes. The coordinator owns the business transaction '
       'and retains its generation gate through planning, validation, apply, and commit/rollback; the helper must '
       'not access source, work, assignment, reservation, or process-control objects. Initial/in-progress reporting '
       'failure prevents apply; a handled post-commit reporting failure returns ERROR JSON with COMMITTED persistence. '
       'Preserve the original error through secondary failures. Dedicated logging/transaction fault suites are '
       'excluded with the user accepting the resulting lack of qualification; verify only the logging path needed '
       'to demonstrate serialization. Excluding tests does not remove these implementation requirements.')

def replace_paragraph(text, start, replacement):
    pattern = r'(?m)^' + re.escape(start) + r'[^\n]*(?:\n(?!\n)[^\n]*)?'
    # These contract paragraphs are single source lines.
    return re.sub(r'(?m)^'+re.escape(start)+r'[^\n]*',lambda _:replacement,text)

def main():
    evidence=HERE/'evidence'
    evidence.mkdir(exist_ok=True)
    before_manifest=evidence/'revision-inputs.json'
    if before_manifest.exists():
        raise SystemExit('Documentation revision already captured; do not overwrite original evidence.')
    original={}
    for path in (DOCS/'M0').rglob('*'):
        if path.is_file() and HERE not in path.parents:
            original[str(path.relative_to(REPO)).replace('\\','/')] = hashlib.sha256(path.read_bytes()).hexdigest()
    for name in FILES:
        path=DOCS/name
        raw=path.read_bytes()
        saved=evidence/'before-docs'/name
        saved.parent.mkdir(parents=True,exist_ok=True)
        saved.write_bytes(raw)
        original[str(path.relative_to(REPO)).replace('\\','/')] = hashlib.sha256(raw).hexdigest()
    for path in (REPO/'dw/STANDARDIZE_STAGE/Procedures').glob('GENERATE_CUST_NUMS*.sql'):
        original[str(path.relative_to(REPO)).replace('\\','/')] = hashlib.sha256(path.read_bytes()).hexdigest()
    before_manifest.write_text(json.dumps(original,indent=2)+'\n',encoding='utf-8')
    for name in FILES:
        path=DOCS/name
        raw=path.read_bytes()
        newline='\r\n' if b'\r\n' in raw else '\n'
        text=raw.decode('utf-8').replace('\r\n','\n')
        old=text
        prefix='../' if name.startswith('Reviews/') else ''
        notice=(f'## {STAMP}\n\nThe user approved a required JSON OUT outcome for harness/RPDM logging and control, '
          'and accepted excluding permission/ownership, transaction, timeout, logging-error, and locking tests '
          'except those required to validate serialization. This revision supersedes earlier conflicting return/error '
          'and qualification requirements; D01–D04/D08 allocation and migration policy is unchanged. '
          f'Use the [SQL-only runbook]({prefix}M0/sql-only/README.md), [coverage and accepted gaps]({prefix}M0/sql-only/COVERAGE.md), '
          f'and [JSON caller contract]({prefix}REPORTING.md#json-outcome-and-caller-actions). '
          'The original M0 package and CR1 historical ten modeled results remain evidence of their original scope. '
          'Both supplied procedure files are unchanged; the new SQL contains M0 fixtures/prototypes only. '
          'All Snowflake checks remain NOT_RUN. The reduced M0 gate remains NOT MET pending the required target-account results.\n\n')
        lines=text.split('\n',2)
        text=lines[0]+'\n\n'+notice+lines[2]
        text=replace_paragraph(text,'**D06.3 decision (October 19, option A):**',D06)
        text=replace_paragraph(text,'**D07.1 decision (October 19, option A):**',D07)
        text=text.replace('The existing harness captures the runtime SQL error; harness changes are out of scope.',
          'The procedure-specific harness/RPDM caller captures the JSON outcome and any escaping SQL error; shared framework redesign is out of scope.')
        text=text.replace('The existing harness captures that runtime SQL error; changes to the harness are out of scope.',
          'The procedure-specific harness/RPDM caller receives the original details in RESULT OUT VARIANT and captures any escaping SQL error; shared framework redesign is out of scope.')
        text=text.replace('existing harness captures the runtime SQL error.', 'procedure-specific caller logs the JSON outcome and captures any escaping SQL error.')
        text=text.replace('with the unchanged VARCHAR SUCCESS result under D06', 'with the versioned JSON OUT outcome and caller action under revised D06')
        text=text.replace('Persisted bounded, rule-specific samples and harness changes are out of scope.', 'Persisted bounded, rule-specific samples and shared harness framework redesign are out of scope; procedure-specific JSON handling is required.')
        if name=='REPORTING.md':
            text=text.replace('Preserve the existing SUCCESS/error contract.', 'Adopt the revised JSON OUT/error contract below.')
            text=text.replace('The harness is existing infrastructure; harness changes are out of scope. It captures the runtime SQL error.',
              'The harness is existing infrastructure. Procedure-specific SQL must consume RESULT OUT VARIANT, log its outcome, and stop on ERROR. The outer caller also captures SQL errors when no usable JSON is returned. Shared framework redesign remains out of scope.')
            text=text.replace('These decisions settle the F12 error-handling scope. Implementation and Snowflake verification remain pending, including original-error preservation when rollback or logging fails and correct persistence reporting after a confirmed business commit.',
              'The revised F12 contract preserves original details in ERROR JSON and requires an outer SQL-error fallback. Business-error JSON/caller reaction remains required testing. Secondary rollback/logging failures and post-commit fault injection are excluded and unverified under the accepted reduced scope; truthful persistence remains an implementation requirement.')
            text=text.replace('post-commit audit failure raises', 'handled post-commit audit failure returns ERROR JSON')
            # Insert the protocol before the existing audit field table.
            contract=(HERE/'CONTRACT.md').read_text(encoding='utf-8')
            text=text.replace('| Table | Field | Description |',contract+'\n\n| Table | Field | Description |',1)
        if name=='implementation-plan.md':
            text=replace_paragraph(text,'| D05 — SETTLED', '| D05 — SETTLED implementation; reduced verification | Retain the 60-second gate wait, locked startup truncation, no open caller transaction, AUTOCOMMIT TRUE, EXECUTE AS OWNER, and database-local object resolution. | Required qualification retains serialization and guarded environment binding. Permission/ownership, transaction, timeout, logging-failure, and additional locking fault suites are excluded with accepted risk; exclusions are not PASS. See M0/sql-only/COVERAGE.md. |')
            text=replace_paragraph(text,'| D06 — SETTLED', '| D06 — REVISED October 19 | Retain explicit FEED_INSTANCE_ID, externally supplied AUTOMATION_GUID VARCHAR(36), and explicit Boolean preview. Add RESULT OUT VARIANT containing the versioned SUCCESS/ERROR outcome. VARCHAR return mirrors status. | Procedure-specific harness/RPDM binding logs JSON and branches on status/persistence. ERROR stops downstream work; COMMITTED/UNKNOWN requires reconciliation. Outer SQL-error fallback is required. Signature is (NUMBER,VARCHAR,BOOLEAN,VARIANT); retire zero-argument allocation at cutover. |')
            text=replace_paragraph(text,'| D07 — SETTLED', '| D07 — SETTLED implementation; reduced verification | Keep the dedicated audit-only scoped-transaction helper and original-error preservation; return handled failures through revised D06 JSON. | Serialization evidence must cover the helper path without early gate release. Dedicated audit/rollback/logging failure qualification is excluded and unverified, with user-accepted risk. |')
            text=replace_paragraph(text,'| F12 — Errors', '| F12 — Errors | Capture original code/state/message/stage before secondary work; return handled errors in RESULT OUT VARIANT, guard rollback/logging, and require caller logging plus STOP/reconciliation. Escaping errors use the outer SQL-error path. No persistent rule-specific samples. | M0 JSON contract prototype, M4 target integration; reduced-scope T22 and serialization evidence. |')
            text=text.replace('retaining the success/error contract does not preserve the zero-argument call.', 'the JSON OUT contract adds a fourth argument and requires caller outcome handling.')
            text=text.replace('Propagate the original runtime SQL error to the existing harness even if rollback or logging fails.', 'Return the original code/state/message/stage in ERROR JSON even if secondary rollback or logging fails; the caller must log and act on it. Escaping SQL errors remain an outer-caller failure path.')
            text=text.replace('Reuse the existing harness identifiers and success/error handling; no shared framework redesign is included.', 'Reuse the existing harness identifiers, bind the fourth OUT argument, persist its JSON outcome, and stop/reconcile on ERROR; no shared framework redesign is included.')
            text=text.replace('### Durable logging design to prove in M0','### Durable logging design and accepted qualification gap')
            text=text.replace('Prove initial-log failure stops apply, in-progress logging survives business rollback, and logging never releases the lock early.', 'The reduced suite verifies the logging path does not release the gate early. Initial-log, audit-durability, and secondary logging fault tests are excluded; their implementation requirements remain.')
            text=replace_paragraph(text,'M0 local preparation (October 19):', 'M0 progress (October 19): the original [qualification package](M0/README.md) is retained unchanged as historical evidence. The approved [SQL-only revision](M0/sql-only/README.md) adds prefixed mocks, a SQL runner, a consolidated prototype deployment file, JSON caller handling, serialization scripts, and exportable evidence. All Snowflake checks remain NOT_RUN. The reduced M0 gate is NOT MET; excluded infrastructure tests no longer block that reduced gate, while required compilation/functional/serialization results remain outstanding. Both supplied procedures are unchanged. No M1 allocator implementation or database execution has occurred.')
            text=replace_paragraph(text,'| M0 — Baseline', '| M0 — Baseline and executable design | Preserve baseline identity and behavior; compile isolated baseline and JSON prototype; run SQL-only baseline, relational, JSON/caller, and serialization checks. Retain deployed/caller/consumer inventory and future business oracles. | Reduced gate: required SQL-only checks PASS with saved failures/successes and exact package/environment identity. Excluded checks remain NOT_RUN/EXCLUDED. Deployed consumer/lineage gaps remain documented dependencies for M1–M5 and cutover; prototype success is not allocator qualification. |')
            text=replace_paragraph(text,'| M4 — Atomic', '| M4 — Atomic apply, reporting, and failures | Integrate business DML, count reconciliation, preview, persistence states, JSON OUT outcome, and caller logging/action. | M3 plus D05–D07 implementation requirements; required business/JSON and serialization coverage passes. Excluded infrastructure/fault suites remain unverified under accepted risk. |')
            text=replace_paragraph(text,'| M6 — Integrated', '| M6 — Integrated qualification and release package | Run the approved reduced matrix against the exact candidate and migrated model; retain package identity, fixtures, failures, outcomes, accepted exclusions, and workload evidence. | All applicable prior gates and retained portions of T01–T23; no unresolved REQUIRED FAIL/NOT_RUN. Excluded tests do not count as PASS. Qualification, release authorization, deployment, and production acceptance remain separate. |')
            replacements={
              'T01':'Compilation and objects | Compile baseline/candidate and verify referenced objects and blocked membership. Owner/grant test matrix is excluded. Guard configured database/prefix and bind every dependency to the isolated environment. Future target contains no runtime work-table DDL.',
              'T16':'Transaction fault suite — EXCLUDED | Dedicated rollback, AUTOCOMMIT, caller-transaction, and transactional cleanup tests are excluded with accepted risk. Keep only lifecycle checks necessary for T18 serialization.',
              'T17':'Secondary error suite — EXCLUDED | Rollback/logging failure injection and audit-initialization fault tests are excluded. Original caught business-error details in JSON and caller STOP remain required under T22.',
              'T19':'Serialization gate prerequisites | Retain exactly-one-row/no-bypass checks and release behavior needed for T18. Exact 60-second timeout and other acquisition-fault tests are excluded; the configured limit remains an implementation requirement.',
              'T20':'Run isolation and cleanup | Retain run isolation and cleanup ordering needed for serialization plus ordinary successful cleanup. Dedicated transactional startup-truncate/cleanup failure matrices are excluded. Only dedicated work tables may be cleaned.',
              'T21':'Uncertain/post-commit fault suite — EXCLUDED | Fault injection for uncertain commit and post-commit audit failures is excluded. Truthful persistence and no blind retry remain the JSON/caller implementation contract.',
              'T22':'JSON report and caller contract | Bind feed/GUID/explicit preview plus RESULT OUT VARIANT. Verify SUCCESS/ERROR JSON, original error details, truthful persistence, identifier preservation, caller logging/STOP, and legacy-overload rejection. Successful CALL alone is insufficient. Keep compact metrics and distinct retry identities. Actual RPDM binding is required before cutover; grant and logging-fault tests are excluded.'}
            for tid,value in replacements.items():
                text=re.sub(r'(?m)^\| '+tid+r' —[^\n]*', '| '+tid+' — '+value+' | Revised reduced scope |',text)
            text=text.replace('Add one DDL file per chosen stage table, process table/seed, process log, D07.1 audit logging helper, and proposed CORE reservation table.', 'Provide one ordered deployment/migration SQL file for the chosen stage tables, process table/seed, process log, D07.1 helper, and CORE reservation table; maintain reviewable component sources as needed. DDL steps are independently committed and must be recorded/recoverable.')
        if name=='Reviews/CR1.md':
            text=text.replace('and exact `SUCCESS` return on successful completion; details remain in the process log linked by feed ID and failures raise errors.', 'and the revised versioned JSON OUT result; the procedure-specific caller logs SUCCESS/ERROR and stops or reconciles failures.')
            text=text.replace('propagate the original runtime SQL error through the existing harness contract.', 'return the original details in ERROR JSON for procedure-specific harness/RPDM logging and action; preserve an outer SQL-error fallback.')
            text=text.replace('Verify original-error preservation when rollback or logging fails, durable reporting after business rollback, distinct retry identities, and reporting failure after confirmed commit without claiming rollback or blindly reapplying the plan.', 'Verify caught business-error JSON, caller action, and distinct retry identities. Secondary rollback/logging and post-commit fault tests are excluded under the accepted reduced scope; the implementation still must preserve original errors and truthful persistence.')
        path.write_bytes(text.replace('\n',newline).encode('utf-8'))
        diff=''.join(difflib.unified_diff(old.splitlines(True),text.splitlines(True),fromfile=name+' (before)',tofile=name+' (approved revision)'))
        dest=evidence/'documentation-diffs'/(name.replace('/','_')+'.diff')
        dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_text(diff,encoding='utf-8',newline='\n')
    print('Updated five documents; preserved before bytes and exact diffs. Supplied SQL unchanged.')

if __name__=='__main__': main()
