"""Remove superseded verification wording; original bytes are already retained."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
DOCS=ROOT.parents[1]
for name in ['implementation-plan.md','REPORTING.md','README.md','plan-refactoring.md','Reviews/CR1.md']:
    path=DOCS/name
    raw=path.read_bytes(); nl='\r\n' if b'\r\n' in raw else '\n'
    text=raw.decode().replace('\r\n','\n')
    replacements={
      '- **D06.3 — SETTLED (October 19, option A):** Return the exact string `SUCCESS` after successful completion of the requested mode; raise failures. Obtain mode/counts/persistence/log ID from the process log using the supplied feed ID. No D06 policy points remain open.':
      '- **D06.3 — REVISED (October 19):** Require `RESULT OUT VARIANT`; return SUCCESS/ERROR JSON and mirror status in the scalar VARCHAR return. The procedure-specific caller logs the outcome and stops/reconciles errors. The prior SUCCESS-only/rethrow contract is superseded.',
      'Retain `EXECUTE AS OWNER`; verify required grants, caller-entry checks, lock-wait enforcement, and logging under that rights model.':
      'Retain `EXECUTE AS OWNER`; record required grants and supported caller settings. Dedicated rights/entry/timeout fault tests are excluded; serialization remains required.',
      'Verify enforcement with the actual wrapper, caller settings, and target account during implementation.':
      'Configure this limit; exact timeout enforcement testing is excluded under the accepted reduced qualification scope.',
      'Verify entry detection and rejection with the actual wrapper and harness.':
      'Dedicated caller-transaction rejection tests are excluded under the accepted reduced scope.',
      'Verify configuration and enforcement using the selected execution-rights model and actual harness during M0; do not assume session-inspection commands are available under every rights mode.':
      'Configure the required setting for qualification; direct-entry enforcement tests are excluded under the accepted reduced scope. Do not assume session-inspection commands are available under every rights mode.',
      'Verify D05.1 lock-wait enforcement, D05.3 caller-transaction rejection, D05.4 AUTOCOMMIT enforcement, and D07 logging under owner rights with the actual harness, including an authorized non-owner caller.':
      'The dedicated owner/non-owner, caller-transaction, AUTOCOMMIT, timeout, and logging-failure suites are excluded with accepted risk; only the path needed for serialization is qualified.',
      'Verify rollback and lock retention in the target account.':
      'Verify lock retention only as needed for serialization; the broader transactional-truncate/rollback matrix is excluded.',
      'transaction ownership and independent durability must still be verified during implementation.':
      'transaction ownership and independent durability remain implementation obligations; their dedicated fault qualification is excluded under the accepted reduced scope.',
      'Verify preview, zero-work, failed/unexecuted checks, apply-count mismatch, rollback, uncertain persistence, retries, and audit failure after confirmed business commit.':
      'Verify preview, zero-work, failed/unexecuted checks, apply-count mismatch, retries, JSON outcome handling, and serialization. Dedicated rollback, uncertain-commit, and audit-failure tests are excluded with accepted risk.',
      'M0 must reconcile the supplied production export with the deployed definition, actual schema, owner/grants, and callers.':
      'M0 records reconciliation with available deployed definition/schema/caller evidence and lists missing metadata. Permission/ownership testing is excluded; missing deployed metadata remains a later integration/cutover dependency.',
      'Validate the selected design with the actual wrapper, caller, and account before accepting its implementation; do not treat a nested call as automatic independent persistence.':
      'Validate the selected path for serialization with the actual wrapper and account. The broader independent-durability/fault qualification is excluded; a nested call is not itself proof of durability.',
      'D01–D08 decisions settled; implementation, migration, and Snowflake qualification are pending.':
      'D01–D08 govern with the approved D06/F12 and reduced-qualification revision; implementation, migration, and Snowflake qualification are pending.'
    }
    for before,after in replacements.items(): text=text.replace(before,after)
    path.write_bytes(text.replace('\n',nl).encode())
print('Reconciled active contract wording; historical modeled results unchanged.')
