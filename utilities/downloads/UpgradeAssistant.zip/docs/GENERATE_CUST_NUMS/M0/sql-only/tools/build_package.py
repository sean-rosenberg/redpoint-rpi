"""Local authoring only. Generated SQL needs only a Snowflake SQL worksheet.

Never connects to a database. Original M0 artifacts and supplied SQL are read only.
"""
from pathlib import Path
import hashlib
import json
import re
import difflib

ROOT = Path(__file__).resolve().parents[1]
M0 = ROOT.parent
REPO = M0.parents[2]
VERSION = 'M0-SQL-ONLY-2'

def q(s):
    return "'" + str(s).replace("'", "''") + "'"

def write(name, text):
    path = ROOT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text.rstrip() + '\n', encoding='utf-8', newline='\n')

def lit(v):
    if v is None: return 'NULL'
    if isinstance(v, bool): return str(v).upper()
    if isinstance(v, (int, float)): return str(v)
    return q(v)

DECL = """  v_db VARCHAR := $Q_DATABASE;
  v_prefix VARCHAR := $Q_PREFIX;
  v_account VARCHAR := $Q_ACCOUNT;
  v_ack VARCHAR := $Q_ACK;
  v_sql VARCHAR;
  v_n NUMBER;
  v_guard EXCEPTION (-20990, 'Qualification guard failed: check account, database, prefix, marker, and caller transaction');
"""
GUARD = """  IF (v_db IS NULL OR v_prefix IS NULL OR v_account IS NULL OR v_ack IS NULL
      OR NOT REGEXP_LIKE(v_db, '^[A-Z][A-Z0-9_]*$')
      OR NOT REGEXP_LIKE(v_prefix, '^M[0-9]+_$')
      OR v_account <> CURRENT_ACCOUNT() OR v_db <> CURRENT_DATABASE()
      OR v_ack <> 'ISOLATED_PREFIX_FIXTURES_ONLY'
      OR CURRENT_TRANSACTION() IS NOT NULL) THEN RAISE v_guard; END IF;
"""

def bind(s):
    return f"REPLACE(REPLACE({q(s)}, '@DB@', v_db), '@P@', v_prefix)"

def execute(s):
    return '  v_sql := ' + bind(s) + ';\n  EXECUTE IMMEDIATE :v_sql;\n'

def block(body, decl='', marker=True):
    g = GUARD
    if marker:
        g += "  LET v_marker VARCHAR := v_db || '.STANDARDIZE_AUDIT.' || v_prefix || 'ENVIRONMENT';\n"
        g += f"  SELECT COUNT(*) INTO :v_n FROM IDENTIFIER(:v_marker) WHERE PACKAGE_VERSION = '{VERSION}' AND DATABASE_NAME = :v_db AND OBJECT_PREFIX = :v_prefix AND ACCOUNT_NAME = :v_account;\n"
        g += '  IF (v_n <> 1) THEN RAISE v_guard; END IF;\n'
    return '-- Generated locally; Snowflake compilation/execution NOT_RUN. See README.md.\nEXECUTE IMMEDIATE $$\nDECLARE\n' + DECL + decl + 'BEGIN\n' + g + body + '\nEND;\n$$;\n'

def proc(name, args, returns, body, rights='CALLER'):
    return f'CREATE PROCEDURE @DB@.STANDARDIZE_STAGE.@P@{name}({args}) RETURNS {returns} LANGUAGE SQL EXECUTE AS {rights} AS ' + q(body) + ';'

def source(name):
    return (ROOT / 'src' / name).read_text(encoding='utf-8')

def main():
    write('00_config.sql', """-- Select the approved test database/role/warehouse in your worksheet first.
-- Run this in EVERY session. Replace both REPLACE values; use a new unused prefix.
-- This file creates no database/schema, changes no role/grants, and runs no tests.
SELECT CURRENT_ACCOUNT() AS ACCOUNT_LOCATOR, CURRENT_DATABASE(), CURRENT_ROLE(), CURRENT_WAREHOUSE(), CURRENT_SESSION();
SET Q_ACCOUNT = 'REPLACE_WITH_ACCOUNT_LOCATOR';
SET Q_DATABASE = 'REPLACE_WITH_TEST_DATABASE';
SET Q_PREFIX = 'M0_';
SET Q_ACK = 'ISOLATED_PREFIX_FIXTURES_ONLY';
""" + block("""  EXECUTE IMMEDIATE 'ALTER SESSION SET AUTOCOMMIT = TRUE';
  EXECUTE IMMEDIATE 'ALTER SESSION SET LOCK_TIMEOUT = 60';
  EXECUTE IMMEDIATE 'ALTER SESSION SET DEFAULT_NULL_ORDERING = LAST';
  EXECUTE IMMEDIATE 'ALTER SESSION SET QUERY_TAG = ''M0-SQL-ONLY-2''';
  RETURN 'CONFIGURATION_VALIDATED';""", marker=False) + """
SHOW PARAMETERS LIKE 'AUTOCOMMIT' IN SESSION;
SHOW PARAMETERS LIKE 'LOCK_TIMEOUT' IN SESSION;
SHOW PARAMETERS LIKE 'DEFAULT_NULL_ORDERING' IN SESSION;
""")
    mocks = {
      'STANDARDIZE_AUDIT.ENVIRONMENT': 'PACKAGE_VERSION VARCHAR, DATABASE_NAME VARCHAR, OBJECT_PREFIX VARCHAR, ACCOUNT_NAME VARCHAR, CREATED_AT TIMESTAMP_LTZ, INPUT_HASHES VARIANT',
      'STANDARDIZE_CORE.CUST_NUM_INDIVIDUAL_XREF': 'CUST_NUM NUMBER(38,0) NOT NULL, INDIVIDUAL_ID NUMBER(38,0) NOT NULL, CREATE_DATE TIMESTAMP_NTZ(9) NOT NULL, CREATE_FEED_INSTANCE_ID NUMBER(38,0), REC_TYPE VARCHAR(50)',
      'STANDARDIZE_CORE.PARTY_PROFILE': 'SOURCE_PARTY_PROFILE_ID VARCHAR(320), INDIVIDUAL_ID NUMBER(38,0), SOURCE_SYSTEM_PK_1 VARCHAR(320), PARTY_PROFILE_STATUS_CODE VARCHAR(50), SOURCE_REC_CREATE_DATETIME TIMESTAMP_NTZ(9), SOR_NAME VARCHAR(100), UPDATE_FEED_INSTANCE_ID NUMBER(38,0)',
      'STANDARDIZE_AUDIT.AUTOMATION_LOG': 'AUTOMATION_ID NUMBER(38,0) NOT NULL AUTOINCREMENT START 1 INCREMENT 1 ORDER, AUTOMATION_GUID VARCHAR(128) NOT NULL, AUTOMATION_NAME VARCHAR(128), START_DATE TIMESTAMP_NTZ(9), END_DATE TIMESTAMP_NTZ(9), LAST_ERROR_STEP_NAME VARCHAR(128), LAST_ERROR VARCHAR(4000), AUTOMATION_STATUS VARCHAR(32)',
      'STANDARDIZE_AUDIT.FEED_INSTANCE': 'FEED_INSTANCE_ID NUMBER(38,0) NOT NULL, AUTOMATION_GUID VARCHAR(64), SOURCE_ID NUMBER(38,0) NOT NULL, FEED_ID NUMBER(38,0) NOT NULL, FEED_PROCESS_RESULT VARCHAR(16), FEED_START_DATE TIMESTAMP_NTZ(9) NOT NULL, FEED_END_DATE TIMESTAMP_NTZ(9), CREATE_DATETIME TIMESTAMP_NTZ(9) NOT NULL',
      'STANDARDIZE_AUDIT.SOURCE_LOOKUP': 'SOURCE_ID NUMBER(38,0) NOT NULL, SOURCE_NAME VARCHAR(50) NOT NULL, CREATE_DATETIME TIMESTAMP_NTZ(9) NOT NULL, UPDATE_DATETIME TIMESTAMP_NTZ(9) NOT NULL',
      'STANDARDIZE_AUDIT.SOURCE_FEED_LOOKUP': 'SOURCE_ID NUMBER(38,0) NOT NULL, FEED_ID NUMBER(38,0) NOT NULL, MODEL_NAME VARCHAR(255) NOT NULL, SUBJECT_AREA_FILE VARCHAR(255) NOT NULL, NAME VARCHAR(255) NOT NULL, SPECIFICATION VARCHAR(200000) NOT NULL'
    }
    # No CREATE OR REPLACE: existing prefix objects always stop initial setup.
    body = "  LET v_tables VARCHAR := v_db || '.INFORMATION_SCHEMA.TABLES';\n  LET v_routines VARCHAR := v_db || '.INFORMATION_SCHEMA.PROCEDURES';\n"
    body += "  SELECT COUNT(*) INTO :v_n FROM IDENTIFIER(:v_tables) WHERE TABLE_SCHEMA IN ('STANDARDIZE_CORE','STANDARDIZE_STAGE','STANDARDIZE_AUDIT') AND STARTSWITH(TABLE_NAME,:v_prefix);\n  IF (v_n <> 0) THEN RAISE v_guard; END IF;\n"
    body += "  SELECT COUNT(*) INTO :v_n FROM IDENTIFIER(:v_routines) WHERE PROCEDURE_SCHEMA IN ('STANDARDIZE_CORE','STANDARDIZE_STAGE','STANDARDIZE_AUDIT') AND STARTSWITH(PROCEDURE_NAME,:v_prefix);\n  IF (v_n <> 0) THEN RAISE v_guard; END IF;\n"
    for name, cols in mocks.items():
        schema, table = name.split('.')
        body += execute(f'CREATE TABLE @DB@.{schema}.@P@{table} ({cols});')
    prod_sha=hashlib.sha256((REPO/'dw/STANDARDIZE_STAGE/Procedures/GENERATE_CUST_NUMS.prod.sql').read_bytes()).hexdigest()
    normalized_sha=hashlib.sha256((M0/'scripts/sql/baseline.normalized.sql').read_bytes()).hexdigest()
    body += execute(f"INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@ENVIRONMENT SELECT '{VERSION}',CURRENT_DATABASE(), '@P@', CURRENT_ACCOUNT(), CURRENT_TIMESTAMP(), OBJECT_CONSTRUCT('productionFileSha256','{prod_sha}','normalizedFileSha256','{normalized_sha}');")
    body += execute("INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@SOURCE_LOOKUP SELECT 99,'M0 SYNTHETIC HARNESS',CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP();")
    body += execute("INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@SOURCE_FEED_LOOKUP VALUES (99,140,'M0_ONLY','SYNTHETIC','GENERATE_CUST_NUMS','Fixture, not deployed RPDM metadata');")
    write('01_mock_current_state.sql', block(body + "  RETURN 'MOCKS_CREATED';", marker=False))

    tables = {
      'TEST_DEFINITION': 'TEST_ID VARCHAR, SUITE VARCHAR, DESCRIPTION VARCHAR, DISPOSITION VARCHAR, FIXTURE_SQL VARCHAR, EXECUTE_SQL VARCHAR, ASSERT_SQL VARCHAR, EXPECTED VARIANT, PREREQUISITE VARCHAR, DEFINITION_SHA256 VARCHAR',
      'TEST_RUN': 'RUN_ID VARCHAR, RUN_KIND VARCHAR, STARTED_AT TIMESTAMP_LTZ, FINISHED_AT TIMESTAMP_LTZ, RUN_STATUS VARCHAR, ENVIRONMENT VARIANT, PACKAGE_VERSION VARCHAR',
      'TEST_RESULT': 'RUN_ID VARCHAR, TEST_ID VARCHAR, DISPOSITION VARCHAR, STATUS VARCHAR, STARTED_AT TIMESTAMP_LTZ, FINISHED_AT TIMESTAMP_LTZ, PHASE VARCHAR, FEED_INSTANCE_ID NUMBER, AUTOMATION_GUID VARCHAR(36), EXPECTED VARIANT, ACTUAL VARIANT, ASSERTION_PASS BOOLEAN, SQLCODE NUMBER, SQLSTATE VARCHAR, SQLERRM VARCHAR, LAST_QUERY_ID VARCHAR',
      'ARTIFACT': 'ARTIFACT_ID VARCHAR, CREATED_AT TIMESTAMP_LTZ, KIND VARCHAR, STATUS VARCHAR, SQL_TEXT VARCHAR, SQL_SHA256 VARCHAR, QUERY_ID VARCHAR, ERROR VARIANT',
      'SERIAL_PAIR': 'RUN_ID VARCHAR, PAIR_KIND VARCHAR, FEED_A NUMBER, FEED_B NUMBER, GUID_A VARCHAR(36), GUID_B VARCHAR(36), INITIAL_VALUE NUMBER, CREATED_AT TIMESTAMP_LTZ'
    }
    body = ''
    for name, cols in tables.items():
        body += execute(f'CREATE TABLE @DB@.STANDARDIZE_AUDIT.@P@{name} ({cols});')
    body += execute('CREATE SEQUENCE @DB@.STANDARDIZE_AUDIT.@P@FEED_SEQUENCE START = 900000 INCREMENT = 1;')
    write('02_test_harness.sql', block(body + "  RETURN 'HARNESS_TABLES_CREATED';"))

    baseline = (M0/'scripts/sql/baseline.normalized.sql').read_text(encoding='utf-8')
    # Rewrite only identifiers in executable code; comments/error messages remain exact.
    def prefix_code(sql):
        chunks = re.split(r"('(?:''|[^'])*'|--[^\n]*)", sql)
        for i in range(0, len(chunks), 2):
            chunks[i] = re.sub(r'\b(STANDARDIZE_CORE|STANDARDIZE_STAGE)\.([A-Za-z_][A-Za-z0-9_]*)', r'@DB@.\1.@P@\2', chunks[i])
        return ''.join(chunks)
    mapped = prefix_code(baseline)
    mapped = mapped.replace('CREATE OR REPLACE PROCEDURE "GENERATE_CUST_NUMS"()', 'CREATE PROCEDURE @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS()', 1)
    (ROOT/'src/baseline.prefixed.sql.template').write_text(mapped,encoding='utf-8',newline='\n')
    write('evidence/baseline-prefix.diff', ''.join(difflib.unified_diff(baseline.splitlines(True), mapped.splitlines(True), fromfile='original-M0/baseline.normalized.sql', tofile='sql-only/src/baseline.prefixed.sql.template')))
    # Represent the body with a single-quoted literal when nesting CREATE inside a scripting block.
    before, rest = mapped.split('AS $$', 1)
    baseline_body, tail = rest.rsplit('$$', 1)
    baseline_ddl = before + 'AS ' + q(baseline_body) + tail
    deployment = [
      ('PROTOTYPE_GATE', 'CREATE TABLE @DB@.STANDARDIZE_AUDIT.@P@CUST_NUM_PROCESS (PROCESS_NAME VARCHAR, LAST_RUN_ID NUMBER);'),
      ('GATE_SEED', "INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@CUST_NUM_PROCESS VALUES ('GENERATE_CUST_NUMS',NULL);"),
      ('PROTOTYPE_BUSINESS', 'CREATE TABLE @DB@.STANDARDIZE_CORE.@P@PROTOTYPE_BUSINESS (ID NUMBER, VALUE NUMBER);'),
      ('BUSINESS_SEED', 'INSERT INTO @DB@.STANDARDIZE_CORE.@P@PROTOTYPE_BUSINESS VALUES (1,0);'),
      ('PROTOTYPE_WORK', 'CREATE TABLE @DB@.STANDARDIZE_STAGE.@P@PROTOTYPE_WORK (RUN_ID NUMBER, OBSERVED_VALUE NUMBER);'),
      ('SCENARIO', 'CREATE TABLE @DB@.STANDARDIZE_STAGE.@P@SCENARIO (FEED_INSTANCE_ID NUMBER, HOLD_SECONDS NUMBER, FAIL_AFTER_APPLY BOOLEAN, ZERO_WORK BOOLEAN);'),
      ('PROTOTYPE_LOG', 'CREATE TABLE @DB@.STANDARDIZE_AUDIT.@P@PROTOTYPE_PROCESS_LOG (FEED_INSTANCE_ID NUMBER, RESULT VARIANT, UPDATED_AT TIMESTAMP_LTZ);'),
      ('CALLER_ACTION', 'CREATE TABLE @DB@.STANDARDIZE_AUDIT.@P@CALLER_ACTION (FEED_INSTANCE_ID NUMBER, ACTION VARCHAR, RESULT VARIANT, CREATED_AT TIMESTAMP_LTZ);'),
      ('BASELINE_COMPILE', baseline_ddl),
      ('AUDIT_HELPER_COMPILE', proc('WRITE_PROTOTYPE_LOG','P_FEED NUMBER, P_RESULT VARIANT','VARCHAR',source('audit.sql'), 'OWNER')),
      ('CANDIDATE_COMPILE', proc('GENERATE_CUST_NUMS_PROTOTYPE','FEED_INSTANCE_ID NUMBER(38,0), AUTOMATION_GUID VARCHAR(36), PREVIEW BOOLEAN, RESULT OUT VARIANT','VARCHAR',source('candidate.sql'), 'OWNER')),
      ('CALLER_ADAPTER_COMPILE', proc('CALLER_ADAPTER','P_FEED NUMBER, P_GUID VARCHAR(36), P_PREVIEW BOOLEAN, RESULT OUT VARIANT','VARCHAR',source('adapter.sql'))),
      ('RUN_CASE_COMPILE', proc('RUN_CASE','P_RUN VARCHAR, P_CASE VARCHAR','VARCHAR',source('run_case.sql'))),
      ('RUN_SUITE_COMPILE', proc('RUN_SUITE','','VARCHAR',source('run_suite.sql'))),
      ('SERIAL_WORKER_COMPILE', proc('SERIAL_WORKER','P_RUN VARCHAR, P_WORKER VARCHAR','VARIANT',source('serial_worker.sql')))
    ]
    body = ''
    for step, ddl in deployment:
        body += f"  v_step := '{step}';\n  v_sql := {bind(ddl)};\n"
        body += "  INSERT INTO IDENTIFIER(:v_artifacts) SELECT UUID_STRING(),CURRENT_TIMESTAMP(),'DEPLOY_'||:v_step,'RUNNING',:v_sql,SHA2(:v_sql,256),NULL,NULL;\n"
        body += "  BEGIN\n    EXECUTE IMMEDIATE :v_sql;\n    v_query := SQLID;\n    UPDATE IDENTIFIER(:v_artifacts) SET STATUS='PASS',QUERY_ID=:v_query WHERE KIND='DEPLOY_'||:v_step AND STATUS='RUNNING';\n  EXCEPTION WHEN OTHER THEN\n    v_error := OBJECT_CONSTRUCT('sqlcode',SQLCODE,'sqlstate',SQLSTATE,'message',SQLERRM);\n    UPDATE IDENTIFIER(:v_artifacts) SET STATUS='FAIL',ERROR=:v_error WHERE KIND='DEPLOY_'||:v_step AND STATUS='RUNNING';\n    RETURN 'DEPLOYMENT_FAILED: '||v_step||'. Run 06_export_evidence.sql; use a fresh prefix for a corrected attempt.';\n  END;\n"
    write('03_deploy_migrate.sql', block(body + "  RETURN 'M0_PROTOTYPES_DEPLOYED_NO_ALLOCATOR_MIGRATION';", "  v_step VARCHAR;\n  v_query VARCHAR;\n  v_error VARIANT;\n  v_artifacts VARCHAR := v_db || '.STANDARDIZE_AUDIT.' || v_prefix || 'ARTIFACT';\n"))
    build_definitions()
    write('04_run_tests.sql', block(execute('CALL @DB@.STANDARDIZE_STAGE.@P@RUN_SUITE();') + "  RETURN 'Run created; inspect 06_export_evidence.sql for results, including failures.';"))
    build_serial()
    build_exports()
    print('Generated SQL-only package locally; no database execution.')

def definition(test_id, suite, description, fixture='', invocation='', assertion='', expected=None, disposition='REQUIRED', prerequisite='03 deployment successful; no concurrent suite on this prefix'):
    return dict(testId=test_id, suite=suite, description=description, disposition=disposition, fixtureSql=fixture, executeSql=invocation, assertSql=assertion, expected=expected or {}, prerequisite=prerequisite, status='NOT_RUN')

def output_stmt(expr):
    return "UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ACTUAL=" + expr + " WHERE RUN_ID='@RUN@' AND TEST_ID='@CASE@';"

def assertion_stmt(expr):
    return "UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT SET ASSERTION_PASS=(" + expr + ") WHERE RUN_ID='@RUN@' AND TEST_ID='@CASE@';"

def build_definitions():
    original = json.loads((M0/'fixtures/behavior-cases.json').read_text())
    definitions = []
    for case in original['cases']:
        fixture = 'BEGIN\nDELETE FROM @DB@.STANDARDIZE_CORE.@P@PARTY_PROFILE;\nDELETE FROM @DB@.STANDARDIZE_CORE.@P@CUST_NUM_INDIVIDUAL_XREF;\n'
        for table, cols, rows in [('PARTY_PROFILE',original['profileColumns'],case['profiles']),('CUST_NUM_INDIVIDUAL_XREF',original['coreColumns'],case['core'])]:
            if rows:
                fixture += f"INSERT INTO @DB@.STANDARDIZE_CORE.@P@{table} ({','.join(cols)}) VALUES " + ','.join('('+','.join(map(lit,row))+')' for row in rows) + ';\n'
        fixture += 'END;'
        expected = case['productionBaseline'].copy()
        expected['rows'] = [[r[0],r[1],r[2],r[4]] for r in case['core']] + expected['newAssignments'] + expected['newReservations']
        expected['retainedRows'] = case['core']
        # Expected errors must originate in invocation, not fixture or assertion execution.
        invoke = "DECLARE v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@BASELINE_GENERATE_CUST_NUMS() INTO :v_return; " + output_stmt("OBJECT_CONSTRUCT('returnValue',:v_return)") + ' END;'
        assertion = source('assert_baseline.sql')
        definitions.append(definition('BASELINE-'+case['id'],'BASELINE',case['description'],fixture,invoke,assertion,expected))
        definitions.append(definition('TARGET-'+case['id'],'TARGET',case['description'],expected=case['approvedTarget'],disposition='DEFERRED',prerequisite=original['targetExecutionPrerequisite']))

    def contract(case, preview=False, fail=False, zero=False, nullarg=None, adapter=True):
        fixture = f"""BEGIN
INSERT INTO @DB@.STANDARDIZE_STAGE.@P@SCENARIO VALUES (@FEED@,0,{lit(fail)},{lit(zero)});
INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@AUTOMATION_LOG (AUTOMATION_GUID,AUTOMATION_NAME,START_DATE,AUTOMATION_STATUS) VALUES ('@GUID@','M0_CALLER',CURRENT_TIMESTAMP(),'RUNNING');
INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@FEED_INSTANCE VALUES (@FEED@,'@GUID@',99,140,'RUNNING',CURRENT_TIMESTAMP(),NULL,CURRENT_TIMESTAMP());
END;"""
        args = ['@FEED@',"'@GUID@'",lit(preview)]
        if nullarg is not None: args[nullarg] = 'NULL'
        name = 'CALLER_ADAPTER' if adapter else 'GENERATE_CUST_NUMS_PROTOTYPE'
        invocation = 'DECLARE v_out VARIANT; v_return VARCHAR; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@'+name+'('+','.join(args)+',:v_out) INTO :v_return; ' + output_stmt("OBJECT_CONSTRUCT_KEEP_NULL('result',:v_out,'returnValue',:v_return)") + ' END;'
        status = 'ERROR' if fail or nullarg is not None else 'SUCCESS'
        persistence = 'NOT_ATTEMPTED' if preview or zero or nullarg is not None else ('ROLLED_BACK' if fail else 'COMMITTED')
        code = -20970 if nullarg is not None else (-20972 if fail else None)
        checks = f"ACTUAL:result:status::VARCHAR='{status}' AND ACTUAL:returnValue::VARCHAR='{status}' AND ACTUAL:result:persistence::VARCHAR='{persistence}' AND ACTUAL:result:scope::VARCHAR='M0_PROTOTYPE' AND ACTUAL:result:contractVersion::NUMBER=2"
        if code: checks += f" AND ACTUAL:result:error:sqlcode::NUMBER={code} AND ACTUAL:result:error:sqlstate::VARCHAR='P0001' AND LENGTH(ACTUAL:result:error:message::VARCHAR)>0"
        else: checks += " AND IS_NULL_VALUE(ACTUAL:result:error)"
        if nullarg != 0: checks += ' AND ACTUAL:result:feedInstanceId::NUMBER=FEED_INSTANCE_ID'
        if nullarg != 1: checks += ' AND ACTUAL:result:automationGuid::VARCHAR=AUTOMATION_GUID'
        if adapter:
            checks += f" AND (SELECT COUNT(*) FROM @DB@.STANDARDIZE_AUDIT.@P@FEED_INSTANCE WHERE FEED_INSTANCE_ID=@FEED@ AND FEED_PROCESS_RESULT='{status}')=1 AND (SELECT COUNT(*) FROM @DB@.STANDARDIZE_AUDIT.@P@AUTOMATION_LOG WHERE AUTOMATION_GUID='@GUID@' AND AUTOMATION_STATUS='{status}')=1"
            if fail: checks += " AND (SELECT COUNT(*) FROM @DB@.STANDARDIZE_AUDIT.@P@AUTOMATION_LOG WHERE AUTOMATION_GUID='@GUID@' AND LAST_ERROR_STEP_NAME='BUSINESS_MARKER' AND LAST_ERROR ILIKE '%-20972%')=1"
            checks += f" AND (SELECT COUNT(*) FROM @DB@.STANDARDIZE_AUDIT.@P@CALLER_ACTION WHERE FEED_INSTANCE_ID=@FEED@ AND ACTION='{('STOP' if fail else 'CONTINUE')}')=1"
        definitions.append(definition(case,'CONTRACT','OUT JSON and caller action: '+case,fixture,invocation,assertion_stmt(checks),dict(status=status,persistence=persistence,sqlcode=code)))
    contract('JSON-LIVE')
    contract('JSON-PREVIEW',preview=True)
    contract('JSON-ZERO-WORK',zero=True)
    contract('JSON-ERROR',fail=True)
    contract('JSON-NULL-FEED',nullarg=0,adapter=False)
    contract('JSON-NULL-GUID',nullarg=1,adapter=False)
    contract('JSON-NULL-MODE',nullarg=2,adapter=False)
    definitions.append(definition('JSON-LEGACY-ABSENT','CONTRACT','Zero-argument prototype cannot invoke an allocator',invocation='CALL @DB@.STANDARDIZE_STAGE.@P@GENERATE_CUST_NUMS_PROTOTYPE();',assertion=assertion_stmt("SQLCODE IS NOT NULL AND PHASE='EXECUTE' AND (SQLERRM ILIKE '%argument%' OR SQLERRM ILIKE '%signature%' OR SQLERRM ILIKE '%Unknown%')"),expected={'error':'SIGNATURE_ERROR'}))
    for case, args in [('JSON-MISSING-MODE',"@FEED@,'@GUID@'"),('JSON-MISSING-OUTPUT',"@FEED@,'@GUID@',FALSE")]:
        definitions.append(definition(case,'CONTRACT','Missing required argument cannot allocate',invocation='CALL @DB@.STANDARDIZE_STAGE.@P@GENERATE_CUST_NUMS_PROTOTYPE('+args+');',assertion=assertion_stmt("SQLCODE IS NOT NULL AND PHASE='EXECUTE' AND (SQLERRM ILIKE '%argument%' OR SQLERRM ILIKE '%signature%' OR SQLERRM ILIKE '%Unknown%')"),expected={'error':'SIGNATURE_ERROR'}))
    for case, rows in [('GATE-MISSING',0),('GATE-DUPLICATE',2)]:
        fixture = "BEGIN DELETE FROM @DB@.STANDARDIZE_AUDIT.@P@CUST_NUM_PROCESS;\n"
        if rows:
            fixture += "INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@CUST_NUM_PROCESS VALUES ('GENERATE_CUST_NUMS',NULL),('GENERATE_CUST_NUMS',NULL);\n"
        fixture += "INSERT INTO @DB@.STANDARDIZE_STAGE.@P@SCENARIO VALUES (@FEED@,0,FALSE,FALSE); END;"
        invocation = "DECLARE v_out VARIANT; BEGIN CALL @DB@.STANDARDIZE_STAGE.@P@GENERATE_CUST_NUMS_PROTOTYPE(@FEED@,'@GUID@',FALSE,:v_out); " + output_stmt(':v_out') + ' END;'
        assertion = 'BEGIN '+assertion_stmt("ACTUAL:status::VARCHAR='ERROR' AND ACTUAL:error:sqlcode::NUMBER=-20971 AND ACTUAL:stage::VARCHAR='GATE' AND ACTUAL:persistence::VARCHAR='NOT_ATTEMPTED'")
        assertion += " DELETE FROM @DB@.STANDARDIZE_AUDIT.@P@CUST_NUM_PROCESS; INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@CUST_NUM_PROCESS VALUES ('GENERATE_CUST_NUMS',NULL); END;"
        definitions.append(definition(case,'CONTRACT','Serialization requires exactly one gate row',fixture,invocation,assertion,{'status':'ERROR','sqlcode':-20971}))
    definitions.append(definition('REL-NULL-NOT-IN','RELATIONAL','NULL NOT IN differs from NOT EXISTS',invocation=output_stmt("OBJECT_CONSTRUCT('notIn',(SELECT COUNT(*) FROM (SELECT 7 AS ID) S WHERE ID NOT IN (SELECT NULL::NUMBER)), 'notExists',(SELECT COUNT(*) FROM (SELECT 7 AS ID) S WHERE NOT EXISTS (SELECT 1 FROM (SELECT NULL::NUMBER AS ID) T WHERE T.ID=S.ID)))"),assertion=assertion_stmt('ACTUAL:notIn::NUMBER=0 AND ACTUAL:notExists::NUMBER=1'),expected={'notIn':0,'notExists':1}))
    definitions.append(definition('REL-OR-SENTINEL','RELATIONAL','OR/null-to-zero matching can suppress a proposed row',invocation=output_stmt("OBJECT_CONSTRUCT('legacyMatch',(SELECT COUNT(*) FROM (SELECT 0 AS ID, 10 AS NUM) T JOIN (SELECT NULL::NUMBER AS ID, 20 AS NUM) S ON T.ID=IFNULL(S.ID,0) OR T.NUM=IFNULL(S.NUM,0)), 'directMatch',(SELECT COUNT(*) FROM (SELECT 0 AS ID, 10 AS NUM) T JOIN (SELECT NULL::NUMBER AS ID, 20 AS NUM) S ON T.ID=S.ID OR T.NUM=S.NUM))"),assertion=assertion_stmt('ACTUAL:legacyMatch::NUMBER=1 AND ACTUAL:directMatch::NUMBER=0'),expected={'legacyMatch':1,'directMatch':0}))
    for kind in ['COMMIT','ROLLBACK','PREVIEW']:
        definitions.append(definition('SERIAL-'+kind,'SERIALIZATION','Two independent sessions; '+kind,expected={'ordering':'B requests during A hold; B acquires after A release; fresh marker; distinct sessions'},prerequisite='Run 05a/05b/05c/05d separately for '+kind))
    excluded = ['PERMISSIONS-OWNERSHIP','TRANSACTION-MATRIX','TIMEOUT-LIMIT','LOGGING-FAILURES','LOCKING-BEYOND-SERIALIZATION']
    for name in excluded:
        definitions.append(definition('EXCLUDED-'+name,'EXCLUDED',name,disposition='EXCLUDED',expected={'execution':'NOT_RUN','riskAcceptedByUser':'2026-10-19'},prerequisite='Explicitly removed from qualification scope; not a passing test'))
    # Keep genuine future checks; original registry accidentally also contains table-header pseudo IDs.
    old = json.loads((M0/'fixtures/check-registry.json').read_text())['checks']
    for c in old:
        if re.fullmatch(r'TARGET-T\d{2}',c['checkId']):
            disposition = 'EXCLUDED' if c['checkId'] in {'TARGET-T16','TARGET-T17','TARGET-T21'} else 'DEFERRED'
            revised = {
              'TARGET-T01':'Compile baseline and target SQL and validate objects/membership. Permission/ownership tests excluded; database binding remains a guarded deployment requirement.',
              'TARGET-T16':'Transaction/AUTOCOMMIT/caller-transaction fault matrix excluded. Only serialization lifecycle remains required under T18.',
              'TARGET-T17':'Rollback/logging failure injection excluded. Original caught business error in JSON and caller STOP are required under T22.',
              'TARGET-T19':'Exactly-one-row gate and no bypass remain serialization prerequisites; exact timeout/acquisition fault suite excluded.',
              'TARGET-T20':'Retain stage/run isolation during serialization and ordinary successful cleanup; transactional truncation/cleanup failure matrix excluded.',
              'TARGET-T21':'Commit-uncertainty/post-commit logging failure injection excluded; contract still requires truthful persistence and no blind retry.',
              'TARGET-T22':'Explicit feed/GUID/preview plus RESULT OUT VARIANT; supplied identity roundtrip, contractVersion/status/error/persistence/action, caller logging and STOP on ERROR, no legacy bypass. Missing/default inputs cannot allocate. Permission/grant and logging-fault tests excluded. Actual RPDM binding remains required before cutover.'
            }.get(c['checkId'], c['expected'])
            definitions.append(definition(c['checkId'],'FUTURE_TARGET',revised,disposition=disposition,prerequisite='Future allocator; reduced-scope coverage in COVERAGE.md',expected={'approvedExpectation':revised,'historicalExpectation':c['expected']}))
    write('fixtures/check-registry.json',json.dumps({'version':VERSION,'snowflakeExecution':'NOT_RUN','checks':definitions},indent=2))
    body="  LET v_defs VARCHAR := v_db || '.STANDARDIZE_AUDIT.' || v_prefix || 'TEST_DEFINITION';\n  SELECT COUNT(*) INTO :v_n FROM IDENTIFIER(:v_defs);\n  IF (v_n<>0) THEN RAISE v_guard; END IF;\n"
    for d in definitions:
        vals=[q(d['testId']),q(d['suite']),q(d['description']),q(d['disposition']),q(d['fixtureSql']),q(d['executeSql']),q(d['assertSql']), 'PARSE_JSON('+q(json.dumps(d['expected'],separators=(',',':')))+')',q(d['prerequisite'])]
        # SHA over the three rendered SQL texts, separated by ASCII unit separator.
        vals.append('SHA2('+q(d['fixtureSql'])+'||CHR(31)||'+q(d['executeSql'])+'||CHR(31)||'+q(d['assertSql'])+',256)')
        body += execute('INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION SELECT '+','.join(vals)+';')
    write('03b_register_tests.sql',block(body+"  RETURN 'TESTS_REGISTERED';"))

def build_serial():
    body = '  v_sql := '+bind(source('prepare_serial.sql'))+';\n  v_rows := (EXECUTE IMMEDIATE :v_sql);\n  RETURN TABLE(v_rows);'
    write('05a_prepare_serialization.sql', "-- Run after 04 completes. Repeat for COMMIT, ROLLBACK, PREVIEW; never overlap pairs.\nSET Q_PAIR_KIND = 'COMMIT';\n" + block(body,'  v_rows RESULTSET;\n'))
    for worker, letter in [('A','b'),('B','c')]:
        body="  IF (NOT REGEXP_LIKE(v_run,'^[0-9a-fA-F-]{36}$')) THEN RAISE v_guard; END IF;\n"
        body += "  v_sql := 'CALL ' || v_db || '.STANDARDIZE_STAGE.' || v_prefix || 'SERIAL_WORKER(?,?)';\n"
        body += "  v_rows := (EXECUTE IMMEDIATE :v_sql USING (v_run,v_worker));\n  RETURN TABLE(v_rows);"
        write(f'05{letter}_session_{worker}.sql',f"-- Run 00_config.sql in this session first. Start B, then A within 90 seconds.\nSET Q_SERIAL_RUN_ID = 'REPLACE_WITH_RUN_ID_FROM_05a';\n"+block(body,f"  v_run VARCHAR := $Q_SERIAL_RUN_ID;\n  v_worker VARCHAR := '{worker}';\n  v_rows RESULTSET;\n"))
    body = '  v_sql := '+bind(source('assert_serial.sql'))+';\n  v_rows := (EXECUTE IMMEDIATE :v_sql);\n  RETURN TABLE(v_rows);'
    write('05d_assert_serialization.sql', "-- Run after BOTH workers finish; retain failures before repeating with a NEW run.\nSET Q_SERIAL_RUN_ID = 'REPLACE_WITH_RUN_ID_FROM_05a';\n" + block(body,'  v_rows RESULTSET;\n'))

def build_exports():
    queries = [
      ('ENVIRONMENT', 'SELECT * FROM @DB@.STANDARDIZE_AUDIT.@P@ENVIRONMENT'),
      ('SUMMARY', "SELECT RUN_ID,DISPOSITION,STATUS,COUNT(*) AS TEST_COUNT FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT GROUP BY RUN_ID,DISPOSITION,STATUS ORDER BY RUN_ID,DISPOSITION,STATUS"),
      ('RUNS', 'SELECT * FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RUN ORDER BY STARTED_AT'),
      ('RESULTS', 'SELECT * FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT ORDER BY RUN_ID,TEST_ID'),
      ('ARTIFACTS', 'SELECT * FROM @DB@.STANDARDIZE_AUDIT.@P@ARTIFACT ORDER BY CREATED_AT'),
      ('DEFINITIONS', 'SELECT * FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_DEFINITION ORDER BY TEST_ID'),
      ('AUTOMATION_LOG', 'SELECT * FROM @DB@.STANDARDIZE_AUDIT.@P@AUTOMATION_LOG ORDER BY AUTOMATION_ID'),
      ('FEED_INSTANCE', 'SELECT * FROM @DB@.STANDARDIZE_AUDIT.@P@FEED_INSTANCE ORDER BY FEED_INSTANCE_ID'),
      ('PROCESS_LOG', 'SELECT * FROM @DB@.STANDARDIZE_AUDIT.@P@PROTOTYPE_PROCESS_LOG ORDER BY FEED_INSTANCE_ID'),
      ('CALLER_ACTION', 'SELECT * FROM @DB@.STANDARDIZE_AUDIT.@P@CALLER_ACTION ORDER BY FEED_INSTANCE_ID'),
      ('SERIAL_PAIRS', 'SELECT * FROM @DB@.STANDARDIZE_AUDIT.@P@SERIAL_PAIR ORDER BY CREATED_AT'),
    ]
    body=''
    for label, query in queries:
        wrapped="SELECT OBJECT_CONSTRUCT_KEEP_NULL(*) AS PAYLOAD FROM ("+query+")"
        body += "  v_sql := " + bind(wrapped) + ';\n  BEGIN\n    v_rows := (EXECUTE IMMEDIATE :v_sql);\n'
        body += f"    FOR rec IN v_rows DO\n      v_all := ARRAY_APPEND(v_all,OBJECT_CONSTRUCT('section','{label}','row',rec.PAYLOAD));\n    END FOR;\n"
        body += f"  EXCEPTION WHEN OTHER THEN\n    v_error := OBJECT_CONSTRUCT('section','{label}','sqlcode',SQLCODE,'sqlstate',SQLSTATE,'message',SQLERRM);\n    v_all := ARRAY_APPEND(v_all,OBJECT_CONSTRUCT('section','EVIDENCE_QUERY_ERROR','row',v_error));\n  END;\n"
    write('06_export_evidence.sql',block(body+"  v_export := (SELECT VALUE:section::VARCHAR AS SECTION, VALUE:row AS EVIDENCE FROM TABLE(FLATTEN(INPUT=>:v_all)));\n  RETURN TABLE(v_export);",'  v_rows RESULTSET;\n  v_export RESULTSET;\n  v_error VARIANT;\n  v_all ARRAY := ARRAY_CONSTRUCT();\n'))

if __name__ == '__main__': main()
