# M0 SQL-only qualification revision

This is the active user-approved SQL-only package (`M0-SQL-ONLY-2`). Use the numbered SQL files in this directory. No Python, connector, DuckDB, or local SQL runner is required to execute them. The `tools/` Python files are local authoring/validation utilities only.

The original [M0 package](../README.md), its input snapshots, baseline normalization, fixtures, and evidence remain unchanged. Its broader fault suites and runner are historical for this revised scope. Use [COVERAGE.md](COVERAGE.md) and the current [JSON contract](CONTRACT.md). Original production and historical/reference procedures are unchanged. All new SQL is locally prepared, **not Snowflake-compiled or executed**.

## Scope and prerequisites

This package runs the production baseline on synthetic data and tests an M0 JSON/serialization prototype. The prototype increments one synthetic integer; it is not the redesigned customer-number allocator. Target allocation/migration cases remain NOT_RUN with their future implementation prerequisites. `03_deploy_migrate.sql` is a consolidated M0 fixture/prototype deployment; it performs no legacy-data migration and starts no M1 implementation.

You need an approved test database containing `STANDARDIZE_CORE`, `STANDARDIZE_STAGE`, and `STANDARDIZE_AUDIT`, an active warehouse, and a role already able to create/use the prefixed tables, sequence, and SQL procedures there. No scripts create databases/schemas, switch roles, or change grants. Use a new unused prefix matching `M[0-9]+_`, such as `M0_` or `M01_`. A shared database is possible only with an approved isolated prefix: every dependency is fully qualified and prefixed. No reads/clones/writes target the unprefixed current-state objects.

Use two independent Snowflake sessions for serialization. Confirm distinct `CURRENT_SESSION()` values; two editor tabs are not proof of separate sessions. Start with no open transaction. `00_config.sql` sets AUTOCOMMIT TRUE, LOCK_TIMEOUT 60, and DEFAULT_NULL_ORDERING LAST after its guard. The 60-second limit is configured but its exact timeout behavior is excluded from qualification. Only one sequential suite or serialization pair may use a prefix at a time.

## Run order

1. Open [00_config.sql](00_config.sql), set `Q_ACCOUNT` to the account locator returned by `CURRENT_ACCOUNT()`, set uppercase `Q_DATABASE`, choose an unused `Q_PREFIX`, and select that database/role/warehouse in the worksheet. Execute the complete file. Stop unless it reports `CONFIGURATION_VALIDATED`. Save its output.
2. Run [01_mock_current_state.sql](01_mock_current_state.sql), then [02_test_harness.sql](02_test_harness.sql). These create the six mocks, marker, and harness tables. Setup refuses an existing prefix rather than replacing it. Stop on any error and save the worksheet error/query ID. For a corrected setup attempt, use a fresh prefix; do not erase the failed attempt.
3. Run [03_deploy_migrate.sql](03_deploy_migrate.sql). Require `M0_PROTOTYPES_DEPLOYED_NO_ALLOCATOR_MIGRATION`. Each deployment step records its exact SQL, SHA-256, status, query ID, and error. DDL steps are separately committed, not an atomic migration. If any step fails, run the evidence export and stop this attempt.
4. Run [03b_register_tests.sql](03b_register_tests.sql) once. It persists the tests and authored expectations and refuses an already populated registry. Run [04_run_tests.sql](04_run_tests.sql). It continues after individual test failures, retaining each error. Inspect/export results; a completed runner is not a passing suite. New suite invocations have new run IDs and retain previous results.
5. Run [06_export_evidence.sql](06_export_evidence.sql) and save **all rows**, including FAIL, ERROR, NOT_RUN, RUNNING, and evidence-query errors. A failed fixture/assertion is not accepted as an expected procedure error.
6. Perform the serialization sequence below three times: COMMIT, ROLLBACK, PREVIEW. Export again after every pair.

Do not run the old `M0/scripts/sql/baseline_pb*.sql` against this prefixed package. Their fixture definitions have been incorporated into the new stored registry. The new deployment uses a separately named prefixed baseline and a separately named prefixed JSON prototype; no old allocator is installed under the candidate name.

## Serialization: two sessions

Run `00_config.sql` in both sessions with the same account/database/prefix. Keep both sessions at AUTOCOMMIT TRUE and no outer transaction.

1. Run [05a_prepare_serialization.sql](05a_prepare_serialization.sql), choosing `Q_PAIR_KIND='COMMIT'`, `'ROLLBACK'`, or `'PREVIEW'`. Save the returned `runId`.
2. Paste that run ID into [05c_session_B.sql](05c_session_B.sql), [05b_session_A.sql](05b_session_A.sql), and [05d_assert_serialization.sql](05d_assert_serialization.sql).
3. Start **B first** in its own session. It waits up to 90 seconds for A's independently logged held-gate signal. Start A in the other session within that interval. A holds for 30 seconds after preparation and the independent logging call. Do not run any setup, suite, or other pair concurrently.
4. Wait for both calls to finish. Run `05d_assert_serialization.sql` once. It checks distinct sessions, actual overlap, acquisition ordering, A's outcome, B's fresh observation, and final marker value. Calling A then B sequentially fails the overlap assertion.
5. Save the evidence even on failure. Prepare a **new** run for a retry. Never rerun an already used worker or replace a failed result.

An interrupted worker can leave RUNNING/NOT_RUN evidence. Save the error, query ID, and export; do not mark it PASS or silently reset it. Use a fresh prefix for a new attempt if the old run cannot be conclusively completed. This package has no destructive cleanup script.

## Evidence to return

Save the full result grid from `06_export_evidence.sql` as CSV or JSON and put it under `evidence/runs/<your-attempt>/`, along with the edited config and raw worksheet errors/query IDs. The export contains environment identity, run/test results, exact registered tests, actual deployed SQL and hashes, mock audit records, and caller actions. SQL-side hashes identify rendered SQL text; they are distinct from local file-byte hashes in the package manifest.

Compilation/setup can fail before evidence tables exist. Save those errors directly from the worksheet. The export tolerates missing later objects and emits `EVIDENCE_QUERY_ERROR` rows; it cannot recover server output lost before execution. Full test runs and all three serialization pairs must be tied to the same deployed package and prefix when assessing a candidate. A later success does not delete or retroactively pass an earlier failure.

No reduced M0 pass is claimed until the required baseline/relational/JSON/gate tests and three serialization checks have passing Snowflake evidence and failures have dispositions. Excluded checks remain NOT_RUN/EXCLUDED. Deferred allocator/migration/workload checks remain NOT_RUN/DEFERRED; they are prerequisites for later milestones, not hidden M0 passes. See [STATUS.md](STATUS.md).

## Local provenance

The production baseline's original quoting normalization is retained in [the original normalization diff](../evidence/normalization.diff). The only additional baseline changes here are procedure/dependency identifiers; [baseline-prefix.diff](evidence/baseline-prefix.diff) records them. Comments and exception message text are preserved. Executable source is [baseline.prefixed.sql.template](src/baseline.prefixed.sql.template); the consolidated deployment embeds the same body in a quoted string.

All six current-state mocks use repository DDL as evidence. XREF preserves every column/type/nullability. Other mocks retain only fields needed for these tests; audit GUID widths remain 128/64. Source/feed 99/140 rows are synthetic harness fixtures, not claims about deployed RPDM metadata. Synthetic GUIDs/feed identities are issued by the test harness, never by the allocator prototype. The full real-party schema and audit defaults/constraints require reconciliation before later deployment.
