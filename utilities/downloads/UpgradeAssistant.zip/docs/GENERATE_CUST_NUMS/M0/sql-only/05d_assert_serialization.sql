-- Run after BOTH workers finish; retain failures before repeating with a NEW run.
SET Q_SERIAL_RUN_ID = 'REPLACE_WITH_RUN_ID_FROM_05a';
-- Generated locally; Snowflake compilation/execution NOT_RUN. See README.md.
EXECUTE IMMEDIATE $$
DECLARE
  v_db VARCHAR := $Q_DATABASE;
  v_prefix VARCHAR := $Q_PREFIX;
  v_account VARCHAR := $Q_ACCOUNT;
  v_ack VARCHAR := $Q_ACK;
  v_sql VARCHAR;
  v_n NUMBER;
  v_guard EXCEPTION (-20990, 'Qualification guard failed: check account, database, prefix, marker, and caller transaction');
  v_rows RESULTSET;
BEGIN
  IF (v_db IS NULL OR v_prefix IS NULL OR v_account IS NULL OR v_ack IS NULL
      OR NOT REGEXP_LIKE(v_db, '^[A-Z][A-Z0-9_]*$')
      OR NOT REGEXP_LIKE(v_prefix, '^M[0-9]+_$')
      OR v_account <> CURRENT_ACCOUNT() OR v_db <> CURRENT_DATABASE()
      OR v_ack <> 'ISOLATED_PREFIX_FIXTURES_ONLY'
      OR CURRENT_TRANSACTION() IS NOT NULL) THEN RAISE v_guard; END IF;
  LET v_marker VARCHAR := v_db || '.STANDARDIZE_AUDIT.' || v_prefix || 'ENVIRONMENT';
  SELECT COUNT(*) INTO :v_n FROM IDENTIFIER(:v_marker) WHERE PACKAGE_VERSION = 'M0-SQL-ONLY-2' AND DATABASE_NAME = :v_db AND OBJECT_PREFIX = :v_prefix AND ACCOUNT_NAME = :v_account;
  IF (v_n <> 1) THEN RAISE v_guard; END IF;
  v_sql := REPLACE(REPLACE('DECLARE
  v_run VARCHAR := $Q_SERIAL_RUN_ID;
  v_a VARIANT; v_b VARIANT;
  v_kind VARCHAR; v_initial NUMBER; v_final NUMBER;
  v_ok BOOLEAN := FALSE; v_n NUMBER;
  v_bad EXCEPTION (-20994,''Unknown pair or workers unfinished; save evidence before preparing another pair'');
BEGIN
  SELECT COUNT(*) INTO :v_n FROM @DB@.STANDARDIZE_AUDIT.@P@SERIAL_PAIR WHERE RUN_ID=:v_run;
  IF (v_n<>1) THEN RAISE v_bad; END IF;
  SELECT COUNT(*) INTO :v_n FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT
    WHERE RUN_ID=:v_run AND TEST_ID IN (''SERIAL-A'',''SERIAL-B'') AND STATUS IN (''NOT_RUN'',''RUNNING'');
  IF (v_n<>0) THEN RAISE v_bad; END IF;
  SELECT PAIR_KIND,INITIAL_VALUE INTO :v_kind,:v_initial FROM @DB@.STANDARDIZE_AUDIT.@P@SERIAL_PAIR WHERE RUN_ID=:v_run;
  SELECT COUNT(*) INTO :v_n FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=:v_run AND TEST_ID=''SERIAL-''||:v_kind;
  IF (v_n<>0) THEN RAISE v_bad; END IF;
  SELECT ACTUAL INTO :v_a FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=:v_run AND TEST_ID=''SERIAL-A'';
  SELECT ACTUAL INTO :v_b FROM @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT WHERE RUN_ID=:v_run AND TEST_ID=''SERIAL-B'';
  SELECT VALUE INTO :v_final FROM @DB@.STANDARDIZE_CORE.@P@PROTOTYPE_BUSINESS WHERE ID=1;
  -- releaseStartedAt is captured immediately before COMMIT/ROLLBACK. The timestamp
  -- after release can race with B acquiring; do not assert the wrong timestamp order.
  v_ok := COALESCE(
    v_a:prototypeEvidence:sessionId::NUMBER<>v_b:prototypeEvidence:sessionId::NUMBER
    AND v_b:prototypeEvidence:requestedAt::TIMESTAMP_LTZ>=v_a:prototypeEvidence:gateAcquiredAt::TIMESTAMP_LTZ
    AND v_b:prototypeEvidence:requestedAt::TIMESTAMP_LTZ<v_a:prototypeEvidence:releaseStartedAt::TIMESTAMP_LTZ
    AND v_b:prototypeEvidence:gateAcquiredAt::TIMESTAMP_LTZ>=v_a:prototypeEvidence:releaseStartedAt::TIMESTAMP_LTZ
    AND v_a:prototypeEvidence:observedValue::NUMBER=v_initial
    AND v_b:prototypeEvidence:observedValue::NUMBER=v_initial+IFF(v_kind=''COMMIT'',1,0)
    AND v_final=v_initial+IFF(v_kind=''COMMIT'',2,1)
    AND v_b:status::VARCHAR=''SUCCESS'' AND v_b:persistence::VARCHAR=''COMMITTED''
    AND ((v_kind=''COMMIT'' AND v_a:status::VARCHAR=''SUCCESS'' AND v_a:persistence::VARCHAR=''COMMITTED'')
      OR (v_kind=''ROLLBACK'' AND v_a:status::VARCHAR=''ERROR'' AND v_a:error:sqlcode::NUMBER=-20972 AND v_a:persistence::VARCHAR=''ROLLED_BACK'')
      OR (v_kind=''PREVIEW'' AND v_a:status::VARCHAR=''SUCCESS'' AND v_a:persistence::VARCHAR=''NOT_ATTEMPTED'')),FALSE);
  INSERT INTO @DB@.STANDARDIZE_AUDIT.@P@TEST_RESULT
    (RUN_ID,TEST_ID,DISPOSITION,STATUS,STARTED_AT,FINISHED_AT,PHASE,ACTUAL,ASSERTION_PASS)
    SELECT :v_run,''SERIAL-''||:v_kind,''REQUIRED'',IFF(:v_ok,''PASS'',''FAIL''),CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),''ASSERT'',
      OBJECT_CONSTRUCT_KEEP_NULL(''a'',:v_a,''b'',:v_b,''initialValue'',:v_initial,''finalValue'',:v_final),:v_ok;
  UPDATE @DB@.STANDARDIZE_AUDIT.@P@TEST_RUN SET FINISHED_AT=CURRENT_TIMESTAMP(),RUN_STATUS=IFF(:v_ok,''PASS'',''FAIL'') WHERE RUN_ID=:v_run;
  RETURN OBJECT_CONSTRUCT(''runId'',v_run,''checkId'',''SERIAL-''||v_kind,''status'',IFF(v_ok,''PASS'',''FAIL''));
END;
', '@DB@', v_db), '@P@', v_prefix);
  v_rows := (EXECUTE IMMEDIATE :v_sql);
  RETURN TABLE(v_rows);
END;
$$;
