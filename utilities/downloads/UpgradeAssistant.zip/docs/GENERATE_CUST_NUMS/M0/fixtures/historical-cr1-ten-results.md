# Historical CR1 results - unchanged excerpt

Not production results; not rerun. Original reviewed snapshot: f935962f00bda9975225324224565c9ae7b858db7f53b8a16136ee29e71d47f4.

| Case | Modeled outcome |
| --- | --- |
| Literal `NON_ACTIVE` with external 42 | External 42 remains assignable. |
| External 42 exists only as a core individual ID (out-of-contract/legacy row) | Completeness raises `-20007`; not reachable with conforming real assignments and reservations. |
| Merged reservation 42 overlaps new real individual 42 (invalid real ID) | Stage duplicate-ID error `-20013`. |
| Non-active reservation 42 overlaps new real individual 42 (invalid real ID) | Stage duplicate-ID error `-20013`. |
| Out-of-contract real individual 42 arrives after `(42,42)` reservation | No new assignment row is planned. |
| Two individuals prefer 101; loser has 102 | Loser gets a generated number and 102 is reserved. |
| Null individual with existing core individual 0 | Proposal is rejected by the sentinel comparison without a failure assertion. |
| Null date versus known date | Null-date candidate wins under default null ordering. |
| Empty generated range | First generated number is 500000001. |
| Seed 599999999 with one generated assignment needed | Exhaustion error `-20008`. |
