# M0 runbook

## Run locally now

From the workspace root, with Python 3.10+:

```powershell
python docs/GENERATE_CUST_NUMS/M0/scripts/validate_local.py --output docs/GENERATE_CUST_NUMS/M0/evidence/recheck-01.json
python docs/GENERATE_CUST_NUMS/M0/scripts/qualify.py render --config docs/GENERATE_CUST_NUMS/M0/fixtures/environment.example.json --allow-example --script 11_candidate_wrapper.sql --check-id M0-CANDIDATE-COMPILE --output docs/GENERATE_CUST_NUMS/M0/evidence/prepared-example-01
```

Both commands are local. Use a new output path on each attempt; existing evidence is never overwritten. Local validation does not import the Snowflake connector. Do not rerun the initial capture: it intentionally refuses to replace the original evidence. Fixture/registry authoring scripts are reproducibility aids, not test runners; changes after package sealing require a new reviewed manifest/version.

For later read-only metadata preparation (replace these illustrative values with actual names/time bounds):

```powershell
python docs/GENERATE_CUST_NUMS/M0/scripts/prepare_metadata.py --deployed-database ACTUAL_DEPLOYED_DB --owner-role ACTUAL_OWNER --caller-role ACTUAL_CALLER --history-start 2026-09-19T00:00:00-05:00 --history-end 2026-10-20T00:00:00-05:00 --output docs/GENERATE_CUST_NUMS/M0/evidence/local-attempts/metadata-prepared-01.sql
```

This only writes SQL. No current authorization covers executing even the read-only metadata queries. An authorized operator should later execute statements individually, retain output/denials/query IDs, and expand GET_DDL/SHOW GRANTS for discovered objects. A missing zero-argument overload is an inventory fact, not permission to create it.

## Prepare a later isolated run

Separate execution authorization and the exact inputs in [INVENTORY.md](INVENTORY.md) are prerequisites. An operator provisions **new empty databases** with names beginning `M0_CUST_NUM_`, and the three STANDARDIZE schemas. Use independent baseline and candidate databases plus an empty decoy. No CREATE DATABASE/SCHEMA is hidden in the runner; no production clone/data copy is included. Use dedicated profiles and roles with no production object access. The runner checks exact account locator, current database, role, warehouse, absence of an open transaction, AUTOCOMMIT=TRUE and LOCK_TIMEOUT=60 before executing package statements. It does not change these entry settings.

Copy [environment.example.json](fixtures/environment.example.json) to a private operator config per environment/role; fill every REPLACE value. `connection_name` identifies an already configured Python Snowflake Connector profile; do not store passwords/tokens in the package. Authentication installation/configuration is not performed here. Record connector/client versions with the run. The runner requires the optional `snowflake-connector-python` only for its explicit `execute` command. The [official Python Connector API](https://docs.snowflake.com/en/developer-guide/python-connector/python-connector-api) describes connections, cursors and query IDs.

The examples below are for a future authorized run, not commands executed during package creation:

```powershell
python docs/GENERATE_CUST_NUMS/M0/scripts/qualify.py execute --execute-isolated --config C:/M0-config/candidate-owner.json --script 00_setup.sql --check-id M0-ENV --output docs/GENERATE_CUST_NUMS/M0/evidence/runs/setup-01
```

`00_setup.sql` refuses a nonempty database and creates permanent synthetic fixture tables plus a package marker. It is not idempotent production deployment. If setup fails midway, retain the failure and provision a new empty sandbox; do not erase evidence or bypass the emptiness check. The setup creates only the columns needed for synthetic probes, not a full source/audit deployment. Every later script requires the unique marker. The SQL guard is prepended to each rendered script; clients must stop on the first failure. Prefer the supplied runner, which executes explicit statement boundaries and stops on errors.

Repeat the execute command with a new output directory and each required script:

| Database | Order / scripts | Result to inspect |
| --- | --- | --- |
| Baseline only | `00_setup.sql`, `baseline.normalized.sql`, then `baseline_pb01.sql` through `baseline_pb20.sql` individually | Compilation first; each fixture resets only sandbox source/CORE, calls the zero-arg live baseline, and selects output. Retain expected errors and inspect objects afterward. |
| Candidate only | `00_setup.sql`, `10_audit_helper.sql`, `11_candidate_wrapper.sql`, `12_scenarios.sql` | Wrapper/helper compilation, one control row, stale work seeds, unique synthetic feed scenarios. |
| Candidate only | `case_live.sql`, `case_preview.sql`, `case_zero_work.sql`, negative entry and fault cases | Exact return/error, marker delta, log identity/persistence, stage contents and gate state. |
| Either isolated sandbox | `30_relational_edge_probes.sql` | Counts for NULL/OR-MERGE and unique blocked join. |

The candidate's three explicit inputs match D06 types and have no defaults. Prototype business state is an integer marker; it is not a customer number/seed. Metrics follow the compact JSON keys but allocation counts remain null and allocator validation NOT_RUN. A prototype SUCCESS is not target allocation success. Future M1–M4 must implement all applicable checks before using the real SUCCESS contract.

Use `20_inspect.sql` in a new retained attempt before/after each case. This collects control, all work, synthetic business/caller work, full process log, baseline XREF and available query history. Inspection after a failure is a separate command; the runner does not execute later statements after the failing CALL. Child-query history/observer permissions may differ under owner rights; retain denied observations rather than claiming proof.

## Two-session schedule

Run A and B from separate processes/profiles pointing at the **same candidate sandbox**; do not share a connector connection. Use an observer session to see durable log rows and query history. The scenario scripts are preseeded; do not change scenario/control/work fixtures while either run holds the gate.

| Check | A | B | Required observation |
| --- | --- | --- | --- |
| Commit overlap | `case_overlap_a_commit.sql` (feed 1101, 30-second hold) | `case_overlap_b_commit.sql` (1102) | Start B after observer sees A's IN_PROGRESS. B UPDATE blocks until A commit; its business marker must advance from A's committed value. |
| Rollback overlap | `case_overlap_a_rollback.sql` (1103, 30s) | `case_overlap_b_rollback.sql` (1104) | A raises -20972 before apply; B advances from the pre-A marker after release. |
| Preview/live | `case_preview_overlap_a.sql` (1107, 30s) | `case_preview_overlap_b.sql` (1108) | Confirm A held at SYSTEM$WAIT via child-query history; B cannot truncate/prepare until preview rollback. Preview intentionally has no IN_PROGRESS business state. |
| Timeout live | `case_timeout_a.sql` (1105, 80s) | `case_timeout_b.sql` (1106) | Begin B promptly once A's IN_PROGRESS is visible (within 10s); B times out after about 60s blocked; no B preparation/truncate. |
| Timeout preview | `case_timeout_preview_a.sql` (1109, 80s) | `case_timeout_preview_b.sql` (1110) | Same timeout expectation for B preview. |

If observer startup takes too long, the schedule is invalid: retain it as inconclusive and seed fresh feeds/scenarios for a new reviewed attempt. Do not claim timeout qualification from wall-clock call duration alone: record lock UPDATE query ID, blocked-time measurement, A release time and B error. The 60-second parameter applies to each resource lock attempt; this prototype's gate UPDATE is the relevant statement. See [LOCK_TIMEOUT](https://docs.snowflake.com/en/sql-reference/parameters#lock-timeout). A returning before the limit is separately exercised by the 30-second overlap cases.

Independent audit persistence is demonstrated only if an observer sees IN_PROGRESS **while B is still blocked at the gate**, and the row survives a later A rollback. TRUNCATE must not release the gate. D07 helper uses its own explicit scoped transaction and accesses only the log; the coordinator never writes that table directly. Retain actual query/transaction evidence, not just procedure source inspection. [Snowflake scoped transactions](https://docs.snowflake.com/en/sql-reference/transactions#scoped-transactions).

## Failures, cleanup and entry behavior

Run each fault scenario once per seeded feed. A repeat of the same feed is deliberately rejected by the audit helper; retries require new externally supplied feed/GUID values and a new scenario row. Keep earlier rows intact. For independent runs, use a fresh sandbox or append explicitly reviewed synthetic scenario rows and rehash the altered input.

| Case | Expected evidence |
| --- | --- |
| `case_initial_log_failure.sql` | -20981, no gate/business change; no initialized log row. |
| `case_in_progress_failure.sql` | -20981, no business apply; prior durable initial log survives. |
| `case_truncate_failure.sql` | -20972; seeded stale work returns after rollback. |
| `case_apply_failure.sql` / `case_cleanup_failure.sql` | -20972; marker unchanged after rollback; known audit persistence ROLLED_BACK; stale work restored. |
| `case_secondary_log_failure.sql` | Original -20972, not secondary -20981; surviving IN_PROGRESS remains unresolved until evidence establishes rollback. |
| `case_rollback_handler_failure.sql` | Deliberate secondary fault occurs before ROLLBACK; preserve primary -20972. Capture any platform implicit rollback/scope error. This tests handler failure, not a real network/rollback failure. M0-PRIMARY-ERROR remains unqualified if original error is replaced. |
| `case_post_commit_log_failure.sql` | -20981 reaches caller while marker stays committed; catch-path audit records COMMITTED/FAIL if available. Never rerun under assumption of rollback. |
| `case_missing_control.sql` / `case_duplicate_control.sql` | -20971 before truncate/prepare. Use `21_restore_control_fixture.sql` between cases only when all other sessions are idle. This is sandbox fixture repair, not production deployment. |

Use `22_seed_stale_work.sql` before dedicated rollback/preview tests, with no active invocation. Capture exact before/after rows from all work tables (M0 has one). Startup TRUNCATE removes all runs only after the gate; final DELETE uses RUN_ID. Live success leaves no work rows; preview/failure restores stale rows. Source, business/CORE, control, scenario configuration and audit log are never truncate targets. Query history and full snapshots prove the order and retention, not a final empty-table check alone.

`case_caller_transaction.sql` begins a caller transaction and inserts caller-owned work before the CALL. The runner captures CURRENT_TRANSACTION on failure before closing its connection; compare it to the SELECT before CALL. For full caller ownership evidence, use an interactive session to execute the same statements with the rendered environment guard, then, **after the expected error**, SELECT CURRENT_TRANSACTION and M0_CALLER_WORK without closing the session. An observer must not see that uncommitted work. Explicitly roll back in the caller afterward and verify disappearance. No procedure may commit/roll back it. Repeat with `case_caller_transaction_preview.sql` (distinct feed 1208). Entry CURRENT_TRANSACTION behavior under owner rights must be verified, not assumed.

`23_owner_session_probe.sql` is expected to demonstrate that SHOW PARAMETERS IN SESSION is unavailable under owner rights. The supported runner performs those checks outside that scope; `case_autocommit_false_direct.sql` deliberately changes its isolated session to FALSE after runner preflight, then probes direct entry. **If it reaches the gate, that is a known enforcement gap, not a passing test.** The wrapper currently cannot independently verify that session setting or LOCK_TIMEOUT. `case_lock_timeout_direct.sql` sets LOCK_TIMEOUT=1 after preflight; run it while A holds the gate to expose the same bypass risk. Do not substitute guessed system functions, change owner rights or silently alter caller settings. This dependency must be resolved before accepting the real entry design. [Owner-rights restrictions](https://docs.snowflake.com/en/developer-guide/stored-procedure/stored-procedures-rights).

With separate grant authorization in the sandbox, run `25_grants_isolated.sql`, then `case_non_owner.sql` using a config with the non-owner role/profile. Verify no inherited source/business/work privileges and that an unauthorized role cannot invoke. For database resolution, `case_other_database.sql` changes caller context to the precreated decoy and uses a fully qualified candidate call; inspect both databases. The procedure/helper retain two-part body names. No hard-coded production database routing is introduced.

Run `24_overload_demonstration.sql` to show new signature creation leaves a zero-argument **harmless stub** callable, then drops that exact stub. `case_retired_stub.sql` must fail after retirement; `case_legacy_absent.sql` must fail because the candidate has no zero-argument overload. This does not retire any deployed allocator. At actual cutover, repeat the inventory/denial checks for every real entry name and grant path.

## Capture and review every attempt

The runner retains exact rendered SQL, template/render hashes, non-secret config, account/session/version/parameters, statement SQL/query IDs/results/elapsed time, and original error code/state/message. Expected-error runs exit nonzero; keep them. `attempt.json` records execution separately from validation; even a fully executed script leaves validation NOT_RUN until reviewed. Do not use native exit zero as qualification PASS.

For each check, add a new reviewer record with check ID, exact package/candidate/fixture hashes, environment, session IDs, raw attempt paths, expected/actual comparison, PASS/FAIL/NOT_RUN (or separately explained inconclusive schedule), reviewer/date, and unresolved issues. Capture unavailable diagnostics and secondary errors too. Real connection-loss/commit-uncertainty tests need an approved fault method and observer reconciliation; the simulated handler case does not establish them. Never blindly retry an IN_PROGRESS/UNKNOWN/known-COMMITTED attempt.

All current evidence is local. Finish M0 only after required compilation, transaction/caller/rights/metadata gates have actual reviewed Snowflake evidence and design gaps are resolved. M1 implementation, migration, grant cutover and production execution require their own authorization.
