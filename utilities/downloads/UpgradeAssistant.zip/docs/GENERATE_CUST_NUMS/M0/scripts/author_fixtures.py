"""Author deterministic expected fixtures locally BEFORE any database testing.
This is data authoring, not a production/target allocator or Snowflake simulator.
"""
from pathlib import Path
import json
M0=Path(__file__).resolve().parents[1]
F=M0/'fixtures'
I7,I8=100000000007,100000000008
NEW,OLD='2026-10-02 00:00:00','2026-10-01 00:00:00'
def pp(i,num,status='ACTIVE',date=NEW,sor='ICON',key='10',feed=701):
    return [key,i,num,status,date,sor,feed]
def core(i,num,reason='new_external_cust_num',feed=690): return [i,num,reason,OLD,feed]
def mapping(i,num,reason='new_external_cust_num',feed=701): return [i,num,reason,feed]
def result(rows=None,error=None,reservations=None,note=''):
    return {'newAssignments':rows or [],'error':error,'newReservations':reservations or [],'note':note}
def reserve(num,reason,key='10',source_feed=701):
    return {'custNum':num,'recType':reason,'createDate':'CURRENT_INVOCATION_TIME','createFeedInstanceId':900001,
            'originatingFeedInstanceId':source_feed,'sourcePartyProfileId':key}
cases=[]
def case(id,description,profiles,existing,baseline,target,runnable=True):
    cases.append({'id':id,'description':description,'runnableBaseline':runnable,'profiles':profiles,'core':existing,
      'productionBaseline':baseline,'approvedTarget':target,'status':'NOT_RUN'})
case('PB01','Exact NON_ACTIVE is a new target block',[pp(I7,'42','NON_ACTIVE')],[],
     result([mapping(I7,42)]),result([mapping(I7,500000001,'new_cdp_cust_num')],reservations=[reserve(42,'nonactive_external_cust_num')]))
case('PB02','Global leading-zero block across ICON and MAO',[pp(I7,'00042','NON_ACTIVE'),pp(I8,'42',sor='MAO',key='2',feed=702)],[],
     result([mapping(I7,42),mapping(I8,500000001,'new_cdp_cust_num',702)]),
     result([mapping(I7,500000001,'new_cdp_cust_num'),mapping(I8,500000002,'new_cdp_cust_num',702)],reservations=[reserve(42,'nonactive_external_cust_num')]))
case('PB03','Preserve original no fallback: loser has 102',
     [pp(I7,'101'),pp(I8,'101'),pp(I8,'102',date=OLD,key='2',feed=702)],[],
     result([mapping(I7,101),mapping(I8,500000001,'new_cdp_cust_num',702)],reservations=[[102,102,'merged_external_cust_num',702]]),
     result([mapping(I7,101),mapping(I8,500000001,'new_cdp_cust_num',702)],reservations=[reserve(102,'merged_external_cust_num','2',702)]))
case('PB04','No rebalancing: lower ID owns losing alternative',
     [pp(I7,'101'),pp(I7,'102',date=OLD,key='2'),pp(I8,'102')],[],
     result([mapping(I7,101),mapping(I8,500000001,'new_cdp_cust_num')],reservations=[[102,102,'merged_external_cust_num',701]]),
     result([mapping(I7,101),mapping(I8,500000001,'new_cdp_cust_num')],reservations=[reserve(102,'merged_external_cust_num','2')]))
case('PB05','Mapped individual carries newly unused external 77',[pp(I7,'77')],[core(I7,42)],
     result(note='Existing assignment unchanged; 77 not reserved'),
     result(reservations=[reserve(77,'unused_external_cust_num')],note='Existing assignment unchanged; fresh reservation, not migrated history'))
case('PB06','Current NON_ACTIVE must not revoke existing assignment',[pp(I7,'42','NON_ACTIVE')],[core(I7,42)],
     result(),result(note='Preserve all existing assignment fields; no overlapping reservation'))
case('PB07','Empty generated history; non-ICON discovery',[pp(I7,None,sor='OTHER')],[],
     result([mapping(I7,500000001,'new_cdp_cust_num')]),result([mapping(I7,500000001,'new_cdp_cust_num')]))
case('PB08','Generated exhaustion',[pp(I8,None,sor='OTHER')],[core(I7,599999999,'new_cdp_cust_num')],
     result(error='-20005',note='Range check after staging, not -20008; no CORE insert, permanent work/debug can persist'),
     result(error='GENERATED_CAPACITY',note='Fail before apply; no numeric target error code assigned in M0'))
case('PB09','Invalid CORE ID occupies only external key',[pp(I7,'42')],[core(42,500000001,'new_cdp_cust_num')],
     result([mapping(I7,500000002,'new_cdp_cust_num')],note='42 unavailable by either-key occupancy; no completeness -20007'),
     result(error='CORE_INTEGRITY'))
case('PB10','Invalid real ID collides with merged reservation',[pp(I7,'11'),pp(I7,'42',date=OLD),pp(42,None,sor='OTHER')],[],
     result(error='-20013'),result(error='SOURCE_ID_VALIDITY'))
case('PB11','Legacy reservation masks invalid individual 42',[pp(42,None,sor='OTHER')],[core(42,42,'merged_external_cust_num')],
     result(note='No new assignment'),result(error='SOURCE_ID_VALIDITY',note='Reservation itself requires separate historical lineage migration checks'))
case('PB12','NULL source with CORE zero differs from historical reference',[pp(None,None,sor='OTHER')],[core(0,600000001)],
     result(note='NOT IN UNKNOWN removes source before generated planning; no OR-MERGE proposal exists'),
     result(error='CORE_INTEGRITY or SOURCE_ID_VALIDITY',note='Both violations must stop before planning; first failing check ordering is not fixed'))
case('PB13','NULL source with empty CORE',[pp(None,None,sor='OTHER')],[],
     result(error='NOT_NULL_CONSTRAINT',note='NOT IN empty relation admits NULL; staged NULL generated ID then fails supplied CORE constraint; capture actual SQL code'),
     result(error='SOURCE_ID_VALIDITY'))
case('PB14','Known date vs NULL under default owner-account null ordering',[pp(I7,'101',date=None),pp(I7,'102',date=NEW,key='2')],[],
     result([mapping(I7,101)],reservations=[[102,102,'merged_external_cust_num',701]],note='Conditional on effective DEFAULT_NULL_ORDERING=LAST; reverse expected 101/102 under FIRST'),
     result([mapping(I7,102)],reservations=[reserve(101,'merged_external_cust_num')],note='Known date wins under either session default'))
case('PB15','Fractional PK1 rounds under production cast',[pp(I7,'42.4')],[],
     result([mapping(I7,42)],note='Target account TRY_CAST rounding must be observed'),
     result([mapping(I7,500000001,'new_cdp_cust_num')],note='Invalid PK1; no reservation for rounded 42'))
case('PB16','Valid legacy reservation coexists with valid real ID',[pp(100000000042,'42')],[core(42,42,'merged_external_cust_num')],
     result([mapping(100000000042,500000001,'new_cdp_cust_num')]),
     result([mapping(100000000042,500000001,'new_cdp_cust_num')],note='Run after verified migration of 42; no new reservation counted; missing lineage blocks migration first'))
case('PB17','Generated gap not reclaimed',[pp(I8,None,sor='OTHER')],[core(I7,500000010,'new_cdp_cust_num')],
     result([mapping(I8,500000011,'new_cdp_cust_num')]),result([mapping(I8,500000011,'new_cdp_cust_num')]))
case('PB18','Duplicate source selected mapping; assignment feed remains individual maximum',
     [pp(I7,'42',key='10',feed=701),pp(I7,'42',key='2',feed=799)],[],
     result([mapping(I7,42,feed=799)],note='One mapping, not duplicate outputs'),
     result([mapping(I7,42,feed=799)],note='Reservation-specific lineage correction does not change genuine assignment attribution'))
case('PB19','Blocked reservation source string order and same-row feed',
     [pp(I7,'42','NON_ACTIVE',key='10',feed=701),pp(I7,'42','NON_ACTIVE',key='2',feed=799)],[],
     result([mapping(I7,42,feed=799)]),
     result([mapping(I7,500000001,'new_cdp_cust_num',799)],reservations=[reserve(42,'nonactive_external_cust_num','10',701)]))
case('PB20','Existing genuine invalid lower generated boundary is not repaired',[],[core(I7,500000000,'new_cdp_cust_num')],
     result(note='Production does not range-check retained genuine assignments'),
     result(error='CORE_INTEGRITY',note='No repair/revocation; reject invocation'))
payload={'authority':'Production .prod.sql and settled implementation-plan D01-D08 / REPORTING.md',
 'expectationsAuthoredBeforeDatabaseTests':True,'snowflakeExecution':'NOT_RUN',
 'profileColumns':['SOURCE_PARTY_PROFILE_ID','INDIVIDUAL_ID','SOURCE_SYSTEM_PK_1','PARTY_PROFILE_STATUS_CODE','SOURCE_REC_CREATE_DATETIME','SOR_NAME','UPDATE_FEED_INSTANCE_ID'],
 'coreColumns':['INDIVIDUAL_ID','CUST_NUM','REC_TYPE','CREATE_DATE','CREATE_FEED_INSTANCE_ID'],
 'assignmentColumns':['INDIVIDUAL_ID','CUST_NUM','REC_TYPE','CREATE_FEED_INSTANCE_ID'],
 'targetInvocationFeed':900001,'targetExecutionPrerequisite':'M1-M4 allocator and reconciled reservation baseline; M0 wrapper is NOT this implementation',
 'cases':cases}
(F/'behavior-cases.json').write_text(json.dumps(payload,indent=2)+'\n',encoding='utf-8')
status=[None,'',' ','-','ACTIVE','non_active','Non_Active',' NON_ACTIVE','NON_ACTIVE ','anything','NON_ACTIVE']
(F/'status-and-pk1.json').write_text(json.dumps({
 'statusTruthTable':[{'raw':s,'blocked':s=='NON_ACTIVE'} for s in status],
 'pk1ValidSyntax':['42','00042',' 42 ','\t42\n','0','1','499999999','500000000','599999999','600000000','999999999','1000000000'],
 'pk1InvalidSyntax':['+42','-42','42.4','42.6','4.2e1','4 2','',None],
 'conversionOverflow':'9'*39,
 'externalRange':[1,499999999,600000000,999999999],
 'notExternalRange':[0,500000000,599999999,1000000000],
 'validIndividualEndpoints':[100000000000,199999999999],
 'invalidIndividuals':[None,0,99999999999,200000000000,100000000000.5],
 'qualification':'Whitespace, collation, conversion, and pre-conversion fractional source handling require Snowflake evidence; stored NUMBER(38,0) cannot expose prior rounding.'},indent=2)+'\n',encoding='utf-8')
(F/'reservation-lineage.json').write_text(json.dumps({'syntheticOnly':True,'status':'NOT_RUN','cases':[
 {'id':'RL01','legacy':[42,42,'merged_external_cust_num','2024-01-02 03:04:05',799],
  'verifiedEvidence':{'historicalGenerationFeed':6001,'selectedSourceId':'10','selectedSourceFeed':701,'writer':'supplied-production-family'},
  'expectedReservation':[42,'merged_external_cust_num','2024-01-02 03:04:05',6001,701,'10'],
  'expected':'Migration preserves verified creation date; 799 cannot be assumed invocation or winning source feed'},
 {'id':'RL02','legacyReason':'merged_external_cust_num','verifiedEvidence':None,'expected':'BLOCK_MIGRATION; do not substitute migration feed/time or current profile for missing history'},
 {'id':'RL03','legacyReason':'nonactive_external_cust_num','verifiedEvidence':'historical writer unresolved','expected':'BLOCK_MIGRATION; not produced by supplied baseline'},
 {'id':'RL04','legacyReason':'unused_external_cust_num','verifiedEvidence':'ambiguous historical invocation','expected':'BLOCK_MIGRATION; preserve evidence and require separate resolution'},
 {'id':'RL05','legacyReason':None,'equalKeys':[42,42],'expected':'CORE_INTEGRITY; shape alone is insufficient'},
 {'id':'RL06','newBlocked':43,'newUnusedOnMappedIndividual':44,'expected':'NEW target invocation reservations; not migrated, not backdated'},
 {'id':'RL07','existingReservation':[42,'merged_external_cust_num','2024-01-02 03:04:05',6001,701,'10'],
  'laterEvidence':'NON_ACTIVE / different source feed / deleted source','expected':'All six existing fields immutable; no new row; new reservationCount excludes 42'},
 {'id':'RL08','supportingSourceIds':['2','10',None],'expected':'Choose 10 and its own feed; if all missing, fail required lineage before apply'},
 {'id':'RL09','genuineAssignment':[100000000042,42,'new_external_cust_num','2024-01-02 03:04:05',701],
  'newStatus':'NON_ACTIVE','expected':'Preserve assignment exactly; exclude 42 from new reservations'}]},indent=2)+'\n',encoding='utf-8')
print('Authored 20 production/target oracle cases and lineage/status fixtures; no test execution.')
