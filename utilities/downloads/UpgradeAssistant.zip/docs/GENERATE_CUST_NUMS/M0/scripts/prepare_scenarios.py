"""LOCAL generation of isolated SQL cases; never connects to Snowflake."""
from pathlib import Path
import json

M0=Path(__file__).resolve().parents[1]
SQL=M0/'scripts/sql'
SEP='\n-- M0_STATEMENT\n'

def put(name, statements):
    (SQL/name).write_text(SEP.join(statements)+'\n',encoding='utf-8',newline='\n')

def call(feed, preview=False):
    # Exactly 36 characters; opaque fixture identifiers, no UUID validation.
    guid=f'M0-FIXTURE-{feed:025d}'
    return f"CALL STANDARDIZE_STAGE.GENERATE_CUST_NUMS_M0({feed},'{guid}',{str(preview).upper()});"

def main():
    cases=[(1001,'live',0,'NONE',False,False,False,False),
      (1002,'preview',0,'NONE',False,False,False,True),
      (1003,'zero_work',0,'NONE',False,False,True,False),
      (1004,'initial_log_failure',0,'INITIAL_LOG',False,False,False,False),
      (1005,'in_progress_failure',0,'IN_PROGRESS_LOG',False,False,False,False),
      (1006,'truncate_failure',0,'AFTER_TRUNCATE',False,False,False,False),
      (1007,'apply_failure',0,'AFTER_APPLY',False,False,False,False),
      (1008,'cleanup_failure',0,'CLEANUP',False,False,False,False),
      (1009,'secondary_log_failure',0,'AFTER_APPLY',True,False,False,False),
      (1010,'rollback_handler_failure',0,'AFTER_APPLY',True,True,False,False),
      (1011,'post_commit_log_failure',0,'FINAL_LOG',False,False,False,False),
      (1101,'overlap_a_commit',30,'NONE',False,False,False,False),
      (1102,'overlap_b_commit',0,'NONE',False,False,False,False),
      (1103,'overlap_a_rollback',30,'BEFORE_APPLY',False,False,False,False),
      (1104,'overlap_b_rollback',0,'NONE',False,False,False,False),
      (1105,'timeout_a',80,'NONE',False,False,False,False),
      (1106,'timeout_b',0,'NONE',False,False,False,False),
      (1107,'preview_overlap_a',30,'NONE',False,False,False,True),
      (1108,'preview_overlap_b',0,'NONE',False,False,False,False),
      (1109,'timeout_preview_a',80,'NONE',False,False,False,False),
      (1110,'timeout_preview_b',0,'NONE',False,False,False,True),
      (1201,'missing_control',0,'NONE',False,False,False,False),
      (1202,'duplicate_control',0,'NONE',False,False,False,True),
      (1203,'caller_transaction',0,'NONE',False,False,False,False),
      (1204,'autocommit_false_direct',0,'NONE',False,False,False,True),
      (1205,'other_database',0,'NONE',False,False,False,True),
      (1206,'non_owner',0,'NONE',False,False,False,True),
      (1207,'lock_timeout_direct',0,'NONE',False,False,False,True),
      (1208,'caller_transaction_preview',0,'NONE',False,False,False,True)]
    rows=[]
    for feed,name,hold,fault,secondary,rollback,zero,preview in cases:
        rows.append(f"({feed},{hold},'{fault}',{str(secondary).upper()},{str(rollback).upper()},{str(zero).upper()})")
        statements=[call(feed,preview)]
        if name=='missing_control': statements.insert(0,"DELETE FROM STANDARDIZE_AUDIT.CUST_NUM_PROCESS WHERE PROCESS_NAME='GENERATE_CUST_NUMS';")
        if name=='duplicate_control': statements.insert(0,"INSERT INTO STANDARDIZE_AUDIT.CUST_NUM_PROCESS VALUES ('GENERATE_CUST_NUMS',NULL,NULL);")
        if name.startswith('caller_transaction'): statements=["BEGIN TRANSACTION;",f"INSERT INTO STANDARDIZE_CORE.M0_CALLER_WORK VALUES ({feed});",'SELECT CURRENT_TRANSACTION();',*statements]
        if name=='autocommit_false_direct': statements.insert(0,'ALTER SESSION SET AUTOCOMMIT=FALSE;')
        if name=='lock_timeout_direct': statements.insert(0,'ALTER SESSION SET LOCK_TIMEOUT=1;')
        if name=='other_database': statements=["USE DATABASE {{DECOY_DATABASE}};","USE SCHEMA PUBLIC;",call(feed,preview).replace('STANDARDIZE_STAGE.','{{DATABASE}}.STANDARDIZE_STAGE.')]
        put(f'case_{name}.sql',statements)
    put('12_scenarios.sql',['INSERT INTO STANDARDIZE_STAGE.M0_SCENARIO VALUES\n'+',\n'.join(rows)+';'])
    put('20_inspect.sql',[
      'SELECT CURRENT_TRANSACTION(),CURRENT_ACCOUNT(),CURRENT_DATABASE(),CURRENT_ROLE(),CURRENT_SESSION();',
      'SELECT * FROM STANDARDIZE_AUDIT.CUST_NUM_PROCESS;',
      'SELECT * FROM STANDARDIZE_STAGE.M0_WORK ORDER BY RUN_ID;',
      'SELECT * FROM STANDARDIZE_CORE.M0_BUSINESS;',
      'SELECT * FROM STANDARDIZE_CORE.M0_CALLER_WORK;',
      'SELECT * FROM STANDARDIZE_AUDIT.CUST_NUM_PROCESS_LOG ORDER BY CUST_NUM_PROCESS_LOG_ID;',
      'SELECT * FROM STANDARDIZE_CORE.CUST_NUM_INDIVIDUAL_XREF ORDER BY INDIVIDUAL_ID,CUST_NUM;',
      "SELECT QUERY_ID,QUERY_TEXT,EXECUTION_STATUS,ERROR_CODE,ERROR_MESSAGE,START_TIME,END_TIME,TRANSACTION_BLOCKED_TIME FROM TABLE(INFORMATION_SCHEMA.QUERY_HISTORY(RESULT_LIMIT=>1000)) ORDER BY START_TIME;"
    ])
    put('21_restore_control_fixture.sql',[
      '-- Isolated fixture repair ONLY; ensure no active M0 sessions first. Not a deployment seed migration.\nDELETE FROM STANDARDIZE_AUDIT.CUST_NUM_PROCESS;',
      "INSERT INTO STANDARDIZE_AUDIT.CUST_NUM_PROCESS VALUES ('GENERATE_CUST_NUMS',NULL,NULL);"
    ])
    put('22_seed_stale_work.sql',["INSERT INTO STANDARDIZE_STAGE.M0_WORK VALUES (-11,911),(-12,912);"])
    put('case_missing_mode.sql',["CALL STANDARDIZE_STAGE.GENERATE_CUST_NUMS_M0(1301,'M0-FIXTURE-0000000000000000000001301');"])
    put('case_null_mode.sql',["CALL STANDARDIZE_STAGE.GENERATE_CUST_NUMS_M0(1302,'M0-FIXTURE-0000000000000000000001302',NULL);"])
    put('case_missing_feed.sql',["CALL STANDARDIZE_STAGE.GENERATE_CUST_NUMS_M0(NULL,'M0-FIXTURE-0000000000000000000001303',TRUE);"])
    put('case_missing_guid.sql',["CALL STANDARDIZE_STAGE.GENERATE_CUST_NUMS_M0(1304,NULL,TRUE);"])
    put('case_legacy_absent.sql',["CALL STANDARDIZE_STAGE.GENERATE_CUST_NUMS_M0();"])
    put('23_owner_session_probe.sql',[
      """CREATE PROCEDURE STANDARDIZE_STAGE.M0_OWNER_SESSION_PROBE() RETURNS VARCHAR LANGUAGE SQL EXECUTE AS OWNER AS $$
BEGIN
  SHOW PARAMETERS IN SESSION;
  RETURN 'UNEXPECTEDLY_SUPPORTED_REVIEW_PLATFORM_BEHAVIOR';
END;
$$;""",'CALL STANDARDIZE_STAGE.M0_OWNER_SESSION_PROBE();'])
    put('24_overload_demonstration.sql',[
      """-- Harmless legacy stub, NEVER the allocator. Demonstrate overload coexistence.
CREATE PROCEDURE STANDARDIZE_STAGE.M0_OVERLOAD_DEMO() RETURNS VARCHAR LANGUAGE SQL EXECUTE AS OWNER AS $$
BEGIN RETURN 'LEGACY_STUB_NO_ALLOCATION'; END;
$$;""",
      """CREATE OR REPLACE PROCEDURE STANDARDIZE_STAGE.M0_OVERLOAD_DEMO(P_FEED NUMBER,P_GUID VARCHAR(36),P_PREVIEW BOOLEAN)
RETURNS VARCHAR LANGUAGE SQL EXECUTE AS OWNER AS $$
BEGIN RETURN 'EXPLICIT_STUB_NO_ALLOCATION'; END;
$$;""",
      'CALL STANDARDIZE_STAGE.M0_OVERLOAD_DEMO();',
      'DROP PROCEDURE STANDARDIZE_STAGE.M0_OVERLOAD_DEMO();'])
    put('case_retired_stub.sql',['CALL STANDARDIZE_STAGE.M0_OVERLOAD_DEMO();'])
    put('25_grants_isolated.sql',[
      'GRANT USAGE ON DATABASE {{DATABASE}} TO ROLE {{CALLER_ROLE}};',
      'GRANT USAGE ON SCHEMA {{DATABASE}}.STANDARDIZE_STAGE TO ROLE {{CALLER_ROLE}};',
      'GRANT USAGE ON SCHEMA {{DATABASE}}.STANDARDIZE_AUDIT TO ROLE {{CALLER_ROLE}};',
      'GRANT USAGE ON WAREHOUSE {{WAREHOUSE}} TO ROLE {{CALLER_ROLE}};',
      'GRANT SELECT ON TABLE {{DATABASE}}.STANDARDIZE_AUDIT.M0_ENVIRONMENT TO ROLE {{CALLER_ROLE}};',
      'GRANT USAGE ON PROCEDURE {{DATABASE}}.STANDARDIZE_STAGE.GENERATE_CUST_NUMS_M0(NUMBER,VARCHAR,BOOLEAN) TO ROLE {{CALLER_ROLE}};',
      'SHOW GRANTS ON PROCEDURE {{DATABASE}}.STANDARDIZE_STAGE.GENERATE_CUST_NUMS_M0(NUMBER,VARCHAR,BOOLEAN);',
      'SHOW GRANTS TO ROLE {{CALLER_ROLE}};'])
    # Baseline input and oracle files are authored first; generate SQL without implementing a target allocator.
    path=M0/'fixtures/behavior-cases.json'
    if path.exists():
        for case in json.loads(path.read_text())['cases']:
            if not case.get('runnableBaseline'): continue
            statements=['DELETE FROM STANDARDIZE_CORE.PARTY_PROFILE;','DELETE FROM STANDARDIZE_CORE.CUST_NUM_INDIVIDUAL_XREF;']
            def literal(v):
                if v is None: return 'NULL'
                if isinstance(v,(int,float)): return str(v)
                return "'"+str(v).replace("'","''")+"'"
            for table,cols,rows in [('PARTY_PROFILE','SOURCE_PARTY_PROFILE_ID,INDIVIDUAL_ID,SOURCE_SYSTEM_PK_1,PARTY_PROFILE_STATUS_CODE,SOURCE_REC_CREATE_DATETIME,SOR_NAME,UPDATE_FEED_INSTANCE_ID',case['profiles']),
                                    ('CUST_NUM_INDIVIDUAL_XREF','INDIVIDUAL_ID,CUST_NUM,REC_TYPE,CREATE_DATE,CREATE_FEED_INSTANCE_ID',case['core'])]:
                if rows: statements.append(f'INSERT INTO STANDARDIZE_CORE.{table} ({cols}) VALUES\n'+',\n'.join('('+','.join(map(literal,r))+')' for r in rows)+';')
            statements.extend(['CALL STANDARDIZE_STAGE.GENERATE_CUST_NUMS();','SELECT INDIVIDUAL_ID,CUST_NUM,REC_TYPE,CREATE_FEED_INSTANCE_ID FROM STANDARDIZE_CORE.CUST_NUM_INDIVIDUAL_XREF ORDER BY INDIVIDUAL_ID,CUST_NUM;'])
            put('baseline_'+case['id'].lower()+'.sql',statements)
    print('Local scenario SQL generated; Snowflake NOT_RUN.')

if __name__=='__main__': main()
