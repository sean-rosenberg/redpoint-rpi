"""LOCAL artifact checks only. SQL is inspected as text, never compiled/executed.
Use --seal once after review to create an immutable package hash manifest.
"""
from pathlib import Path
import argparse
import ast
import datetime as dt
import difflib
import hashlib
import importlib.util
import json
import re
import sys
import urllib.parse

sys.dont_write_bytecode=True
M0=Path(__file__).resolve().parents[1]
ROOT=M0.parents[2]

def sha(data): return hashlib.sha256(data).hexdigest()
def read_json(path): return json.loads(path.read_text(encoding='utf-8'))
def module(name):
    spec=importlib.util.spec_from_file_location(name,M0/'scripts'/f'{name}.py')
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
def artifacts():
    ignored={'evidence/package-manifest.json','evidence/local-validation.json'}
    return {p.relative_to(M0).as_posix():sha(p.read_bytes()) for p in sorted(M0.rglob('*'))
            if p.is_file() and '__pycache__' not in p.parts
            and p.relative_to(M0).as_posix() not in ignored
            and not any(p.relative_to(M0).as_posix().startswith(prefix) for prefix in ('evidence/local-attempts/','evidence/runs/','evidence/prepared-','evidence/recheck-'))}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',required=True)
    p.add_argument('--seal',action='store_true')
    args=p.parse_args()
    output=Path(args.output).resolve()
    if output.exists(): p.error('Output already exists; preserve earlier validation attempts')
    output.parent.mkdir(parents=True,exist_ok=True)
    checks=[]
    def run(id,fn):
        try: detail=fn(); checks.append({'checkId':id,'status':'PASS','detail':detail})
        except Exception as err: checks.append({'checkId':id,'status':'FAIL','detail':str(err)})
    def require(condition,detail):
        if not condition: raise AssertionError(detail)
    manifest=M0/'evidence/package-manifest.json'
    def preservation():
        before=read_json(M0/'evidence/workspace-before.json')
        changed=[]
        for rel,record in before.items():
            path=ROOT/rel
            if not path.exists() or sha(path.read_bytes())!=record['sha256']: changed.append(rel)
        require(changed==['docs/GENERATE_CUST_NUMS/implementation-plan.md'],f'Unexpected changed/deleted files: {changed}')
        inputs=read_json(M0/'evidence/inputs-before.json')
        for rel,record in inputs.items():
            require(sha((M0/record['snapshot']).read_bytes())==record['sha256'],'Snapshot changed: '+rel)
        for name in ('GENERATE_CUST_NUMS.prod.sql','GENERATE_CUST_NUMS.sql'):
            rel='dw/STANDARDIZE_STAGE/Procedures/'+name
            require(sha((ROOT/rel).read_bytes())==inputs[rel]['sha256'],'Supplied SQL changed: '+name)
        after=M0/'evidence/inputs-after.json'
        if after.exists():
            for rel,record in read_json(after).items():
                require(sha((ROOT/rel).read_bytes())==record['sha256'],'Final input identity drift: '+rel)
        return f'{len(before)} original files checked; only authorized implementation-plan addition; {len(inputs)} snapshots exact; both supplied SQL preserved.'
    run('LOCAL-PRESERVATION',preservation)
    def normalization():
        capture=module('capture_inputs')
        rel='dw/STANDARDIZE_STAGE/Procedures/GENERATE_CUST_NUMS.prod.sql'
        original=(ROOT/rel).read_bytes()
        normal,changes=capture.normalize(original)
        require(normal==(M0/'scripts/sql/baseline.normalized.sql').read_bytes(),'Normalized bytes differ')
        require(len(changes)==15,'Unexpected normalization count')
        expected=''.join(difflib.unified_diff(original.decode().splitlines(True),normal.decode().splitlines(True),fromfile=rel,tofile='M0/scripts/sql/baseline.normalized.sql'))
        require(expected.encode()==(M0/'evidence/normalization.diff').read_bytes(),'Normalization diff differs')
        record=read_json(M0/'evidence/normalization.json')
        require(record['normalizedSha256']==sha(normal) and record['changes']==changes,'Normalization manifest differs')
        return {'changedLines':15,'normalizedSha256':sha(normal),'snowflakeCompilation':'NOT_RUN'}
    run('LOCAL-NORMALIZATION',normalization)
    def historical():
        cr=(M0/'evidence/inputs/docs/GENERATE_CUST_NUMS/Reviews/CR1.md').read_bytes()
        begin=cr.index(b'| Case | Modeled outcome |'); end=cr.index(b'\r\n\r\n',begin)
        hist=(M0/'fixtures/historical-cr1-ten-results.md').read_bytes()
        require(hist[hist.index(b'| Case | Modeled outcome |'):].rstrip(b'\r\n')==cr[begin:end],'Historical table changed')
        require(len(cr[begin:end].splitlines())==12,'Historical table must contain ten cases')
        return 'Original ten modeled outcomes preserved exactly; not rerun.'
    run('LOCAL-HISTORICAL',historical)
    def fixtures():
        registry=read_json(M0/'fixtures/check-registry.json')['checks']
        ids=[r['checkId'] for r in registry]
        require(len(ids)==90 and len(set(ids))==90,'Expected 90 unique checks')
        require(all(r['status']=='NOT_RUN' and r['prerequisite'] and r['expected'] and r['retainedEvidence'] for r in registry),'Missing check contract/status')
        cases=read_json(M0/'fixtures/behavior-cases.json')['cases']
        require(len(cases)==20,'Expected 20 oracle pairs')
        for case in cases:
            require(case['status']=='NOT_RUN' and 'productionBaseline' in case and 'approvedTarget' in case,'Oracle missing')
            require(all(len(r)==7 for r in case['profiles']) and all(len(r)==5 for r in case['core']),'Fixture row width')
            require((M0/'scripts/sql'/('baseline_'+case['id'].lower()+'.sql')).exists(),'Missing baseline case SQL')
        for check in registry:
            for script in check['scripts'].split(';'):
                if script.endswith('.sql'): require((M0/'scripts/sql'/script).exists(),'Missing script '+script)
        rules=read_json(M0/'fixtures/required-rule-registry.json')['rules']
        require(len(rules)==21 and len({r['checkId'] for r in rules})==21,'Runtime rule IDs must be unique')
        require(all(r['qualification'] in ids and r['modes'] and r['stage'] and r['prerequisite'] and r['evidence'] for r in rules),'Missing mode/stage/evidence traceability')
        return '90 NOT_RUN qualification checks; 21 future runtime rule definitions; 20 paired oracle fixtures; all referenced SQL cases present.'
    run('LOCAL-REGISTRY-FIXTURES',fixtures)
    def python_parse():
        paths=sorted((M0/'scripts').glob('*.py'))
        for path in paths: ast.parse(path.read_text(encoding='utf-8'),filename=str(path))
        return f'{len(paths)} Python scripts parsed; no Snowflake module imported.'
    run('LOCAL-PYTHON-PARSE',python_parse)
    def sql_structure():
        candidate=(M0/'scripts/sql/11_candidate_wrapper.sql').read_text()
        helper=(M0/'scripts/sql/10_audit_helper.sql').read_text()
        for name,sql in [('candidate',candidate),('helper',helper)]:
            require(sql.count('$$')==2,f'{name}: dollar delimiters')
            body=sql.split('AS $$',1)[1]
            require(not re.search(r'(?im)^\s*(CREATE|ALTER|DROP)\s',body),f'{name}: runtime DDL')
            require('EXECUTE AS OWNER' in sql,f'{name}: rights missing')
        refs=set(re.findall(r'STANDARDIZE_\w+\.\w+',helper.split('AS $$',1)[1]))
        require(refs=={'STANDARDIZE_AUDIT.CUST_NUM_PROCESS_LOG'},f'Helper crosses transaction boundary: {refs}')
        require(re.findall(r'TRUNCATE TABLE\s+(\S+)',candidate)==['STANDARDIZE_STAGE.M0_WORK;'],'Unexpected truncate target')
        require('n := SQLROWCOUNT;' in candidate and 'IF (n <> 1)' in candidate,'Missing one-row gate')
        require('DELETE FROM STANDARDIZE_STAGE.M0_WORK WHERE RUN_ID=:run_id' in candidate,'Unscoped final cleanup')
        require('STANDARDIZE_CORE.PARTY_PROFILE' not in candidate and 'STANDARDIZE_CORE.CUST_NUM_INDIVIDUAL_XREF' not in candidate,'Candidate must not implement allocator')
        return 'Text inspection only: owner wrapper, gated truncate/run cleanup, no runtime DDL, audit-only helper. SQL grammar/transactions NOT_RUN.'
    run('LOCAL-SQL-SCOPE',sql_structure)
    def rendering():
        q=module('qualify'); c=q.config(M0/'fixtures/environment.example.json',True)
        scripts=sorted((M0/'scripts/sql').glob('*.sql'))
        for path in scripts:
            rendered=q.render(path,c)
            require('{{' not in rendered,'Unresolved token '+path.name)
            require('CURRENT_ACCOUNT()' in rendered and 'CURRENT_ROLE()' in rendered,'Missing guard '+path.name)
            for statement in rendered.split(q.SEP): require(statement.strip().endswith(';'),'Unterminated statement '+path.name)
        testdir=M0/'evidence/local-attempts'/output.stem
        testdir.mkdir(parents=True,exist_ok=False)
        def rejected(values,name):
            path=testdir/(name+'.json'); path.write_text(json.dumps(values))
            try: q.config(path,True)
            except ValueError: return
            raise AssertionError('Unsafe config accepted: '+name)
        rejected({**c,'database':'CDP_TALBOTS'},'reject-production-name')
        rejected({**c,'role':"BAD'; DROP DATABASE X;--"},'reject-injection')
        rejected({**c,'isolated_disposable_database':False},'reject-nonisolated')
        rejected({**c,'decoy_database':c['database']},'reject-same-decoy')
        try: q.config(M0/'fixtures/environment.example.json')
        except ValueError: pass
        else: raise AssertionError('Unfilled config accepted for execution')
        require('snowflake.connector' not in sys.modules,'Local validation imported connector')
        return f'{len(scripts)} SQL scripts rendered locally; 5 invalid environment cases rejected; no database connections.'
    run('LOCAL-RENDER-GUARDS',rendering)
    def links():
        checked=0
        paths=list(M0.glob('*.md'))+[ROOT/'docs/GENERATE_CUST_NUMS/implementation-plan.md']
        for path in paths:
            text=path.read_text(encoding='utf-8')
            for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',text):
                if target.startswith(('https:','http:','#')): continue
                target=urllib.parse.unquote(target.split('#')[0].strip('<>'))
                if not target: continue
                resolved=(path.parent/target).resolve()
                # Seal/report are produced at the successful end of this validation.
                if resolved in (manifest,output,M0/'evidence/local-validation.json'): continue
                require(resolved.exists(),f'Broken local link in {path.name}: {target}')
                checked+=1
        return f'{checked} local file links resolved; external links not treated as local qualification.'
    run('LOCAL-LINKS',links)
    def plan_diff():
        original=(M0/'evidence/inputs/docs/GENERATE_CUST_NUMS/implementation-plan.md').read_bytes()
        current=(ROOT/'docs/GENERATE_CUST_NUMS/implementation-plan.md').read_bytes()
        delta=''.join(difflib.unified_diff(original.decode().splitlines(True),current.decode().splitlines(True),fromfile='implementation-plan.before.md',tofile='implementation-plan.md'))
        require(delta.encode()==(M0/'evidence/implementation-plan.diff').read_bytes(),'Plan diff changed')
        additions=[line[1:] for line in delta.splitlines() if line.startswith('+') and not line.startswith('+++')]
        removals=[line for line in delta.splitlines() if line.startswith('-') and not line.startswith('---')]
        require(not removals and len(additions)==2 and 'M0/README.md' in ''.join(additions),'Plan edits exceed bounded progress addition')
        return 'Only the package link/progress paragraph plus blank line were added.'
    run('LOCAL-PLAN-DELTA',plan_diff)
    if args.seal:
        require(not manifest.exists(),'Manifest already sealed; do not overwrite')
        if all(c['status']=='PASS' for c in checks):
            final_inputs={rel:{'sha256':sha((ROOT/rel).read_bytes()),'bytes':(ROOT/rel).stat().st_size}
                          for rel in read_json(M0/'evidence/inputs-before.json')}
            (M0/'evidence/inputs-after.json').write_text(json.dumps(final_inputs,indent=2)+'\n',encoding='utf-8')
            raw={p.relative_to(M0).as_posix():sha(p.read_bytes()) for p in sorted((M0/'evidence/local-attempts').rglob('*')) if p.is_file()}
            (M0/'evidence/local-evidence-manifest.json').write_text(json.dumps(raw,indent=2)+'\n',encoding='utf-8')
            manifest.write_text(json.dumps({'sha256ByPath':artifacts(),'scope':'Package files; excludes manifest, current local-validation report and subsequent attempt directories/rechecks'},indent=2)+'\n',encoding='utf-8')
    if manifest.exists():
        def verify_manifest():
            expected=read_json(manifest)['sha256ByPath']; actual=artifacts()
            require(expected==actual,'Package artifact set/hash differs from sealed manifest')
            for rel,digest in read_json(M0/'evidence/local-evidence-manifest.json').items():
                require(sha((M0/rel).read_bytes())==digest,'Retained local evidence drift: '+rel)
            return f'{len(actual)} artifacts match sealed hashes.'
        run('LOCAL-PACKAGE-HASHES',verify_manifest)
    report={'date':'2026-10-19','timezone':'America/Chicago','executedAtUtc':dt.datetime.now(dt.timezone.utc).isoformat(),
            'status':'PASS' if all(c['status']=='PASS' for c in checks) else 'FAIL',
            'snowflakeStatus':'NOT_RUN','m0ExitGate':'NOT_MET','checks':checks}
    output.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,indent=2))
    if report['status']!='PASS': raise SystemExit(1)

if __name__=='__main__': main()
