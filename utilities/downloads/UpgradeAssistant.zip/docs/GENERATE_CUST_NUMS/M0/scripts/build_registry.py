"""Build the qualification registry; all database outcomes start NOT_RUN."""
from pathlib import Path
import csv
import json
M0=Path(__file__).resolve().parents[1]
rows=[]
def add(id,scope,scripts,expected,prerequisite,evidence):
    rows.append(dict(checkId=id,scope=scope,required=True,status='NOT_RUN',scripts=scripts,
                     expected=expected,prerequisite=prerequisite,retainedEvidence=evidence))
raw='New attempt directory: rendered SQL/hash, config, session/parameters, statement query IDs/rows/timing/code/state/message, inspect before/after, reviewer comparison; retain errors.'
env='Separately authorized isolated Snowflake run; exact environment and owner role; empty dedicated database; no source cloning.'
add('M0-ENV','M0','00_setup.sql','Exact account/database/role/warehouse and marker; synthetic fixtures only; setup refuses nonempty database.',env,raw)
add('M0-DEPLOYED','M0','metadata.sql.template','Reconcile deployed definition/escaping, DDL, overloads, owners/grants, callers and all consumers. Missing metadata remains unresolved.','Read-only metadata access; RPDM export; history window and retention',raw)
add('M0-BASELINE-COMPILE','M0','baseline.normalized.sql','Complete normalized zero-argument owner wrapper compiles; preserve additional parser errors/diffs, never edit supplied bytes.',env+' Use separate baseline database.',raw)
add('M0-CANDIDATE-COMPILE','M0','10_audit_helper.sql;11_candidate_wrapper.sql;12_scenarios.sql','Complete M0 wrappers compile, including owner rights, binds, exceptions, and audit scopes.',env,raw)
add('M0-ENTRY-INPUTS','M0','case_missing_feed.sql;case_missing_guid.sql;case_null_mode.sql;case_missing_mode.sql','Missing identity or null/omitted mode raises before gate/truncate/business work; never defaults to live.','Candidate compiled; inspect gate/work/business before and after',raw)
add('M0-SUCCESS','M0','case_live.sql;case_preview.sql;case_zero_work.sql','Each returns exact SUCCESS for M0 mechanics; preview/zero-work do not change business marker. No allocator validation claimed.','Candidate compiled; scenarios loaded once; fresh feeds',raw)
add('M0-IDENTITY','M0','case_live.sql;case_preview.sql','Exact opaque 36-character supplied GUID/feed/mode roundtrip; RUN_ID=feed; log IDs distinct. No generated identities or UUID validation.','Inspect log rows and call bindings; actual RPDM binding still separately required',raw)
add('M0-GATE-ONE','M0','case_missing_control.sql;case_duplicate_control.sql;21_restore_control_fixture.sql','-20971 before truncate/prepare; rollback gate updates; no unlocked fallback.','No concurrent runs; restore control fixture between missing/duplicate tests',raw)
add('M0-OVERLAP-COMMIT','M0','case_overlap_a_commit.sql;case_overlap_b_commit.sql','B blocks until A commits, then observes incremented marker and increments from fresh value.','Two separate sessions; start B only after A reaches held phase; observer role',raw+' Child query history proves order, no pre-lock business reads.')
add('M0-OVERLAP-ROLLBACK','M0','case_overlap_a_rollback.sql;case_overlap_b_rollback.sql','A raises -20972; B blocks then observes pre-A marker, proceeds after rollback.','Two sessions; same instructions as commit',raw)
add('M0-PREVIEW-OVERLAP','M0','case_preview_overlap_a.sql;case_preview_overlap_b.sql','Preview holds same gate; B waits through preview rollback; stale work restored before B truncates.','Two sessions plus observer',raw)
add('M0-TIMEOUT','M0','case_timeout_a.sql;case_timeout_b.sql;case_timeout_preview_a.sql;case_timeout_preview_b.sql','B lock UPDATE times out at configured 60 seconds before preparation; A hold is 80 seconds. Both live/preview fail without truncating A work.','LOCK_TIMEOUT=60 verified in both sessions; active hold confirmed before B; record scheduling delay',raw+' Query blocked duration, exact timeout error, A/B session IDs.')
add('M0-TRUNCATE-ROLLBACK','M0','22_seed_stale_work.sql;case_truncate_failure.sql;case_preview.sql','Failure/preview restores all seeded stale work and removes new run work; gate held across truncate.','Seed distinct stale RUN_ID values before each case; unused invocation IDs',raw)
add('M0-CLEANUP','M0','case_live.sql;case_cleanup_failure.sql','Live success leaves zero work; cleanup fault rolls back business marker; no source/CORE/control/log is truncated.','Independent runs/feeds; compare complete snapshots',raw)
add('M0-AUDIT-INDEPENDENCE','M0','case_overlap_a_commit.sql;case_overlap_b_commit.sql;case_apply_failure.sql','Observer sees IN_PROGRESS while A holds gate; B still blocked. Audit survives rollback and never touches business/control table.','Observer SELECT on sandbox audit log; query history visibility',raw)
add('M0-AUDIT-FAILURE','M0','case_initial_log_failure.sql;case_in_progress_failure.sql','-20981 prevents business apply; initialization failure does not acquire gate.','Candidate and helper compiled',raw)
add('M0-PRIMARY-ERROR','M0','case_apply_failure.sql;case_secondary_log_failure.sql;case_rollback_handler_failure.sql','Primary -20972/code/state/message preserved despite guarded secondary failure; retain implicit-scope errors if platform differs.','Actual caller must capture raw error; simulated rollback-handler failure does not prove real network failure',raw)
add('M0-POSTCOMMIT','M0','case_post_commit_log_failure.sql','Audit error -20981 surfaces; marker remains committed; repaired failure log says COMMITTED; no blind retry.','Distinct feed; observer snapshot after error',raw)
add('M0-CALLER-TX','M0','case_caller_transaction.sql;case_caller_transaction_preview.sql','Reject -20970 before gate; CURRENT_TRANSACTION after error equals pre-call ID and caller row remains under caller control.','Owner scope and actual harness; runner captures transaction before closing; interactive session for commit/rollback ownership proof',raw)
add('M0-AUTOCOMMIT','M0','23_owner_session_probe.sql;case_autocommit_false_direct.sql;case_lock_timeout_direct.sql','Supported caller preflight rejects FALSE; direct owner entry must also be constrained before generation and must enforce 60-second lock wait. Direct probes expose current gap if they reach the gate with unsupported settings.','No caller transaction; test both direct entry and actual RPDM configured path; owner SHOW is expected unsupported',raw)
add('M0-NONOWNER','M0','25_grants_isolated.sql;case_non_owner.sql','Authorized non-owner can call owner wrapper without business/work-table privileges; unauthorized caller denied.','Separate sandbox caller role; explicit future grant authorization; inspect inherited/future grants',raw)
add('M0-DATABASE','M0','case_other_database.sql','Fully qualified call affects only procedure database, including helper/log/control/work; decoy unchanged.','Existing empty M0 decoy database/schema with usage for caller; compare both databases',raw)
add('M0-OVERLOAD','M0','24_overload_demonstration.sql;case_retired_stub.sql;case_legacy_absent.sql','New signature coexists with zero-arg stub until exact-signature drop; old call then fails; candidate has no zero-arg/default overload.','Isolated stub only; deployed allocator retirement deferred to coordinated M5 cutover',raw)
add('M0-BLOCKED-JOIN','M0','30_relational_edge_probes.sql','Unique blocked join yields 3 rows, 1 eligible; no correlated SELECT-list EXISTS.','Isolated SQL execution',raw)
add('M0-NULL-OR-MERGE','M0','30_relational_edge_probes.sql','Nullable microprobe NOT IN count 0; NOT EXISTS count 1; IFNULL OR match count 1. Not end-to-end production evidence.','Controlled relations; do not relax actual CORE NOT NULL schema',raw)
for case in json.loads((M0/'fixtures/behavior-cases.json').read_text())['cases']:
    add('BASELINE-'+case['id'],'PRODUCTION_BASELINE','baseline_'+case['id'].lower()+'.sql',
        json.dumps(case['productionBaseline']), 'M0-BASELINE-COMPILE; fresh fixture reset; supplied-like CORE DDL; capture effective null ordering', raw)
    add('TARGET-'+case['id'],'FUTURE_TARGET','fixtures/behavior-cases.json',json.dumps(case['approvedTarget']),
        'M1-M4 implemented candidate and reconciled migrated fixtures; not executable by M0 marker wrapper',raw)
# Preserve every current-plan acceptance obligation verbatim in a separate future registry section.
plan=(M0/'evidence/inputs/docs/GENERATE_CUST_NUMS/implementation-plan.md').read_text()
for line in plan.splitlines():
    if line.startswith('| T'):
        fields=[f.strip() for f in line.strip('|').split('|')]
        id=fields[0].split(' ')[0]
        add('TARGET-'+id,'FUTURE_TARGET','implementation-plan section 9',fields[1],
            'Milestones in implementation-plan; integrated allocator and deployment/caller evidence, not M0 mechanics',raw)
(F:=M0/'fixtures/check-registry.json').write_text(json.dumps({'version':1,'allSnowflakeChecks':'NOT_RUN','checks':rows},indent=2)+'\n',encoding='utf-8')
with (M0/'fixtures/check-registry.csv').open('w',encoding='utf-8',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
print(f'{len(rows)} checks registered; all Snowflake outcomes NOT_RUN.')
