"""One-time LOCAL capture. No database libraries or connection logic."""
from pathlib import Path
import difflib
import hashlib
import json
import subprocess

M0 = Path(__file__).resolve().parents[1]
ROOT = M0.parents[2]

def sha(data):
    return hashlib.sha256(data).hexdigest()

def normalize(data):
    # Preserve comments, whitespace, CRLF, ranks, DDL, predicates and transaction logic.
    lines = data.decode('utf-8').splitlines(keepends=True)
    changes = []
    for i, line in enumerate(lines):
        before = line
        code, sep, comment = line.partition('--')
        code = code.replace("''", "'")
        line = code + sep + comment
        if line.strip() == 'END':
            line = line.replace('END', 'END;')
        if i == len(lines)-1 and line.strip() == '$$':
            line = line.replace('$$', '$$;')
        if line != before:
            changes.append({'line': i+1, 'before': before.rstrip('\r\n'),
                            'after': line.rstrip('\r\n'),
                            'reason': 'Decode one export quoting layer in SQL literals' if "''" in code or "''" in before.partition('--')[0]
                            else 'Add scripting END terminator' if before.strip() == 'END'
                            else 'Add CREATE PROCEDURE statement terminator'})
        lines[i] = line
    return ''.join(lines).encode('utf-8'), changes

def main():
    evidence = M0 / 'evidence'
    evidence.mkdir(parents=True, exist_ok=True)
    manifest = evidence / 'inputs-before.json'
    if manifest.exists():
        raise SystemExit('Capture exists; refuse to overwrite original evidence.')
    paths = sorted(p for p in ROOT.rglob('*') if p.is_file()
                   and '.git' not in p.relative_to(ROOT).parts and M0 not in p.parents)
    workspace = {p.relative_to(ROOT).as_posix(): {'sha256': sha(p.read_bytes()), 'bytes': p.stat().st_size}
                 for p in paths}
    (evidence/'workspace-before.json').write_text(json.dumps(workspace, indent=2)+'\n', encoding='utf-8')
    (evidence/'git-status-before.txt').write_bytes(subprocess.check_output(['git','status','--porcelain=v1'], cwd=ROOT))
    requested = ['docs/GENERATE_CUST_NUMS/'+p for p in ['implementation-plan.md','Reviews/CR1.md','REPORTING.md','README.md','plan-refactoring.md']]
    requested += ['dw/STANDARDIZE_STAGE/Procedures/'+p for p in ['GENERATE_CUST_NUMS.prod.sql','GENERATE_CUST_NUMS.sql']]
    # Inventory sources are inputs too; exact snapshots make later line references reviewable.
    requested += [p.relative_to(ROOT).as_posix() for p in (ROOT/'dw').rglob('*') if p.is_file() and p.suffix in ('.sql','.md')]
    inputs = {}
    for rel in sorted(set(requested)):
        data = (ROOT/rel).read_bytes()
        dest = evidence/'inputs'/rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
        inputs[rel] = {**workspace[rel], 'lines': len(data.splitlines()), 'snapshot': dest.relative_to(M0).as_posix()}
    manifest.write_text(json.dumps(inputs, indent=2)+'\n', encoding='utf-8')
    rel = 'dw/STANDARDIZE_STAGE/Procedures/GENERATE_CUST_NUMS.prod.sql'
    original = (ROOT/rel).read_bytes()
    normalized, changes = normalize(original)
    target = M0/'scripts/sql/baseline.normalized.sql'
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(normalized)
    diff = ''.join(difflib.unified_diff(original.decode().splitlines(True), normalized.decode().splitlines(True),
                                      fromfile=rel, tofile='M0/scripts/sql/baseline.normalized.sql'))
    (evidence/'normalization.diff').write_bytes(diff.encode())
    (evidence/'normalization.json').write_text(json.dumps({'originalSha256':sha(original), 'normalizedSha256':sha(normalized),
         'changes':changes, 'snowflakeCompilation':'NOT_RUN'}, indent=2)+'\n', encoding='utf-8')
    cr = (ROOT/'docs/GENERATE_CUST_NUMS/Reviews/CR1.md').read_bytes()
    begin = cr.index(b'| Case | Modeled outcome |')
    end = cr.index(b'\r\n\r\n', begin)
    hist = M0/'fixtures/historical-cr1-ten-results.md'
    hist.parent.mkdir(parents=True, exist_ok=True)
    hist.write_bytes(b'# Historical CR1 results - unchanged excerpt\r\n\r\nNot production results; not rerun. Original reviewed snapshot: f935962f00bda9975225324224565c9ae7b858db7f53b8a16136ee29e71d47f4.\r\n\r\n'+cr[begin:end]+b'\r\n')
    refs = subprocess.run(['rg','-n','--hidden','-g','!.git/**','-g','!.backup/**','-g','!docs/**',
        'GENERATE_CUST_NUMS|CUST_NUM_INDIVIDUAL_XREF|CUST_NUM_XREF|cnxi_|CNX_01|CUST_NUM_PROCESS|CUST_NUM_RESERVATION','dw'],
        cwd=ROOT, capture_output=True)
    if refs.returncode not in (0,1): raise RuntimeError(refs.stderr.decode())
    (evidence/'repository-references.txt').write_bytes(refs.stdout)
    print(json.dumps({'inputs':len(inputs), 'workspaceFiles':len(workspace), 'normalizationChanges':len(changes), 'originalSha256':sha(original), 'normalizedSha256':sha(normalized)}))

if __name__ == '__main__':
    main()
