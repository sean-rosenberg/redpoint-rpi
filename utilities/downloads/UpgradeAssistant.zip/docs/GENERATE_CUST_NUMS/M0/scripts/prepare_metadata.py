"""Render read-only deployed inventory SQL locally. Never executes it."""
from pathlib import Path
import argparse
import datetime
import re
p=argparse.ArgumentParser(description=__doc__)
for key in ('deployed-database','owner-role','caller-role','history-start','history-end','output'):
    p.add_argument('--'+key, required=True)
a=vars(p.parse_args())
for k in ('deployed_database','owner_role','caller_role'):
    if not re.fullmatch('[A-Z][A-Z0-9_]*',a[k]): p.error('Simple uppercase identifier required: '+k)
for k in ('history_start','history_end'):
    value=datetime.datetime.fromisoformat(a[k])
    if value.tzinfo is None: p.error('History bounds require explicit UTC offsets')
if datetime.datetime.fromisoformat(a['history_start']) >= datetime.datetime.fromisoformat(a['history_end']): p.error('History bounds reversed')
sql=(Path(__file__).parent/'metadata.sql.template').read_text()
for k,v in a.items(): sql=sql.replace('{{'+k.upper()+'}}',v)
dest=Path(a['output'])
with dest.open('x',encoding='utf-8',newline='\n') as f: f.write(sql)
print('Prepared read-only metadata queries; NOT_RUN: '+str(dest))
