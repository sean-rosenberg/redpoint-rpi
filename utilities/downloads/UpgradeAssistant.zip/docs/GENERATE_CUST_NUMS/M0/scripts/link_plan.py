"""Apply the single authorized package progress link without rewriting other bytes."""
from pathlib import Path
import difflib
M0=Path(__file__).resolve().parents[1]
path=M0.parent/'implementation-plan.md'
before=(M0/'evidence/inputs/docs/GENERATE_CUST_NUMS/implementation-plan.md').read_bytes()
if path.read_bytes()!=before:
    raise SystemExit('Plan differs from captured input; refusing to overwrite concurrent changes.')
nl=b'\r\n' if b'\r\n' in before else b'\n'
anchor=b'Each milestone produces reviewable code/scripts and evidence. Passing a local check does not close a Snowflake acceptance gate. No intermediate milestone is a releasable implementation of all CR1 decisions.'+nl
addition=nl+('M0 local preparation (October 19): the [qualification package](M0/README.md) contains preserved input identities, a separate normalized baseline and exact diff, caller/consumer inventory, isolated transaction/logging prototypes, fixtures, a check registry, and local validation evidence. Both supplied procedure files remain unchanged. All Snowflake checks are NOT_RUN; the M0 exit gate is NOT MET, including the unresolved owner-entry AUTOCOMMIT/lock-timeout enforcement mechanism and missing deployed/environment evidence. No M1 implementation or database execution has started. See the [status and handoff](M0/STATUS.md).').encode('utf-8')+nl
if before.count(anchor)!=1: raise SystemExit('Milestone anchor not unique.')
after=before.replace(anchor,anchor+addition)
path.write_bytes(after)
diff=''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='implementation-plan.before.md',tofile='implementation-plan.md'))
(M0/'evidence/implementation-plan.diff').write_bytes(diff.encode())
print('Added only the M0 package progress/link paragraph; retained exact diff.')
