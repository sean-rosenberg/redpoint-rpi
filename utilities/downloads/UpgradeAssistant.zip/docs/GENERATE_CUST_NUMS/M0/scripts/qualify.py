"""M0 renderer and OPTIONAL future isolated executor. Default commands are local.

No Snowflake import/connection occurs for render. Execution requires the separate
execute command and --execute-isolated; that flag does not supply authorization.
SQL scripts use explicit statement boundaries, so procedure bodies stay intact.
"""
from pathlib import Path
import argparse
import datetime as dt
import hashlib
import json
import re
import sys
import time

M0 = Path(__file__).resolve().parents[1]
SQL = M0/'scripts/sql'
SEP = '\n-- M0_STATEMENT\n'

def digest(data): return hashlib.sha256(data).hexdigest()
def write_json(path, value): path.write_text(json.dumps(value, indent=2, default=str)+'\n', encoding='utf-8')
def config(path, allow_example=False):
    c = json.loads(Path(path).read_text(encoding='utf-8'))
    for key in ('account_locator','database','role','warehouse','caller_role','decoy_database','package_marker'):
        if not re.fullmatch(r'[A-Z][A-Z0-9_]*', c[key]): raise ValueError('Unsafe identifier: '+key)
    for key in ('database','decoy_database'):
        if not c[key].startswith('M0_CUST_NUM_'): raise ValueError('Database must start M0_CUST_NUM_')
    if c['database'] == c['decoy_database']: raise ValueError('Decoy must differ from qualification database')
    if c['isolated_disposable_database'] is not True: raise ValueError('Isolated database declaration required')
    if not allow_example and any('REPLACE' in str(v) for v in c.values()): raise ValueError('Unfilled environment value')
    return c

def render(source, c):
    body = source.read_text(encoding='utf-8')
    for key, value in c.items(): body = body.replace('{{'+key.upper()+'}}', str(value))
    if '{{' in body: raise ValueError('Unresolved SQL template token')
    guard = f"""-- M0 ISOLATED ONLY. Stop on the first SQL error. No production execution.
EXECUTE IMMEDIATE $$
DECLARE bad_environment EXCEPTION (-20990, 'M0 environment guard failed');
BEGIN
  IF (CURRENT_ACCOUNT() <> '{c['account_locator']}' OR
      CURRENT_DATABASE() <> '{c['database']}' OR
      CURRENT_ROLE() <> '{c['role']}' OR
      CURRENT_WAREHOUSE() <> '{c['warehouse']}') THEN
    RAISE bad_environment;
  END IF;
  RETURN 'M0_ENVIRONMENT_OK';
END;
$$;"""
    return guard+SEP+'USE SCHEMA '+c['database']+'.STANDARDIZE_STAGE;'+SEP+body

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('command', choices=['render','execute'])
    p.add_argument('--config', required=True)
    p.add_argument('--script', required=True, help='basename under scripts/sql')
    p.add_argument('--output', required=True, help='NEW retained attempt directory; never overwritten')
    p.add_argument('--check-id', required=True)
    p.add_argument('--execute-isolated', action='store_true')
    p.add_argument('--allow-example', action='store_true', help='render only')
    args=p.parse_args()
    if Path(args.script).name != args.script: p.error('Use a script basename')
    if args.command=='execute' and (not args.execute_isolated or args.allow_example):
        p.error('Execution requires --execute-isolated and a completed config')
    c=config(args.config, args.allow_example)
    script=SQL/args.script
    sql=render(script,c)
    out=Path(args.output).resolve()
    out.mkdir(parents=True, exist_ok=False)
    (out/'rendered.sql').write_text(sql, encoding='utf-8', newline='\n')
    write_json(out/'environment.json',c)
    meta={'checkId':args.check_id,'script':args.script,'templateSha256':digest(script.read_bytes()),
          'renderedSha256':digest(sql.encode()),'startedUtc':dt.datetime.now(dt.timezone.utc).isoformat(),
          'snowflakeStatus':'NOT_RUN','validationStatus':'NOT_RUN','command':args.command}
    write_json(out/'attempt.json',meta)
    if args.command=='render':
        print('PREPARED locally; Snowflake NOT_RUN: '+str(out)); return
    # Only this explicit future action can load the connector or contact Snowflake.
    conn=None
    try:
        import snowflake.connector
        conn=snowflake.connector.connect(connection_name=c['connection_name'], database=c['database'],
                                        role=c['role'], warehouse=c['warehouse'])
        cursor=conn.cursor()
        context=cursor.execute('SELECT CURRENT_ACCOUNT(), CURRENT_DATABASE(), CURRENT_ROLE(), CURRENT_WAREHOUSE(), CURRENT_TRANSACTION(), CURRENT_VERSION(), CURRENT_SESSION()').fetchone()
        write_json(out/'session.json',context)
        if tuple(context[:4]) != tuple(c[k] for k in ('account_locator','database','role','warehouse')):
            raise RuntimeError('Connected environment does not match exact allowlist')
        if context[4] is not None: raise RuntimeError('Open caller transaction on entry; refusing to change it')
        cursor.execute('SHOW PARAMETERS IN SESSION')
        columns=[d[0].lower() for d in cursor.description]
        params=[dict(zip(columns,r)) for r in cursor.fetchall()]
        write_json(out/'parameters.json',params)
        values={str(r['key']).upper():str(r['value']).upper() for r in params}
        if values.get('AUTOCOMMIT')!='TRUE' or values.get('LOCK_TIMEOUT')!='60':
            raise RuntimeError('Configure AUTOCOMMIT=TRUE and LOCK_TIMEOUT=60 before entry; runner does not change them')
        if args.script=='00_setup.sql':
            for relation in ('TABLES','PROCEDURES','VIEWS'):
                n=cursor.execute(f"SELECT COUNT(*) FROM {c['database']}.INFORMATION_SCHEMA.{relation} WHERE {('PROCEDURE_SCHEMA' if relation=='PROCEDURES' else 'TABLE_SCHEMA')} <> 'INFORMATION_SCHEMA'").fetchone()[0]
                if n: raise RuntimeError('Setup requires an empty pre-created database (schemas only); '+relation)
        else:
            marker=cursor.execute(f"SELECT MARKER FROM {c['database']}.STANDARDIZE_AUDIT.M0_ENVIRONMENT").fetchall()
            if marker != [(c['package_marker'],)]: raise RuntimeError('Missing or ambiguous M0 marker')
        with (out/'statements.jsonl').open('x',encoding='utf-8') as log:
            for n,statement in enumerate(sql.split(SEP),1):
                started=time.monotonic()
                record={'statement':n,'sql':statement}
                try:
                    cursor.execute(statement)
                    record.update(queryId=cursor.sfqid, columns=[d[0] for d in cursor.description] if cursor.description else [],
                                  rows=cursor.fetchall() if cursor.description else [], execution='SUCCEEDED')
                except Exception as err:
                    record.update(execution='ERROR',queryId=getattr(err,'sfqid',cursor.sfqid),code=getattr(err,'errno',None),
                                  sqlstate=getattr(err,'sqlstate',None),message=str(err))
                    raise
                finally:
                    record['elapsedSeconds']=time.monotonic()-started
                    log.write(json.dumps(record,default=str)+'\n'); log.flush()
        meta['snowflakeStatus']='EXECUTED_REQUIRES_REVIEW'
    except Exception as err:
        meta.update(snowflakeStatus='ATTEMPT_FAILED',error={'type':type(err).__name__,'code':getattr(err,'errno',None),
                    'sqlstate':getattr(err,'sqlstate',None),'message':str(err),'queryId':getattr(err,'sfqid',None)})
        if conn:
            # Observe the caller-owned transaction before session close. Never issue rollback here.
            try: write_json(out/'transaction-after-error.json',conn.cursor().execute('SELECT CURRENT_TRANSACTION()').fetchall())
            except Exception as secondary: write_json(out/'secondary-observation-error.json',{'message':str(secondary)})
        raise
    finally:
        meta['finishedUtc']=dt.datetime.now(dt.timezone.utc).isoformat()
        write_json(out/'attempt.json',meta)
        if conn:
            try: conn.close()
            except Exception as secondary:
                write_json(out/'secondary-close-error.json',{'message':str(secondary)})
    print('Execution retained. Compare actual results with registry; no automatic qualification PASS.')

if __name__=='__main__': main()
