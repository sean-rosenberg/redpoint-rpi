# Expected behavior and evidence boundaries

Expectations were written before any Snowflake testing. [behavior-cases.json](fixtures/behavior-cases.json) has 20 independent production-baseline and approved-target oracles with concrete synthetic source/CORE rows. [check-registry.json](fixtures/check-registry.json) holds stable IDs, prerequisites, expected outcomes and retained evidence. None is a test result.

## Historical evidence

[historical-cr1-ten-results.md](fixtures/historical-cr1-ten-results.md) retains CR1's original ten-row table exactly, including historical `-20007` and `-20008` results. It is not relabeled as production evidence and was not rerun. The local validator compares the table bytes against the preserved CR1 input. The historical model source was not supplied; this package does not reconstruct it and claim an identical run.

## Production versus target

Normal cases use valid 12-digit individual IDs. Small IDs/nulls are deliberately marked invalid cases. Baseline result entries list new genuine assignments and synthetic reservation tuples separately; compare their union to inserted XREF rows, retaining multiplicity and feed attribution. Pre-existing CORE rows must remain byte/value equivalent except that comparison excludes newly generated timestamps on newly inserted rows. The target uses a separate six-column reservation relation; it is not run by the M0 transaction marker wrapper.

| Cases | Required distinction |
| --- | --- |
| PB01–PB02 | Production has no status filter. Target exact NON_ACTIVE blocks globally across individuals/SORs and numeric leading-zero forms; newly blocked reservations are current invocation creations. |
| PB03–PB04 | Both versions keep the original DENSE_RANK / ROW_NUMBER intersection, with no fallback or rebalance. Loser receives generated number; eligible losing 102 is merged reservation. |
| PB05–PB06 | Production ignores extra external numbers on mapped individuals. Target newly retires unused 77, while preserving existing 42 and never overlapping it with a reservation. |
| PB07–PB08 | Start at 500000001. Production exhaustion is -20005 after staging; no early -20008. Target requires pre-apply GENERATED_CAPACITY failure. Target numeric error codes are implementation work, not invented in M0. |
| PB09–PB13 | Invalid CORE, synthetic-ID collisions/masking, production NOT IN discovery and NULL behavior are modeled separately. Baseline has no completeness -20007. Supplied CORE NOT NULL constraints matter. |
| PB14 | Baseline result depends on effective owner/account null ordering. Target known date wins under every caller default via explicit NULLS LAST. Record actual owner behavior; a caller session setting may not control this owner-rights parameter. |
| PB15 | Production TRY_CAST can adopt rounded fractional input. Target invalid PK1 cannot create rounded assignments/reservations, but valid individual still gets generated number. |
| PB16 | Valid historical reservation 42 and genuine ID 100000000042 coexist. Target run assumes separately verified migration lineage; missing lineage blocks migration acceptance first. |
| PB17–PB18 | Preserve retained-XREF allocation, gap behavior, multiplicity and genuine-assignment maximum source-feed attribution. No reservation-specific attribution change may silently change genuine assignment provenance. |
| PB19–PB20 | New reservation picks source ID `'10'` before `'2'`, with that same row's feed; target rejects retained genuine assignment at reserved 500000000 without repairing it. |

[30_relational_edge_probes.sql](scripts/sql/30_relational_edge_probes.sql) separately demonstrates NULL poisoning and OR-MERGE sentinel matching using controlled CTEs. Do not relax deployed CORE constraints to pretend these are reachable production fixtures. In PB12 the production NOT IN eliminates the NULL source **before** a staged proposal reaches MERGE; the historical reference's sentinel rejection is a different path. Unchanged-data conflicts can also be caught by earlier duplicate checks. To test a later concurrent conflict, retain the schedule and distinguish the accepted external-writer race from an initial-data case.

[status-and-pk1.json](fixtures/status-and-pk1.json) specifies exact status variants, unsigned syntax/conversion/range endpoints, source-ID boundaries and whitespace. Future fixtures must test mapped and unmapped invalid IDs before PK1 filtering, source mutation after capture, all SOR discovery, and raw diagnostic values. Collation and upstream integer coercion require actual schema/client evidence.

## Historical versus new reservations

[reservation-lineage.json](fixtures/reservation-lineage.json), RL01–RL09, explicitly separates validated legacy migration from new generation. These are synthetic evidence examples, not claims about real history.

Migration preserves verified original timestamp/reason, reconstructs the actual generation feed, and separately reconstructs the selected source ID/feed. Legacy individual-level MAX source attribution is not generation audit or proof of winning source identity. Missing/ambiguous history, unknown record types, malformed keys, or nonactive/unused rows without an identified writer block acceptance. Only merged reservations are explained by the supplied producer. Current profiles cannot prove deleted historical evidence.

Newly blocked/unused values are new target reservations with current invocation audit; they are never backdated or counted as migrated rows. Existing reservations keep all six fields forever during ordinary generation, even after later NON_ACTIVE evidence, corrected/deleted source, or changed feed. New reservationCount excludes them. Existing genuine assignments remain unchanged even if a current eligibility check would reject a fresh assignment.

## Registry and future acceptance

The 90-row qualification registry consists of 27 M0 mechanism/inventory checks, 20 baseline oracles, 20 future-target oracles, and all current plan tests T01–T23. M0 prototype check IDs are qualification evidence identifiers, not an expansion of routine process metrics. [required-rule-registry.json](fixtures/required-rule-registry.json) separately defines 21 stable future runtime rule IDs, required modes/stages, prerequisites, expectations and evidence, mapped to these qualification checks. It is a design registry, not additional test results. Numeric exception assignments remain implementation work.

Every Snowflake outcome starts NOT_RUN. A script returning successfully is only execution evidence; a reviewer must compare rows, errors, cardinality, settings and invariants before recording PASS in a new evidence file. A failed expected-error call can be a passing check only after its original code/state/message, lack of forbidden writes and transaction state are verified. Never overwrite a failed attempt or change an oracle to match an unexpected result without a reviewed versioned correction.

Future target checks include two-session same-person/seed/external conflicts, fresh state after waiting, complete disposition, existing assignment preservation, all three apply-count reconciliations, preview/zero work, report field/JSON/null agreement, retries, and unresolved commit outcomes. The marker probes establish platform mechanics only; they do not replace these allocation tests. No history-loss detector, sequence, separate allocation counter, fallback rounds, routine sample tables, or extra metric families are introduced.

## T23 workload qualification plan

Use the exact verified production executable and later exact candidate on independent isolated copies of the same approved data snapshot, same warehouse size/settings, cache policy and concurrency. Retain input/data identities, query IDs/profiles, elapsed time, bytes/partitions scanned, sort/spill, row multiplicity, warehouse consumption and repetitions outside routine reporting. Retain failures and warm/cold distinctions; agree performance thresholds before acceptance.

Stratify source/profile count, already-mapped share, ICON/MAO share, blocked and leading-zero duplicates, contested external values, null dates, historical reservations, generated capacity and skew. Measure initial migration separately from **first target generation**, whose new blocked/unused reservations may grow sharply because production never retired those values and did not cover mapped individuals. Measure first-run growth by distinct new numbers and qualifying source population, then steady-state rerun, later status/source changes, rollback and overlap. Reconcile assignments and reservation reasons/lineage with the frozen oracles before comparing speed. Production has seven permanent success work objects/two source reads; error path adds one object/read. Additional target validation, retirement and audit costs are intentional; no speedup is claimed.
