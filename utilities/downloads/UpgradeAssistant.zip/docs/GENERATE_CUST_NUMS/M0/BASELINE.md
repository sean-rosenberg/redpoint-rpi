# Baseline identity and normalization

The client-supplied production input is `dw/STANDARDIZE_STAGE/Procedures/GENERATE_CUST_NUMS.prod.sql`: 10,397 bytes, 266 lines, SHA-256 `c87fcea7bfc1e81adc40f3443ceb68d72e9db7c37ec35c5afea0653f98d2cb4b`. It is supplied production evidence, not a deployed readback.

The unchanged current historical/reference file is 20,806 bytes, 496 lines, SHA-256 `c2d72149026c77ffaf8fabf7a0143813b54d6be851d5d1e814e57a96fe14e31f`. CR1 identifies a different historical 495-line snapshot, SHA-256 `f935962f00bda9975225324224565c9ae7b858db7f53b8a16136ee29e71d47f4`. This package preserves CR1's ten-result excerpt, but does not claim possession or reproduction of that original historical executable/model.

All 24 actual procedure, documentation, DDL, and RPDM input files have byte hashes and exact copies under [evidence/inputs](evidence/inputs-before.json). The captured implementation plan is the pre-package version. Its small final progress/link addition is separately retained in [implementation-plan.diff](evidence/implementation-plan.diff).

## Prepared executable copy

[baseline.normalized.sql](scripts/sql/baseline.normalized.sql), SHA-256 `7f3ace8845ded1eeaef9a134ce3fc2427d2eb4158009b4d29957f174dff63e99`, is **locally prepared, not Snowflake-compiled**. [normalization.diff](evidence/normalization.diff) is the exact unified diff; [normalization.json](evidence/normalization.json) explains every changed line. [capture_inputs.py](scripts/capture_inputs.py) defines the deterministic transformation and refuses to overwrite initial evidence.

There are exactly 15 changed lines:

1. Decode one layer of doubled apostrophes on 13 SQL-literal lines: seven exception messages, ICON/MAO, three record-type literals, the generated-range record-type predicate, and SUCCESS. `AS $$` already delimits the body, so the inner SQL literals need ordinary quote delimiters. Preserve comments, including doubled apostrophes in comments, to minimize the diff.
2. Change the final scripting `END` to `END;`.
3. Change the closing `$$` to `$$;` to terminate the CREATE PROCEDURE statement for file-based execution.

The wrapper name, zero arguments, owner rights, VARCHAR return, seven success-path permanent tables, exception debug table, two success-path source reads, ranks, date ordering, NOT IN, either-key occupancy, UNION, OR-MERGE, generated-range predicate/error, transaction statements, and allocation behavior are otherwise unchanged. No target fixes were smuggled into the baseline. Dollar delimiters preserve contained text without single-quoted-string escaping. See [Snowflake string constants](https://docs.snowflake.com/en/sql-reference/data-types-text#dollar-quoted-string-constants).

This is an export-normalization hypothesis. Reconcile it against deployed `GET_DDL`, then compile it with the actual client. A parser failure must be retained, followed by a separately reviewed minimal diff and new identity. Do not silently broaden normalization or count file parsing as Snowflake compilation.

## Isolation requirement

Use a fresh, dedicated `M0_CUST_NUM_*` database with `STANDARDIZE_CORE`, `STANDARDIZE_STAGE`, and `STANDARDIZE_AUDIT`, synthetic fixtures, and no production clones or grants. Install the baseline only in its own baseline database, separate from the candidate mechanics database. The renderer keeps the body byte content apart from newline serialization in the retained rendered file and prepends environment guards; it records both hashes.

The baseline always attempts live application and contains runtime DDL. An outer rollback is not isolation, and a baseline CALL must never be described as preview. Only the disposable database limits its effects. Startup/exception permanent objects may survive failures. Snowflake documents DDL transaction boundaries and scoped transactions separately from ordinary business rollback. See [transactions](https://docs.snowflake.com/en/sql-reference/transactions).
