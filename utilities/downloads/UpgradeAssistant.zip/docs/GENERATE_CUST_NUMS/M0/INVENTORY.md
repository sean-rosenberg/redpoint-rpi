# Deployment and caller inventory

Repository evidence is captured in [repository-references.txt](evidence/repository-references.txt), with each input hashed in [inputs-before.json](evidence/inputs-before.json). Searches included hidden RPDM paths and excluded `.git` and `.backup` from active-caller conclusions. Backup/reference matches are historical evidence, not additional deployed callers.

## Known repository objects and consumers

| Evidence | Observed contract | Qualification/cutover implication |
| --- | --- | --- |
| [Production export](../../../dw/STANDARDIZE_STAGE/Procedures/GENERATE_CUST_NUMS.prod.sql) | Zero-argument `GENERATE_CUST_NUMS()`, SQL, `EXECUTE AS OWNER`, VARCHAR SUCCESS/errors; no preview/log | D06 adds `(NUMBER(38,0), VARCHAR(36), BOOLEAN)` with no defaults. Preserve SUCCESS/error behavior. |
| `dw/.scripts/rpdm/InSitu_Model/core/PartyProfile_002_Transform.dlp/Calculate 19/07-DIFFKEY_CUST_NUM_INDIVIDUAL_XREF.sql:1` | `CALL STANDARDIZE_STAGE.GENERATE_CUST_NUMS();` | One known local caller. Actual RPDM binding, caller role, connection/session reuse, orchestration and transaction boundary are missing. |
| Same folder, `09-DIFFKEY_CUST_NUM_XREF.sql:33` | Joins profile to assignment XREF by INDIVIDUAL_ID, no REC_TYPE predicate; writes permanent `STANDARDIZE_STAGE.CNX_01` | Verify genuine assignment history remains identical after reservation removal; cannot certify consumer safety from disjoint domains alone when legacy data is unresolved. |
| Same file, lines 4–8 | Uses maximum feed joined through AUTOMATION_LOG, filtered SOURCE_ID=10 / FEED_ID=101 | This is history-flow attribution, not authority for D06 invocation identity. Generation report uses existing harness SOURCE_ID=99 / FEED_ID=140. Do not copy this lookup into allocator entry. |
| Same file, legacy branch | Emits former ICON number as synthetic INDIVIDUAL_ID in history output | `CUST_NUM_XREF` history is a distinct model; do not classify those rows as allocator reservations or rewrite it under M0. Inspect actual consumer semantics at cutover. |
| Same folder, `10`–`12` SQL | ALTER/UPDATE CNX_01; joins `STANDARDIZE_IR.MATCH_INSTANCE` and `INTERNAL_ID_XREF` for change reason | CNX_01 is unrelated shared history scratch, explicitly excluded from allocator cleanup. IR DDL is not supplied. |
| Same folder, `13`–`14` SQL | UPDATE/INSERT `STANDARDIZE_CORE.CUST_NUM_XREF` from CNX_01 | Coordinated D08 consumer regression required. Existing source-of-truth RPDM must be updated, not merely local copies. |
| [XREF DDL](../../../dw/STANDARDIZE_CORE/Tables/CUST_NUM_INDIVIDUAL_XREF.sql) | Hard-coded `CDP_TALBOTS`; both numeric keys and CREATE_DATE NOT NULL; REC_TYPE and CREATE_FEED_INSTANCE_ID already present but nullable | Database literal is evidence, not verified deployment target. No unique constraints in supplied definition; check live table type/DDL/grants. Reference-only missing column script is not presumed necessary. |
| [PARTY_PROFILE DDL](../../../dw/STANDARDIZE_CORE/Tables/PARTY_PROFILE.sql) | Nullable NUMBER(38,0) individual, VARCHAR(320) PK1/source ID, VARCHAR(50) status, timestamp source date, update feed | Validate deployed types, collation, keys, data integrity, and retention. Fractional IDs rounded before storage require upstream/raw-boundary fixtures. |
| Audit DDL | AUTOMATION_LOG GUID VARCHAR(128), FEED_INSTANCE GUID VARCHAR(64), existing error/outcome/timing fields | Keep existing columns unchanged. New process-log/input GUID is settled VARCHAR(36); no width discovery or UUID-format policy gate. |

RPDM source-of-truth location: `repository://InSitu_Model/core/PartyProfile_002_Transform`, tool `Calculate 19`; `.dlp` is only a local directory suffix. See [RPDM README](../../../dw/.scripts/rpdm/README.md).

## Permanent allocator staging dependencies

All eight are in `STANDARDIZE_STAGE`. Production creates/replaces the first seven during success and the eighth on exception. No independent active repository reader was found outside the procedure/reference files; this is not proof that deployed consumers do not exist.

| Object | Responsibility | Inventory needed before retirement/repurposing |
| --- | --- | --- |
| CNXI_MAXID | Retained-XREF seed | DDL, ownership/grants, readers |
| CNXI_NEW_IND | New IDs / maximum source feed | Same; diagnostic/scheduler readers |
| CNXI_EXTERNAL_CUST_NUM | Dual ranking | Same; ranking-analysis consumers |
| CNXI_NEW_EXTERNAL_CUST_NUM | Selected external assignments | Same |
| CNXI_MERGED_EXTERNAL_CUST_NUM | Synthetic merged reservations | Same; reservation consumers |
| CNXI_NEW_CDP_CUST_NUM | Generated plan | Same |
| CUST_NUM_INDIVIDUAL_XREF | Combined staged outputs | Same; downstream readers of persistent output |
| CNXI_NEW_IND_DEBUG | Exception debug population | Same; support/diagnostic dependencies before removal |

`CNXI_TAKEN`, `CNXI_NONACTIVE_CUST_NUM`, `CNXI_NONACTIVE_EXTERNAL_CUST_NUM`, `CNXI_UNUSED_EXTERNAL_CUST_NUM`, and `CNXI_INSERT_REJECTS` are reference-only names. Their deployed existence is unknown. No local production DDL for CUST_NUM_PROCESS, CUST_NUM_PROCESS_LOG, or CUST_NUM_RESERVATION exists; M0 test objects are not those deployment deliverables. Physical target work-table choices remain M1 work.

## Owner and grants contract

Record exact roles, inheritance and managed-access ownership before deployment. The owner needs database/schema usage, warehouse access as applicable, source SELECT, assignment/reservation SELECT and INSERT, control SELECT/UPDATE, work SELECT/INSERT/DELETE/TRUNCATE, and USAGE on audit helper; the helper owner needs log SELECT/INSERT/UPDATE. Deployment additionally needs appropriate CREATE TABLE/PROCEDURE and controlled ownership authority. Production baseline CTAS/create-or-replace needs schema CREATE TABLE plus ownership of replaced objects in isolation. No generic ALL PRIVILEGES grant is proposed.

Callers need warehouse/database/schema access and USAGE on the exact public signature; they should not need direct business/work table access. The M0 runner adds SELECT on its harmless environment marker solely to verify isolation. Helper invocation access must not be broadly exposed. Inspect direct, inherited, future, PUBLIC and database-role grants; negative tests need an actually unauthorized role. No grants have been changed.

## Metadata and missing environment inputs

[metadata.sql.template](scripts/metadata.sql.template) is read-only and locally rendered by [prepare_metadata.py](scripts/prepare_metadata.py). It queries procedure definitions/signatures, owner/grants, schema types, tasks, view/procedure references, object dependencies, query history and audit summaries. Capture denials and unavailable/retained-out history as evidence. Account Usage latency, role visibility, dynamic SQL, external clients and RPDM mean a zero-row result is not a complete caller inventory. Obtain actual RPDM exports and scheduler/service configuration separately.

Before a qualification run, provide:

1. Account locator/region and exact deployed database; `GET_DDL` for every GENERATE/SP_GENERATE overload, its owner/grants and export provenance; source/target/audit/work DDL, table types, constraints, collation, policies and dependencies. Expand GET_DDL/SHOW GRANTS for every discovered work object and helper.
2. Fresh isolated baseline and candidate database names, three precreated schemas each, an empty decoy database, test warehouse, owner role, non-owner caller role and observer privileges. Profiles must already authenticate and enforce AUTOCOMMIT=TRUE and LOCK_TIMEOUT=60. Supply client/connector/RPDM versions and query-history visibility.
3. Actual RPDM statement/binding syntax and origin of both invocation identifiers, mode binding, transaction scope, session pooling/retries, all other callers, and legacy writers/overloads. The identifiers' contract is settled; only integration evidence is missing.
4. All assignment/reservation/work-table consumers and version owners, including views/tasks/dynamic SQL/external jobs; cutover pause/resume authority and recovery compatibility evidence.
5. Historical reservation writer/version, original timestamp, actual generation invocation feed and selected source ID/feed reconstruction evidence, with retention/time window. Missing/ambiguous evidence is a data blocker, not permission to guess. No generated-history reconstruction is required under D04.2.
6. Representative data-volume/skew and warehouse/profile evidence for T23, including already-mapped source coverage and first-run new blocked/unused reservation volume; performance acceptance thresholds supplied for later qualification.

## Coordinated signature/caller strategy (future M5)

Preserve deployed definitions and grants for review/recovery. Pause all generation callers, deploy the approved migrated model/compatible consumers, bind the caller-issued feed and unchanged GUID with an explicit Boolean to the new signature, and retire the zero-argument allocator and all alternate legacy entry points before re-enabling callers. `CREATE OR REPLACE` with new parameter types does not replace another overload. Verify signature-specific grants and prove zero-argument/omitted-mode calls cannot allocate or bypass the gate. The [overload stub probe](scripts/sql/24_overload_demonstration.sql) demonstrates this only with harmless isolated stubs. See [Snowflake overloading](https://docs.snowflake.com/en/developer-guide/udf-stored-procedure-naming-conventions#overloading-procedures-and-functions).

Do not install a compatibility view, dual writer, default-to-live argument or new shared harness framework. Recovery must be compatible with separate reservations and preserve genuine mappings; blindly re-enabling the old allocator is not a recovery plan. M0 prepares this strategy; it does not carry out cutover or modify the RPDM scripts.
