# GENERATE_CUST_NUMS — Code Review

## SQL-only qualification and JSON outcome revision (October 19)

The user approved a required JSON OUT outcome for harness/RPDM logging and control, and accepted excluding permission/ownership, transaction, timeout, logging-error, and locking tests except those required to validate serialization. This revision supersedes earlier conflicting return/error and qualification requirements; D01–D04/D08 allocation and migration policy is unchanged. Use the [SQL-only runbook](../M0/sql-only/README.md), [coverage and accepted gaps](../M0/sql-only/COVERAGE.md), and [JSON caller contract](../REPORTING.md#json-outcome-and-caller-actions). The original M0 package and CR1 historical ten modeled results remain evidence of their original scope. Both supplied procedure files are unchanged; the new SQL contains M0 fixtures/prototypes only. All Snowflake checks remain NOT_RUN. The reduced M0 gate remains NOT MET pending the required target-account results.

Assessment date: October 15, 2026 (America/Chicago). Updated October 19, 2026 for F01–F04, F09, and F11 planning decisions, the F07 fallback reversal, and the F10/F12 reporting and error-handling contracts; the October 16 individual-ID contract and business decisions remain applicable.

Reviewed source: `GENERATE_CUST_NUMS.sql`, 495 lines, 20,760 bytes. SHA-256: `f935962f00bda9975225324224565c9ae7b858db7f53b8a16136ee29e71d47f4`. All line references identify this snapshot.

Companion documents: [Business assessment](../README.md) and [Refactoring plan](../plan-refactoring.md).

The [October 16 business decisions](../README.md#recorded-business-decisions) now resolve several policy questions raised by this review. Required target behavior includes `NON_ACTIVE` global blocking of new assignments, `PARTY_PROFILE.INDIVIDUAL_ID` preflight validation, a separate CORE reservation table, original dual-ranking external selection without fallback (the earlier F07 fallback decision was reversed October 19), lowest priority for null dates, reserved `500000000`, retirement of unused eligible PK1s after successful processing, and success only when execution and all required checks pass. Findings and modeled outcomes still describe the reviewed source; these decisions are not implementation or test evidence.

## Production baseline applicability (October 19)

The client identifies `dw/STANDARDIZE_STAGE/Procedures/GENERATE_CUST_NUMS.prod.sql` as the production procedure requiring migration. This review's original source, line references, findings, and ten local modeled outcomes remain historical evidence for the other version; they are not production execution evidence. The [implementation plan](../implementation-plan.md#baseline-identity) records the production hash and authority split. D01–D08 remain settled target decisions.

| Finding | Applicability to supplied production | Implementation consequence |
| --- | --- | --- |
| F01 | No status column/predicate at all; reviewed `'-'` mismatch is absent. | Add exact global `NON_ACTIVE` blocking as new behavior. |
| F02 | Runtime CREATE OR REPLACE of permanent tables, not temporary tables. | Seven success-path objects plus exception debug object require inventory, predeployment, and transactional DML; account for persistent consumers. |
| F03 | No shared generation lock. | Implement the settled gate and concurrency verification. |
| F04 | Either-key occupancy remains, but reviewed completeness check/error is absent. | Add CORE preflight and complete disposition; historical completeness-failure examples are not production results. |
| F05 | Synthetic merged reservations exist; other reservation branches are absent. | Separate assignments/reservations; verify provenance of any other legacy reason found in data. |
| F06 | Source-ID preflight is absent; NOT IN and null-to-zero OR-MERGE are present; reference reject capture is absent. | Implement validated keys, null-safe discovery, coverage, and fatal reconciliation failures. |
| F07 | Original dual rankings and no fallback are present. | Preserve D02 with production-based regression fixtures. |
| F08 | No explicit null placement in date ranking. | Apply and verify NULLS LAST. |
| F09 | Two success-path source reads, plus exception debug read; no frozen population. | Capture once; target external coverage also includes already-mapped individuals. |
| F10 | Live-only zero-argument entry point returns SUCCESS without the proposed log. | Add explicit inputs, preview, reporting, and caller/overload cutover. |
| F11 | TRY_CAST without unsigned-integer syntax validation. | Apply the settled syntax/range contract. |
| F12 | Unguarded rollback followed by permanent debug-table DDL and rethrow. | Preserve original errors with guarded rollback and independent compact reporting. |
| F13 | Reviewed CASE/EXISTS and preview IF constructs are absent. Supplied export has AS $$ with doubled literals. | Verify export escaping and baseline/candidate compilation separately; no live parser failure has been reproduced. |

Production directly produces only `new_external_cust_num`, `new_cdp_cust_num`, and `merged_external_cust_num`. Newly blocked/unused reservations are target additions, not historical rows to invent. Existing genuine assignments remain fixed. The missing column script referenced by the reviewed source is not an established production prerequisite: production already uses both columns, subject to actual schema verification.

Retain the original modeled table below unchanged. Build independent production and target expectations: production has neither completeness error `-20007` nor early capacity error `-20008`; its generated-range check uses `-20005`. Use the verified production workload for performance comparison, not the reviewed twelve temporary tables/five success-path reads. These corrections change applicability, not the implementation/verification status of the target requirements.

## Review conclusion and scope

The block contains useful defensive checks and a reasonably explicit set of assignment categories. Its highest-priority problems include a status predicate that contradicts its own comments and missing required-ID validation. With the supplied real-ID range, F04/F05 no longer establish collisions for conforming data; they remain conditional invalid/legacy-data concerns. The mixed assignment/reservation model still requires clear consumer semantics. Transaction and concurrency guarantees also need to be established before treating this as a reliable live allocator. Compilation-sensitive constructs in F13 must be resolved first; the behavioral analysis describes the intended relational operations, not a claim that the supplied block executes successfully.

This is a **static review**, not a production execution or deployment approval. The supplied text is an anonymous Snowflake Scripting block or extracted procedure body: it omits the procedure declaration, parameters, execution-rights mode, target/source DDL, orchestration, and grants. It defaults to `what_if = true`. No database connection, query profile, deployed procedure definition, or original CDP-1029 specification was available.

Ten small cases were checked with a local Python model of the relevant set and ranking operations. They support the counterexamples below, but do not validate Snowflake compilation, optimizer behavior, locking, or actual schema constraints. Snowflake-specific semantics were checked against official documentation listed at the end.

Severity means impact if the stated condition occurs. **High** identifies incorrect identity assignment, missing assignment, blocking inconsistencies, or inadequate integrity guarantees. **Medium** identifies policy ambiguity, operational ambiguity, conditional data defects, or maintainability concerns. **Conditional** marks F04/F05 as outside the supplied valid-ID contract; their original high-impact failure modes require invalid or inconsistent legacy data. A conditional finding is not a claim that the corresponding production data or operating condition currently exists.

### Supplied individual-ID contract

CDP-generated real `INDIVIDUAL_ID` values are **100,000,000,000–199,999,999,999 inclusive**, as documented in the [business assessment](../README.md#number-domains). These are distinct from assignable generated `CUST_NUM` values (`500,000,001–599,999,999`; `500,000,000` is reserved) and all eligible external numbers (at most `999,999,999`). Synthetic reservation IDs copy external numbers and cannot collide with conforming real IDs. The source block does not validate the real-ID range, and historical data has not been inspected. The recorded decision now requires source-ID preflight validation.

F04/F05 retain the original counterexamples as out-of-contract cases, not expected production failures. Elsewhere, illustrative individuals 7 and 8 are shorthand for valid IDs `100000000007` and `100000000008`; their ordering is unchanged. The original local model results below have not been rerun for this documentation update.

## Findings at a glance

The following table describes the historical reviewed version; use the production applicability map above for migration. Status reflects the decisions and verification evidence recorded in this review. A settled business decision does not close an implementation finding; no implemented and verified fix is recorded here.

| ID | Severity | Status | Finding | Evidence classification |
| --- | --- | --- | --- | --- |
| F01 | High | Open — exact exclusion, all-other-value eligibility, and scope decided; implementation pending. | Non-active filtering checks `'-'`, not `'NON_ACTIVE'`. | Confirmed mismatch with the authoritative `NON_ACTIVE` business encoding; live source values remain uninspected. |
| F02 | High | Open — predeployed permanent staging required; implementation and live verification pending. | Temporary-table DDL breaks the apparent encompassing transaction. | Confirmed platform behavior applied to the supplied control flow. |
| F03 | High | Open — process-table serialization decided; implementation and concurrency verification pending. | Allocation and insertion are not protected against overlapping writers. | Missing protection in this block; external serialization unknown. |
| F04 | Conditional | Open — fail-preflight policy decided; ready for implementation and testing. Legacy-data audit and validation guards pending. | Occupancy and completeness diverge for inconsistent/out-of-contract core identities. | Original failure requires an external-range ID without the corresponding customer number; conforming rows avoid it. |
| F05 | Conditional | Open — separate reservation table decided; implementation and migration pending. | Synthetic reservation IDs can conflict with or mask out-of-contract real identities. | Valid CDP IDs cannot overlap reservation IDs; mixed row semantics remain a design concern. |
| F06 | High | Open — source-ID preflight required; implementation pending. | Null IDs and the zero sentinel permit invalid or silently skipped assignments. | Confirmed code paths; supplied real-ID domain is known, but schema enforcement is unverified. |
| F07 | Medium | Accepted behavior — earlier fallback requirement reversed October 19; preservation/regression verification pending. | Dual ranking has no fallback to another external candidate. | Confirmed original behavior; the current decision explicitly retains it. |
| F08 | Medium | Open — null-date priority decided; implementation pending. | Null source dates can outrank known dates. | Confirmed dependence on Snowflake null-ordering settings; the recorded decision requires null dates to have lowest priority. |
| F09 | Medium | Open — prepared-population contract decided; implementation and verification pending. | Different stages can evaluate different source states. | Confirmed repeated reads; impact requires concurrent source changes. |
| F10 | Medium | Open — reporting contract defined in REPORTING.md; ready for implementation and testing. Procedure integration with the existing harness and Snowflake verification pending. | `SUCCESS` does not distinguish preview, inserted rows, or rejected rows. | Confirmed output-contract gap. |
| F11 | Medium | Open — unsigned-integer PK1 rule decided; implementation and verification pending. | Numeric conversion is more permissive than integer-identifier validation. | Confirmed conversion semantics; the recorded unsigned-integer rule requires validation before adoption. |
| F12 | Medium | Open — error-handling scope decided in REPORTING.md; ready for implementation and testing. Guarded handling and Snowflake verification pending. | Failure diagnostics are temporary and can obscure the original exception. | Confirmed unguarded diagnostic work in the handler. |
| F13 | High | Open — target-account compilation verification or correction pending. | Candidate eligibility uses a correlated EXISTS outside its documented supported location; one IF also omits documented parentheses. | Documentation-backed compilation risks; no account execution performed. |

## Detailed findings

### F01 — Non-active status predicate violates the confirmed encoding

**Evidence:** Lines 83–99, especially the TODO at 92 and comparison at 93; dependent eligibility at 115–120 and validation at 390–397.

```sql
--TODO: 'NON_ACTIVE' not '-'
AND UPPER(IFNULL(pp.PARTY_PROFILE_STATUS_CODE, '')) = '-'
```

The comments and exception describe `NON_ACTIVE`, while the predicate recognizes only a hyphen. A literal `'NON_ACTIVE'` value does not enter the blocked-number set and can receive `CN_ELIG_FLAG = 1`. The later check consumes the same incorrect set, so it cannot catch this mismatch. Null, blank, and other status values are also not blocked. Their status eligibility agrees with the settled target rule: only exact `NON_ACTIVE` is excluded; no active-status whitelist is required.

**Counterexample:** Empty core; individual 7 has ICON PK1 `'42'`, status `'NON_ACTIVE'`. The logic proposes `(7, 42, 'new_external_cust_num')` and can pass its checks. With status `'-'`, it instead reserves 42 and generates a CDP number for individual 7.

**Recorded decision and recommendation (settled October 19):** Only the exact `PARTY_PROFILE_STATUS_CODE` value `NON_ACTIVE` is excluded. Every other value is eligible under the status rule: NULL, empty strings, whitespace, hyphens, case variants, and any other string. Apply exact comparison without trimming, case folding, or an active-status whitelist. No status-eligibility policy remains unresolved. Any qualifying exact `NON_ACTIVE` ICON or MAO occurrence prevents all new assignments of that numeric PK1 across individuals and both sources; another occurrence with any eligible status cannot override the global block. Other ID, number, occupancy, and reservation rules still apply. The decision addresses new assignments and does not direct revocation of existing ones.

**Acceptance:** Verify exact `NON_ACTIVE` is excluded, while NULL, `''`, whitespace, `'-'`, `'ACTIVE'`, `'non_active'`, `'Non_Active'`, `' NON_ACTIVE'`, `'NON_ACTIVE '`, and arbitrary other strings pass the status rule. Test the same numeric PK1 across individuals and ICON/MAO with both excluded and eligible occurrences: the qualifying exact `NON_ACTIVE` occurrence blocks all new assignments of that value. Policy is settled; implementation and Snowflake verification remain pending.

### F02 — Transaction boundaries do not match the apparent control flow

**Evidence:** `BEGIN TRANSACTION` at 14; CTAS starting at 29 and throughout the block; another `CREATE OR REPLACE TEMPORARY TABLE` at 429; insert at 458; commit at 479; rollback at 486.

Snowflake DDL, including CTAS, commits an active transaction and runs separately. With default autocommit, subsequent DML outside an explicit transaction commits when successful. Stored-procedure transaction scope also constrains where transactions can start and end. [S1]

**Implication for this code:** The first CTAS ends the apparent opening transaction. The later reject-table creation occurs immediately before the live-write branch. Under default settings, the core insert commits as its own statement; the final `COMMIT` does not establish an encompassing transaction retroactively. The handler cannot undo already committed work.

There is only **one persistent core insert** in the supplied block. This finding does not mean that insert commits partially or that multiple current core updates can become inconsistent within one run. It means the source presents a rollback boundary it does not actually provide, and it is unsafe to extend it with additional persistent writes on that assumption.

**Recorded decision and implementation plan (October 19):** Use permanent staging tables deployed before the procedure runs, with one DDL file per required table in `dw/STANDARDIZE_STAGE/Tables`. Replace runtime table creation/CTAS with DML into those tables, including reject and exception-diagnostic paths. Use `RUN_ID` to isolate rows and scope reads, joins, and final cleanup. Settled D05.2 adds defensive truncation of all dedicated work tables after lock acquisition and before source capture, within the same transaction; this deliberately removes stale rows across run IDs. Do not create, replace, or drop staging objects during execution. The coordinator owns begin/commit/rollback and acquires the F03 lock before reading the target baseline or allocation seed, then retains it through planning, validation, and apply. See the [staging deployment plan](../plan-refactoring.md#f01f03-implementation-deliverables).

**D05.2 decision (October 19, option A with defensive startup truncate):** Retain no successful-run staging rows. Immediately after acquiring the shared generation lock, and before source capture or populating work tables, `TRUNCATE TABLE` each explicitly inventoried, predeployed work table dedicated to this procedure. This startup cleanup intentionally removes stale rows across all run IDs; it is the sole exception to run-scoped staging DML. Never truncate source, CORE assignment/reservation, process control, or audit/reporting tables. Perform the truncates in the coordinator transaction while holding the gate; no early commit or unlocked cleanup. All generation modes use this ordering. After live validation/apply reconciliation, capture required report values in procedure state and delete the current run's work rows before commit. Cleanup failure fails the invocation and rolls back its transaction. Preview/failure rollback undoes both startup truncation and new staging writes, so pre-existing stale rows can reappear; do not promise durable cleanup after rollback. No staging-retention period or scheduled cleanup job is required. Durable reporting remains separate.

**D05.3 decision (October 19, option A):** Require no open caller transaction when invoking generation, for live and preview alike. The caller must finish its transaction before the call; the coordinator begins and completes its own business transaction. Reject an invocation with an already-open caller transaction before acquiring the generation gate, truncating work tables, preparing source data, or applying business writes. Never commit or roll back caller-owned work to satisfy this precondition. Preserve the error through the existing harness; any reporting of rejected entry must use the D07 independent logging contract without modifying the caller transaction. Dedicated caller-transaction rejection tests are excluded under the accepted reduced scope. The AUTOCOMMIT requirement is settled separately under D05.4; D05.3 does not replace the separate D07 audit transaction design.

**D05.4 decision (October 19, option A):** Require the caller session to have `AUTOCOMMIT = TRUE` before invoking generation, for live and preview alike, in addition to D05.3's no-open-caller-transaction requirement. `AUTOCOMMIT = FALSE` is unsupported and must not proceed into generation work. The coordinator still explicitly begins and completes its business transaction; enabled autocommit does not make the statements inside that transaction commit individually. Do not enable or change AUTOCOMMIT inside the procedure or commit caller-owned work to satisfy the contract. Configure the required setting for qualification; direct-entry enforcement tests are excluded under the accepted reduced scope. Do not assume session-inspection commands are available under every rights mode. The setting does not replace the separate D07 durable-logging design.

**D05.5 decision (October 19, option A):** Retain `EXECUTE AS OWNER` for the public generation procedure, matching the supplied `GENERATE_CUST_NUMS.prod.sql` wrapper. Use the procedure owner's privileges for underlying data operations; callers need the appropriate procedure, database/schema, and warehouse access, without requiring direct privileges on every underlying table. Record the actual owner role and required grants as deployment configuration. The dedicated owner/non-owner, caller-transaction, AUTOCOMMIT, timeout, and logging-failure suites are excluded with accepted risk; only the path needed for serialization is qualified. Do not assume caller-session inspection or session changes are available under owner rights. The rights policy is settled; target-account verification and grants remain implementation/deployment work. Database/schema resolution is settled separately under D05.6.

**D05.6 decision (October 19, option A):** Resolve data objects relative to the database containing the deployed generation procedure, under settled `EXECUTE AS OWNER`. Keep explicit two-part `SCHEMA.OBJECT` references, using `STANDARDIZE_CORE`, `STANDARDIZE_STAGE`, and `STANDARDIZE_AUDIT` in that same database. Apply this convention to source/target tables, work-table truncation and cleanup, process control, process logging, and helper calls. Do not introduce caller-selected database routing or environment-specific database literals inside the procedure body. Deployment selects the environment database and installs the procedure and required objects there; callers can use a fully qualified procedure name to select the intended deployment. Verify calls made while the caller has a different current database/schema still use only the called procedure's environment. D05 policy is fully settled; actual environment names, grants, implementation, and target-account verification remain deployment/qualification work.

**D06.1 decision (October 19, option A):** The caller explicitly supplies the invocation's `FEED_INSTANCE_ID`, `AUTOMATION_GUID`, and a Boolean preview flag. TRUE means preview and FALSE means live. Use the existing harness-issued identifiers; generation creates neither identifier, does not derive them from source rows, and does not look up `FEED_INSTANCE` to obtain a missing automation identifier. `RUN_ID` remains exactly `FEED_INSTANCE_ID`. Require both identifiers and an explicit non-null mode before generation work; missing identity or mode must not fall through to live processing. Use the supplied invocation feed for generation audit fields under the existing provenance decisions. Verify parameter binding with the actual harness; this records the procedure input contract without redesigning the shared harness framework. Procedure-specific invocation SQL/binding must change from the production zero-argument call; the implementation plan defines caller/signature cutover. Automation identifier width and caller return value are settled under D06.2 and D06.3.

**D06.2 decision (October 19, option C supplied by user):** Use `VARCHAR(36)` for the `AUTOMATION_GUID` procedure input contract and the new `CUST_NUM_PROCESS_LOG` column. The identifier is externally supplied and the user has verified this contract as correct; its width and external correctness are settled, not outstanding discovery or approval items. Preserve the supplied value without truncation, normalization, or regeneration. Do not add UUID-format validation or widen the new contract based on the existing audit tables' larger capacities. Leave existing `AUTOMATION_LOG` and `FEED_INSTANCE` definitions unchanged. Implementation verification covers parameter binding and unchanged propagation into reporting; it does not reopen the confirmed identifier contract.

**D06.3 revised decision (October 19, user-approved SQL-only revision):** Add a required fourth argument `RESULT OUT VARIANT`. It returns the versioned JSON outcome specified in REPORTING.md: supplied invocation identity, mode, SUCCESS/ERROR status, business persistence, stage, original error details, and caller action. Handled failures return ERROR JSON; successful calls return SUCCESS JSON. The scalar VARCHAR return mirrors the JSON status as SUCCESS or ERROR. A successfully executed CALL is not sufficient evidence of business success. The harness/RPDM must inspect and log the JSON, stop downstream processing on ERROR, and reconcile COMMITTED or UNKNOWN errors before any retry. Errors outside the handler still use the SQL-error path. This supersedes the earlier SUCCESS-only/no-structured-response and mandatory rethrow contract. Procedure-specific caller binding and outcome handling are in scope; shared harness framework redesign remains out of scope.

**D07.1 retained implementation decision; reduced verification (October 19):** Keep the dedicated audit-only scoped-transaction helper for all CUST_NUM_PROCESS_LOG writes. The coordinator owns the business transaction and retains its generation gate through planning, validation, apply, and commit/rollback; the helper must not access source, work, assignment, reservation, or process-control objects. Initial/in-progress reporting failure prevents apply; a handled post-commit reporting failure returns ERROR JSON with COMMITTED persistence. Preserve the original error through secondary failures. Dedicated logging/transaction fault suites are excluded with the user accepting the resulting lack of qualification; verify only the logging path needed to demonstrate serialization. Excluding tests does not remove these implementation requirements.

**D08.1 decision (October 19, option A):** Update affected consumers for the separate assignment/reservation model as part of the controlled cutover. Consumers read genuine assignments from XREF and reservations from `STANDARDIZE_CORE.CUST_NUM_RESERVATION` where needed. Inventory actual consumers, update and verify those affected, and deploy their compatible versions with the migration before enabling generation callers. Do not introduce a temporary compatibility view that recreates legacy combined/synthetic rows or an independent dual-writing allocator. Consumer readiness is a cutover prerequisite; discovering the inventory and proving compatibility remain implementation work. Existing evidence-based classification, separate remediation, D03.5 reservation-audit reconstruction, and F04 unresolved-data blocking remain unchanged. D04.2 still requires no detection or response to lost generated-assignment history. D08 policy is settled; migration evidence, consumer changes, and cutover/recovery qualification remain pending.

**Acceptance:** Verify deployment supplies every referenced staging table, execution contains no runtime DDL, run rows cannot mix, and `AUTOCOMMIT = TRUE` with no open caller transaction preserves rollback after injected failures following business DML. Under D05.4, verify FALSE cannot proceed into generation work and is not silently changed to TRUE. Under D05.3, verify calls with an open caller transaction fail before gate acquisition or staging/business work, leaving that transaction and its prior work under caller control. Check diagnostic failure handling, locked startup truncation of stale work rows, current-run cleanup before live commit, and cleanup-failure rollback. Prove a waiting invocation cannot truncate the active invocation's work, and preview/failure rollback restores any pre-existing stale rows. Exclude source, CORE, process control, and audit/reporting tables from staging cleanup. No DDL files or procedure changes are implemented by this planning update.

### F03 — Concurrent runs can allocate or insert the same keys

**Evidence:** Seed captured at 28–36, occupied keys at 39–64, new individuals at 67–81, live duplicate checks at 354–377, and final filtering against the **earlier** `cnxi_taken` snapshot at 465–476.

Two overlapping executions can observe the same maximum and both allocate the same next customer number. They can also both decide that the same individual or external number is absent. Even the later checks leave a race between validation and insertion; the final filter does not inspect newly committed core rows.

On ordinary Snowflake standard tables, declared primary-key and unique constraints are not enforced. The target table type was not supplied, so constraints cannot be assumed to close this race. [S2]

**Counterexample schedule:** Runs A and B read seed 500000010, each plan customer number 500000011, each validate before the other inserts, then both apply. With unenforced uniqueness and no external serialization, conflicting rows can be stored. Identical staged mappings can also be inserted twice.

**Recorded decision and implementation plan (October 19):** Serialize all CUST_NUM generation instances using a lock on a new `STANDARDIZE_AUDIT.CUST_NUM_PROCESS` table. Deploy the table and a single shared control row before invocation; plan its DDL in `dw/STANDARDIZE_AUDIT/Tables/CUST_NUM_PROCESS.sql`. Begin the coordinator-owned transaction and perform a real `UPDATE` of that row before any target baseline/seed reads. Verify exactly one row was affected; a missing or duplicate control row is a fatal deployment error. All generation instances, including previews, use the same gate. Hold the lock until commit or rollback; a waiting run reads fresh state only after acquisition. D05.1 is settled (October 19, option A): allow up to 60 seconds to acquire the generation lock in live and preview; this is not a total execution limit. A lock timeout or acquisition failure must stop the run before source preparation, allocation, or business writes. This is a proposed locking protocol requiring target-account validation, not an implemented guarantee. [S1]

**Accepted risk:** Writers outside CUST_NUM generation may bypass this gate and change assignments, reservations, or allocation state concurrently. The process-table lock does not protect those tables from nonparticipating writers. Duplicate/conflicting assignments or stale decisions from such writes remain an explicitly accepted risk; this work does not require external writers to adopt the protocol. Required integrity checks remain, but cannot eliminate that race.

**Acceptance:** Use two real Snowflake sessions to show that run B waits at the process-table update while A holds the transaction, then reads A's committed state before planning. Cover the same new individual, different individuals sharing a seed, competing external numbers, preview/live overlap, rollback, the D05.1 60-second lock-wait limit, and missing/duplicate control rows. Verify release before the limit permits progress and holding beyond it fails the waiting invocation. Confirm lock release on commit/rollback and that failure never falls through to allocation. Observe a bypass writer separately as accepted-risk evidence, not as a serialization guarantee or a required prevention test.

### F04 — Occupancy and completeness can diverge for invalid or legacy data

**Evidence:** `cnxi_taken` combines both key columns, lines 46–64. External candidates and reservations exclude any matching value, lines 159–164, 207–212, and 240–245. Completeness subtracts only `CUST_NUM`, lines 400–419.

**Out-of-contract counterexample:** Core contains `(INDIVIDUAL_ID = 42, CUST_NUM = 500000001)`. A new individual 7 supplies external PK1 42. The value is excluded because it is an occupied individual ID. No branch reserves it. Individual 7 receives a generated proposal, but completeness still demands a core or staged **customer number** 42 and raises `-20007`.

Under the supplied domain, real individual 42 is invalid. For conforming rows, real IDs exceed all customer numbers, while a reservation ID already appears in its own `CUST_NUM` column. Therefore the two occupancy predicates agree for external values. The unused branch's exclusion of new real IDs cannot match a valid external number, and generated customer numbers cannot collide with valid real IDs either.

**Recorded decision (October 19):** Fail preflight on unresolved CORE integrity violations and handle remediation separately. Stop the entire invocation before assignment planning or business writes; do not continue by filtering or quarantining the violating rows. This applies to invalid real-assignment `INDIVIDUAL_ID` values, malformed legacy reservations, unresolved null/unrecognized `REC_TYPE` values, and other required CORE integrity-check failures. No automatic repair, deletion, or historical identity reassignment is authorized by this decision.

**Implementation and acceptance:** F04 is ready for implementation and testing. Validate the supplied real-ID domain and audit legacy core rows by record type. Require legacy synthetic reservations to carry the same valid external number in both keys before migration. In the target model, check external coverage across genuine XREF assignments and the new CORE reservation table; do not require a reservation to have an individual ID or weaken coverage to accommodate invalid identities. Simplify occupancy after migration and reconciliation establish those invariants. Verify that unresolved CORE violations fail both preview and live preflight without business writes, valid legacy reservations are not subjected to the real-ID domain check, and separately remediated data passes on a later invocation. The legacy audit, implementation, and Snowflake verification remain pending.

### F05 — Reservation rows impersonate real individual IDs

**Evidence:** Synthetic keys at 185–186, 201–202, and 221–222; only the unused branch checks new real IDs, lines 264–269. Discovery of new individuals ignores `REC_TYPE`, lines 74–79.

The original collision/masking cases below require a real identity outside the supplied CDP range:

| Case | Minimal setup | Result |
| --- | --- | --- |
| Same-run collision | Individual 7 prefers external 11 and has older external 42; real individual 42 also needs a generated number. | Merged reservation `(42,42)` and the real assignment both have individual ID 42. Stage validation raises `-20013`. |
| Non-active same-run collision | Blocked external 42 is reserved while real individual 42 also needs a number. | The non-active branch causes the same duplicate-ID failure. |
| Future identity masked | Core already contains reservation `(42,42)`; a genuine individual 42 arrives later. | `cnxi_new_ind` excludes the real individual because an ID 42 already exists. No genuine new assignment is created. |

All three cases require genuine individual 42, which is outside `100000000000–199999999999`. They cannot occur for conforming CDP-generated identities. The source does not enforce this domain, so the examples remain useful invalid-input/legacy-data fixtures rather than evidence of a normal identity collision.

**Recorded decision and recommendation:** Require preflight validation of `PARTY_PROFILE.INDIVIDUAL_ID` and move reservations to a new table in `STANDARDIZE_CORE`, keeping real assignments in XREF. This separation is now a business requirement even though conforming IDs do not collide. Audit historical rows by record type and domain before migration; do not apply the real-ID range check to legacy synthetic reservations.

### F06 — Required IDs are not validated, and null is conflated with zero

**Evidence:** No `IS NOT NULL` predicate on new individuals at 69–80; nullable stage columns at 299–306; `IFNULL(...,0)` in reject joins and final insertion filters at 441–445 and 470–475.

`NOT EXISTS` correctly avoids the broad null poisoning associated with `NOT IN`, but it does not make a null individual ID valid. One null ID can be grouped, assigned a generated number, and pass uniqueness checks. Actual insertion may fail later if target DDL enforces non-null, or may store an invalid mapping if it does not.

The zero sentinel introduces a second path. If core contains individual ID 0, a staged null individual is treated as an existing zero-valued individual. The row enters `cnxi_insert_rejects`, the final insert skips it, and the routine can still return `SUCCESS`.

**Counterexample:** Core `(0, 600000001)`; one PARTY_PROFILE row with null individual ID from another source. Stage can contain `(NULL, 500000001)`, then reject it as `individual_id_exists`. No assertion rejects the nonempty reject set.

**Recorded decision and recommendation:** Require a preflight check on `PARTY_PROFILE.INDIVIDUAL_ID`: every retained source ID in the input population must be a non-null integer in `100000000000–199999999999`, including rows for already mapped individuals. A failed check prevents success. Apply separate migration checks to legacy core reservations. The existing null/zero example is an invalid-data case, and the block itself provides no such domain guard. Use direct key comparison after non-null validation instead of inventing an equality between null and zero. Assert assignment coverage and reconcile staged, accepted, rejected, and inserted counts. Treat unexpected rejected assignments as errors.

### F07 — Ranking does not implement “best available alternative”

**Evidence:** Independent window rankings at 137–156; both ranks must equal 1 at 177–179; lower-ranked candidates are reserved at 191–193; remaining individuals receive CDP numbers at 285–290.

**Counterexample:** Individual 7 has external 101. Individual 8 prefers 101 but also has lower-ranked 102. Individual 7 wins 101 because its ID is lower. Individual 8 does not retry with 102; 102 is reserved as merged and individual 8 gets a generated number.

This is a confirmed consequence of the reviewed code. The earlier decision to add fallback was reversed on October 19; this no-fallback outcome is now accepted target behavior.

**Recorded decision — superseding the earlier fallback approval (October 19):** Retain original dual-ranking selection. Select an eligible external candidate only when both `EXTERNAL_RANK = 1` and `CUST_NUM_RANK = 1`. Do not retry lower-ranked candidates, rerank after removing winners, displace winners, or rearrange assignments to maximize external-number usage. New individuals without a selected external assignment receive generated numbers, even when an otherwise eligible alternative exists. Finalize reservations for eligible unassigned values after selection; the separate CORE reservation table and all other approved corrections remain required. Existing assignments remain unchanged.

**Acceptance:** Preserve the example's original selection result: individual 7 receives 101, individual 8 receives a generated number, and 102 is reserved in the target CORE reservation table. Verify multiple conflicts, both-rank eligibility, and no iterative reassignment. Duplicate/tie handling must preserve selection semantics and provenance, with the approved eligibility and `NULLS LAST` corrections. This is a policy reversal accepting the original no-fallback behavior, not evidence of implemented or verified refactoring.

### F08 — Missing dates can win the “newest” preference

**Evidence:** `t_src_create_date DESC` at 143 and 154, with no `NULLS FIRST` or `NULLS LAST`.

With Snowflake's default `DEFAULT_NULL_ORDERING = LAST`, descending order places nulls first. The outcome can change when this setting changes. [S3]

**Counterexample:** Individual 7 has external 101 with a null creation date and external 102 with a known date. Under default ordering, 101 wins. The code therefore does not unambiguously mean “newest known record.”

**Recorded decision and recommendation:** Null source dates have lowest priority. Specify `NULLS LAST` in both preference and ownership date ordering and verify independence from session settings. Add a stable source-record tie-breaker if record-level lineage matters and such a key exists. Exact duplicate input rows do not by themselves prove duplicate output: `CUST_NUM_RANK = 1` still selects only one row per external value.

### F09 — Source reads are not one frozen input population

**Evidence:** Independent reads of PARTY_PROFILE at 73, 89, 121, 230, and 404; core snapshots and later live checks are also taken at different points.

Successive Snowflake statements can see different committed states, even within a transaction. [S1]

**Impact:** A newly arriving external value can appear in completeness after all reservation tables were built, producing an avoidable failure. A status update after the blocked-number set is captured can leave later checks using an obsolete classification. The local occupancy table is a snapshot of one query, not a coordinated snapshot of the whole run.

**Recorded decision and implementation plan (October 19):** Materialize the required `PARTY_PROFILE` columns once into predeployed permanent staging scoped by `RUN_ID`, after acquiring the F03 process-table lock. Preserve rows needed for all individuals and external-number coverage, including already-mapped individuals and all sources needed for individual discovery. Run source-ID preflight against that population before excluding invalid IDs: invalid IDs must fail validation rather than disappear through a filter. Normalize PK1 and classify status once using the settled exact-exclusion rule, preserving raw values and diagnostic classifications. Derive assignments, ranked external candidates, reservations, and source-based self-checks from those prepared relations without rereading `PARTY_PROFILE`. Record the captured population's source identity. Target integrity and apply reconciliation still check the target under the F03 contract; the accepted external-writer risk remains.

**Acceptance:** Include invalid IDs on new and already-mapped individuals, external numbers on already-mapped individuals, and non-ICON/MAO rows needed for discovery. Change source rows after materialization and verify that every source-based decision/check uses the captured population. Confirm invalid IDs remain visible to preflight and raw PK1/status values remain available for diagnostics. This decision does not establish live implementation or snapshot-test evidence.

### F10 — Success and rejection reporting are insufficient

**Evidence:** Literal preview default at 12, temporary rejects at 429–449, optional apply at 453–478, unconditional `RETURN 'SUCCESS'` at 481.

The caller cannot distinguish a preview from a committed live run using the return value. No inserted, accepted, rejected, or per-record-type counts are returned. Rejects are not asserted to be empty. Under stable, non-null inputs, most ordinary same-column conflicts already raise errors before reject classification, so the reject table is not a complete conflict report for all failure paths.

Ordinary temporary tables are session-local and disappear when the session ends. They are not durable operational evidence. [S4]

**Recorded decision:** Success means an error-free run without any failed preflight or self-checks. Any error or failed required check prevents success. A no-work run may succeed when all checks pass; persistence is not implied by a successful preview.

**Reporting contract and readiness (October 19):** [REPORTING.md](../REPORTING.md) defines the compact reporting contract and supersedes the earlier recommendation for broader routine counts. F10 is ready for implementation and testing; procedure integration with the existing harness and Snowflake verification remain pending; harness changes are out of scope. Store one durable `STANDARDIZE_AUDIT.CUST_NUM_PROCESS_LOG` row per invocation, preserving retries, and reuse the existing feed and automation records for execution outcome, timing, and errors. Report mode, validated assignment/reservation plan counts, allocation metrics, business persistence, and failed or unexecuted required checks as specified there. Unknown counts remain null; plan counts represent committed counts only after commit is confirmed. Preview must not advance allocation state or persist business assignments/reservations. Reconcile external assignments, generated assignments, and CORE reservations separately before live commit; finalize reservations after dual-ranking selection completes.

**Implementation and acceptance:** Use `RUN_ID = FEED_INSTANCE_ID`; each retry has distinct automation, feed, and process-log identifiers without correlation between attempts. Implement settled D06.1–D06.3: explicit feed/automation/preview inputs, externally supplied `VARCHAR(36)` automation identifier, and the revised versioned JSON OUT result; the procedure-specific caller logs SUCCESS/ERROR and stops or reconciles failures. Define stable check IDs within the existing harness contract. Integrate durable logging with F02/F03 transaction ownership and F12 error handling. Verify preview, zero-work, failed/unexecuted checks, apply-count mismatch, retries, JSON outcome handling, and serialization. Dedicated rollback, uncertain-commit, and audit-failure tests are excluded with accepted risk. Logging failures must preserve the primary error and must not trigger blind reapplication. This reporting decision does not establish implemented or verified behavior.

### F11 — Numeric casting can alter an external identifier

**Evidence:** Repeated `TRY_CAST(SOURCE_SYSTEM_PK_1 AS NUMBER(38,0))`, including 87, 111, 228, and 403.

Snowflake numeric casts round when the target scale is insufficient. `TRY_CAST` provides conversion-error handling, not a digits-only input rule. [S5, S6]

**Impact:** A fractional string such as `'42.4'` can become 42, while `'42.6'` can become 43. Leading-zero variants normalize to the same number. This may be intentional, but it can also assign or retire a number different from the supplied identifier. Malformed values are dropped from external handling without a specific diagnostic.

**Recorded business rule (October 19):** A PK1 used as an external customer number must represent a valid unsigned decimal integer and satisfy the existing external customer-number range restrictions. Leading zeros normalize numerically. Signs, decimal notation, and exponent notation are not valid identifier syntax. Invalid PK1 excludes that external candidate; it does not remove the source row from ID preflight/discovery or make an otherwise valid individual ineligible for generated assignment.

**Implementation plan:** Combine `REGEXP_LIKE` with successful `TRY_CAST` in the F09 preparation layer, retain raw values and rejection reasons, and apply range/availability checks separately. Use the expression in the [F09/F11 implementation plan](../plan-refactoring.md#f09-and-f11-prepared-input-and-pk1-validation). Confirm the source column is a string as required by `TRY_CAST`. [S6] The business rule is settled; implementation and Snowflake verification remain pending.

**Acceptance:** Accept digit strings and normalize leading zeros; reject signs, fractions, exponents, embedded spaces, empty strings, NULL, and conversion overflow. Distinguish syntax validity from range eligibility: `0` is an unsigned integer but is not an eligible external customer number. Verify an invalid PK1 cannot create an assignment/reservation for a rounded numeric value, while a valid individual remains eligible for generated assignment.

### F12 — Exception handling can replace useful failure information

**Evidence:** Lines 483–495 unconditionally attempt rollback, create another temporary table, and then rethrow.

If the original error involves source access, the diagnostic query can fail for the same reason. If diagnostics fail, the final bare `RAISE` is not reached. The diagnostic table only lists IDs still absent from core; it does not identify duplicate keys, conflicting reservations, missing external coverage, or the stage that failed. It also has no run ID. In a reused session, tables from earlier attempts can be mistaken for current diagnostics after an early failure.

**Recorded decisions and readiness (October 19):** [REPORTING.md](../REPORTING.md#25-f12-error-handling-decisions-october-19) settles the F12 scope. Capture original error code, state, message, and stage before diagnostic work, if any. Protect rollback and logging so secondary failures cannot replace the original runtime SQL error. The procedure-specific harness/RPDM caller captures the JSON outcome and any escaping SQL error; shared framework redesign is out of scope. `RUN_ID` equals `FEED_INSTANCE_ID`. Each retry has different `AUTOMATION_GUID`, `FEED_INSTANCE_ID`, and `CUST_NUM_PROCESS_LOG_ID` values; no correlation between retry attempts is required. Persisted bounded, rule-specific samples are out of scope, superseding the earlier sample recommendation. Use the compact run summary and failed/unexecuted-check reporting defined in REPORTING.md, with failure reporting preserved outside business rollback.

**Implementation and acceptance:** F12 is ready for implementation and testing. Capture the original exception before any secondary work, guard rollback and reporting, and return the original details in ERROR JSON for procedure-specific harness/RPDM logging and action; preserve an outer SQL-error fallback. Remove the dependency on the generic exception debug extract; do not add persistent sample storage. Verify caught business-error JSON, caller action, and distinct retry identities. Secondary rollback/logging and post-commit fault tests are excluded under the accepted reduced scope; the implementation still must preserve original errors and truthful persistence. Implementation and Snowflake verification remain pending.

### F13 — Resolve compilation-sensitive constructs before behavioral testing

**Evidence:** The `CASE WHEN EXISTS` expression at lines 115–120 references the outer `pp.SOURCE_SYSTEM_PK_1`. The preview guard at line 453 is `IF NOT what_if THEN`.

Snowflake documents correlated `EXISTS` subqueries as supported only in a `WHERE` clause. This correlated expression is in the SELECT list's `CASE`, outside that documented support. [S8] Treat it as a potential unsupported-subquery compilation blocker until verified or rewritten on the target account; no actual Snowflake error was observed in this review.

**Recommended rewrite:** Join the candidate source to `cnxi_nonactive_cust_num` on the parsed customer number and derive eligibility from `CASE WHEN na.CUST_NUM IS NOT NULL THEN 0 ELSE 1 END`. The existing blocked-number relation is grouped by number and excludes null/out-of-range values, so one left join can preserve the membership semantics without multiplying candidate rows. Keep the status-rule correction separate from this structural change.

The IF reference documents `IF ( <condition> ) THEN`. [S7] Normalize line 453 to `IF (NOT what_if) THEN` and verify the complete block with the actual execution client and procedure wrapper. This is a syntax compatibility concern, not a reproduced parser failure.

**Acceptance:** Compile and run the candidate CTAS and a harmless preview in an isolated Snowflake test schema. Verify both blocked and unblocked membership and candidate row counts. Local relational models cannot establish acceptance of either SQL construct.

## Other observations and strengths

### Useful elements to retain

- Explicit column lists on both inserts avoid dependency on target column order.
- `NOT EXISTS` avoids null poisoning across an entire anti-join population.
- The materialized `cnxi_taken` set retains separate `IS_CUST_NUM` and `IS_INDIVIDUAL_ID` flags. Keeping that provenance is necessary when same-column collision semantics differ from external eligibility.
- Range exhaustion and output uniqueness are checked before the core insert.
- Separate record types expose why rows were created, even though the underlying model mixes responsibilities.
- Error conditions have distinct numeric codes, which can become a stable validation interface.

### Allocation boundaries and retention

The seed is the maximum **currently retained** CDP-range customer number, floored at 500000000. It is not a separately persisted historical maximum. The no-reuse guarantee therefore depends on retained history and control of other writers. Deleting the greatest allocated value can make it available again. The recorded decision confirms that 500000000 is reserved and never assigned; initial allocation remains 500000001, and validation must exclude the reserved value. The [business assessment](../README.md#number-domains) records the original omission in a footnote.

The supplied retirement rule is also now explicit: an eligible PK1 left unassigned after successful processing becomes ineligible for future assignment. Persist this in the new CORE reservation table after dual-ranking selection completes. D03.1 is now settled (October 19, option A): committed `NON_ACTIVE` reservations also remain permanently unavailable after source correction, status change, or removal. No automatic or built-in administrative release path is included; exceptional data remediation remains separate. Verify this permanence on subsequent invocations. D04.1 retains the XREF-derived seed without a separate counter; settled D04.2 requires no detection or response to generated-assignment history loss, including known loss.

**D03.2 decision (October 19, option A):** Retain the exact reservation reason values `nonactive_external_cust_num`, `merged_external_cust_num`, and `unused_external_cust_num`. For a new reservation, classify a qualifying exact `NON_ACTIVE` value as `nonactive_external_cust_num`; otherwise use `merged_external_cust_num` when the eligible candidate has `EXTERNAL_RANK > 1` and `CUST_NUM_RANK = 1`; otherwise use `unused_external_cust_num` for remaining valid, unoccupied external values not assigned or reserved by another branch. Exclude existing assignments/reservations and final new assignments before creating reservation rows. Each newly reserved number has one reason. The `merged` label does not establish a person merge or surviving-individual link. Preserve these exact values for validated legacy reservations during migration; F04 still blocks malformed or unclassified rows.

**D03.3 decision (October 19, option A):** Existing reservation rows are immutable during normal generation. Preserve the original reason, creation date, feed attribution, and any stored creation/run metadata. Later observations, including a new exact `NON_ACTIVE` occurrence, do not update the row, append another reservation for the same number, or release the number. The reason records why the number was first reserved, not its latest observed status. Reprocessing is insert-only for newly reserved numbers; exceptional data remediation remains separate.

**D03.4 decision (October 19):** Use `STANDARDIZE_CORE.CUST_NUM_RESERVATION` with `CUST_NUM`, `REC_TYPE`, `CREATE_DATE`, `CREATE_FEED_INSTANCE_ID`, `ORIGINATING_FEED_INSTANCE_ID`, and `SOURCE_PARTY_PROFILE_ID`. For new generation rows, `CREATE_DATE` is the reservation creation timestamp and `CREATE_FEED_INSTANCE_ID` is the generation invocation's `FEED_INSTANCE_ID`. Store the selected source row's feed in `ORIGINATING_FEED_INSTANCE_ID` and its source identifier in `SOURCE_PARTY_PROFILE_ID`. For duplicate qualifying sources, select the smallest `SOURCE_PARTY_PROFILE_ID` in string order using its existing VARCHAR type, not numeric order. Carry the originating feed and source identifier together from that selected row; do not combine independent aggregate values from different rows. No separate reservation `RUN_ID` is needed because the invocation is identified by `CREATE_FEED_INSTANCE_ID`; staging/reporting retain their existing run identity contract. D03.3 immutability applies to all six reservation fields.

**D03.4 acceptance:** Distinguish generation invocation feed from selected source feed. Verify duplicate-source selection in string order, including `'10'` before `'2'`, and ensure the source feed and identifier refer to the same qualifying row. Validate required provenance before apply and preserve all reservation fields on later runs. Legacy source attribution must not be copied into the new generation-audit column; settled D03.5 requires evidence-based reconstruction of the historical generation invocation and preservation of the original creation timestamp.

**D03.5 decision (October 19, option B):** Reconstruct historical creation audit for migrated reservations. Preserve the verified original `CREATE_DATE` and populate `CREATE_FEED_INSTANCE_ID` with the actual historical generation invocation's `FEED_INSTANCE_ID`, recovered from supporting audit/history evidence. Do not replace these values with the migration timestamp or migration invocation ID. Do not treat the legacy source-attribution value as proof of the historical generation invocation. Populate `ORIGINATING_FEED_INSTANCE_ID` and `SOURCE_PARTY_PROFILE_ID` from verified source evidence under D03.4, preserving validated original reason values. Retain reconstruction evidence with the migration reconciliation. Missing or ambiguous required audit/source lineage blocks migration acceptance and cutover until separately resolved under F04/D08; do not fabricate values, silently skip unresolved reservations, or weaken the required fields. This settles D03 policy; reconstruction, implementation, and verification remain pending.

**D04.1 decision (October 19, option B):** Retain the original XREF-derived generated-number seed. After acquiring the process lock and passing CORE preflight, read the greatest retained generated `CUST_NUM` in `500000001–599999999`, using `500000000` as the floor when none exists. Allocate sequentially above that seed in individual-ID order; do not fill gaps below it. Add no separate allocation-state table, sequence, or `LAST_GENERATED_CUST_NUM` counter. `CUST_NUM_PROCESS` remains the generation gate, not a historical number counter. Preview and confirmed rollback leave the persisted XREF unchanged and consume no generated numbers. Preventing reuse depends on retaining committed generated-assignment history. The allocator cannot prove that higher historical assignments were deleted merely by inspecting the remaining XREF. Under settled D04.2, do not detect or react to generated-assignment history loss; continue using the retained-XREF seed, including when loss is known. A lost highest assignment can lower the seed and permit reuse.

### Performance hypotheses requiring measurement

The successful path creates 12 temporary tables and reads PARTY_PROFILE through five different stages. Repeated conversion, grouping, ranking, and the all-history coverage check are candidates for consolidation. `UNION` performs distinct elimination across all branch columns; replacing it with `UNION ALL` is safe only after proving branch disjointness and internal uniqueness.

The source comments attribute prior cost to disjunctive joins. The current equality-based occupied-key probes are a sensible structure to retain, but no query profiles were supplied to establish the actual bottleneck or quantify an improvement. Compare elapsed time, bytes scanned, intermediate row counts, sorting/spill, and warehouse cost on representative data before choosing CTEs versus materialized work sets.

### Deployment and provenance

The historical reviewed source references a missing deploy-time column migration; the supplied production source already uses those columns, so verify actual schema requirements instead of assuming that script is required. D05.5/D05.6 now select owner rights and two-part object references within the procedure's deployment database, independently of caller current database/schema. Confirm the procedure signature, deployed owner/grants, source types, target constraints, scheduler, and consumer contract before implementation; verify the selected database-resolution behavior in the target account. Feed provenance is an aggregate and does not necessarily identify the winning source record; preserve a source key separately if auditability requires it.

## Verification performed and remaining acceptance tests

The following cases were checked in a local relational model. They are **modeled outcomes of the supplied logic**, not results from executing the stored procedure in Snowflake.

| Case | Modeled outcome |
| --- | --- |
| Literal `NON_ACTIVE` with external 42 | External 42 remains assignable. |
| External 42 exists only as a core individual ID (out-of-contract/legacy row) | Completeness raises `-20007`; not reachable with conforming real assignments and reservations. |
| Merged reservation 42 overlaps new real individual 42 (invalid real ID) | Stage duplicate-ID error `-20013`. |
| Non-active reservation 42 overlaps new real individual 42 (invalid real ID) | Stage duplicate-ID error `-20013`. |
| Out-of-contract real individual 42 arrives after `(42,42)` reservation | No new assignment row is planned. |
| Two individuals prefer 101; loser has 102 | Loser gets a generated number and 102 is reserved. |
| Null individual with existing core individual 0 | Proposal is rejected by the sentinel comparison without a failure assertion. |
| Null date versus known date | Null-date candidate wins under default null ordering. |
| Empty generated range | First generated number is 500000001. |
| Seed 599999999 with one generated assignment needed | Exhaustion error `-20008`. |

Add valid-ID boundary cases (`100000000000`, `199999999999`), invalid neighboring values (`99999999999`, `200000000000`), and null/zero cases for the required source-ID preflight. For legacy migration fixtures, verify that `(42,42)` reservations coexist with genuine assignments for `100000000042` and are classified separately, then migrate reservations to CORE without fabricated individual IDs. These are proposed tests, not new execution evidence.

The recorded decisions require new expected outcomes for `NON_ACTIVE` blocking, null-date priority, and source-ID preflight. F07 now requires preservation of the original no-fallback selection result; the earlier alternative-assignment expectation is superseded. Also verify rejection of `500000000`, migration to a separate CORE reservation table, future exclusion of eligible PK1s retired after successful processing, and failure whenever a required check fails. Keep the original modeled outcomes above as baseline evidence; do not relabel them as passing tests of the target behavior. See the [focused test matrix](../plan-refactoring.md#focused-test-matrix).

Before a live release, resolve the compilation gate in F13 and execute Snowflake tests for those cases, concurrent writers, rollback fault injection, caller transaction scope, source changes during a run, malformed numeric input, deterministic ordering, preview/live outcomes, and unchanged-input reruns. Add a check that every required real individual has exactly one genuine assignment and every in-scope external number has exactly one approved disposition.

## Official platform references

These references substantiate platform semantics; they do not establish the missing business requirements.

- **[S1]** [Snowflake transactions](https://docs.snowflake.com/en/sql-reference/transactions): DDL, autocommit, scoped transactions, and read-committed behavior.
- **[S2]** [Overview of constraints](https://docs.snowflake.com/en/sql-reference/constraints-overview): enforcement differences for standard and hybrid tables.
- **[S3]** [ORDER BY](https://docs.snowflake.com/en/sql-reference/constructs/order-by): explicit and default null placement.
- **[S4]** [Temporary and transient tables](https://docs.snowflake.com/en/user-guide/tables-temp-transient): session lifetime and name precedence.
- **[S5]** [CAST](https://docs.snowflake.com/en/sql-reference/functions/cast): scale reduction and rounding.
- **[S6]** [TRY_CAST](https://docs.snowflake.com/en/sql-reference/functions/try_cast): supported inputs and conversion-error handling.
- **[S7]** [IF in Snowflake Scripting](https://docs.snowflake.com/en/sql-reference/snowflake-scripting/if): documented conditional-statement syntax.
- **[S8]** [Subquery operators](https://docs.snowflake.com/en/sql-reference/operators-subquery): supported locations for correlated EXISTS.
