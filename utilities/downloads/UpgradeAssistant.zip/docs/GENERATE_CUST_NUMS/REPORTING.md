# Durable Run Report for F10 and F12

## SQL-only qualification and JSON outcome revision (October 19)

The user approved a required JSON OUT outcome for harness/RPDM logging and control, and accepted excluding permission/ownership, transaction, timeout, logging-error, and locking tests except those required to validate serialization. This revision supersedes earlier conflicting return/error and qualification requirements; D01–D04/D08 allocation and migration policy is unchanged. Use the [SQL-only runbook](M0/sql-only/README.md), [coverage and accepted gaps](M0/sql-only/COVERAGE.md), and [JSON caller contract](REPORTING.md#json-outcome-and-caller-actions). The original M0 package and CR1 historical ten modeled results remain evidence of their original scope. Both supplied procedure files are unchanged; the new SQL contains M0 fixtures/prototypes only. All Snowflake checks remain NOT_RUN. The reduced M0 gate remains NOT MET pending the required target-account results.

This proposed F10 reporting contract records the validated assignment/reservation plan and whether its business changes were committed. It extends [F10](Reviews/CR1.md#f10--success-and-rejection-reporting-are-insufficient) and [F12 in CR1.md](Reviews/CR1.md#f12--exception-handling-can-replace-useful-failure-information) and follows the [recorded business decisions](README.md#recorded-business-decisions).

This document defines the target reporting design. The table, procedure integration, and Snowflake validation remain to be implemented.

Production-baseline clarification (October 19): the supplied `GENERATE_CUST_NUMS.prod.sql` has a zero-argument, live-only entry point and no process log. Preview, explicit D06 inputs, and this reporting contract are new production capabilities. The [implementation plan](implementation-plan.md#caller-and-signature-cutover) requires procedure-specific invocation SQL/binding updates, signature-specific grants, and retirement of the zero-argument allocator. “Harness changes are out of scope” means no shared framework redesign; it does not exempt these call-site integration changes. Adopt the revised JSON OUT/error contract below. No SQL implementation or live verification is claimed.

## 1. Run identity and outcome

The harness is existing infrastructure. Procedure-specific SQL must consume RESULT OUT VARIANT, log its outcome, and stop on ERROR. The outer caller also captures SQL errors when no usable JSON is returned. Shared framework redesign remains out of scope. The harness running the procedure records the following `STANDARDIZE_AUDIT` tables. Reuse these fields rather than duplicating execution outcome, timing, and error details in the process metrics.

**D06.1 decision (October 19, option A):** The caller explicitly supplies the invocation's `FEED_INSTANCE_ID`, `AUTOMATION_GUID`, and a Boolean preview flag. TRUE means preview and FALSE means live. Use the existing harness-issued identifiers; generation creates neither identifier, does not derive them from source rows, and does not look up `FEED_INSTANCE` to obtain a missing automation identifier. `RUN_ID` remains exactly `FEED_INSTANCE_ID`. Require both identifiers and an explicit non-null mode before generation work; missing identity or mode must not fall through to live processing. Use the supplied invocation feed for generation audit fields under the existing provenance decisions. Verify parameter binding with the actual harness; this records the procedure input contract without redesigning the shared harness framework. Procedure-specific invocation SQL/binding must change from the production zero-argument call; the implementation plan defines caller/signature cutover. Automation identifier width and caller return value are settled under D06.2 and D06.3.

**D06.2 decision (October 19, option C supplied by user):** Use `VARCHAR(36)` for the `AUTOMATION_GUID` procedure input contract and the new `CUST_NUM_PROCESS_LOG` column. The identifier is externally supplied and the user has verified this contract as correct; its width and external correctness are settled, not outstanding discovery or approval items. Preserve the supplied value without truncation, normalization, or regeneration. Do not add UUID-format validation or widen the new contract based on the existing audit tables' larger capacities. Leave existing `AUTOMATION_LOG` and `FEED_INSTANCE` definitions unchanged. Implementation verification covers parameter binding and unchanged propagation into reporting; it does not reopen the confirmed identifier contract.

**D06.3 revised decision (October 19, user-approved SQL-only revision):** Add a required fourth argument `RESULT OUT VARIANT`. It returns the versioned JSON outcome specified in REPORTING.md: supplied invocation identity, mode, SUCCESS/ERROR status, business persistence, stage, original error details, and caller action. Handled failures return ERROR JSON; successful calls return SUCCESS JSON. The scalar VARCHAR return mirrors the JSON status as SUCCESS or ERROR. A successfully executed CALL is not sufficient evidence of business success. The harness/RPDM must inspect and log the JSON, stop downstream processing on ERROR, and reconcile COMMITTED or UNKNOWN errors before any retry. Errors outside the handler still use the SQL-error path. This supersedes the earlier SUCCESS-only/no-structured-response and mandatory rethrow contract. Procedure-specific caller binding and outcome handling are in scope; shared harness framework redesign remains out of scope.

**D07.1 retained implementation decision; reduced verification (October 19):** Keep the dedicated audit-only scoped-transaction helper for all CUST_NUM_PROCESS_LOG writes. The coordinator owns the business transaction and retains its generation gate through planning, validation, apply, and commit/rollback; the helper must not access source, work, assignment, reservation, or process-control objects. Initial/in-progress reporting failure prevents apply; a handled post-commit reporting failure returns ERROR JSON with COMMITTED persistence. Preserve the original error through secondary failures. Dedicated logging/transaction fault suites are excluded with the user accepting the resulting lack of qualification; verify only the logging path needed to demonstrate serialization. Excluding tests does not remove these implementation requirements.

### JSON outcome and caller actions

The target signature is `GENERATE_CUST_NUMS(FEED_INSTANCE_ID NUMBER(38,0), AUTOMATION_GUID VARCHAR(36), PREVIEW BOOLEAN, RESULT OUT VARIANT) RETURNS VARCHAR`. No arguments have defaults. The scalar return mirrors `RESULT:status`; callers must inspect the JSON. The JSON is an outcome envelope, separate from the existing compact process metrics; it does not add metric columns or rule-specific sample storage.

| Field | Contract |
| --- | --- |
| `contractVersion` | Integer `2`. |
| `scope` | `ALLOCATOR` for the future implementation; `M0_PROTOTYPE` for the harmless M0 mechanics prototype. |
| `feedInstanceId`, `automationGuid` | Exact supplied identity. A rejected null input remains JSON null. Generation invents neither identity. |
| `mode` | `PREVIEW` or `LIVE`; null when the supplied mode is invalid. |
| `status` | `SUCCESS` only when the requested operation and required checks/reporting complete; otherwise `ERROR` for a handled failure. |
| `persistence` | `NOT_ATTEMPTED`, `COMMITTED`, `ROLLED_BACK`, or `UNKNOWN`, describing business changes. Never infer rollback from an error status. Successful preview uses `NOT_ATTEMPTED`. |
| `stage` | Completion or the stage where the original failure occurred. |
| `error` | Explicit JSON null on success; otherwise `{sqlcode, sqlstate, message, stage}` captured before rollback/reporting. Preserve original values, including negative application codes. |
| `action` | `CONTINUE` on success; `STOP` on an error with no committed changes; `RECONCILE` for errors with `COMMITTED` or `UNKNOWN` persistence. Neither error action authorizes an automatic retry. |

The caller receives the OUT value in a local Snowflake Scripting variable, persists the outcome to the existing automation/feed audit fields, and branches on status. `ERROR` must stop downstream processing even though the CALL completed normally. If RPDM requires a SQL exception to mark the step failed, its procedure-specific SQL adapter must first persist the original JSON details and then raise a caller-level failure. That raised code need not equal the original SQLCODE; the retained JSON/audit values remain the original diagnostic evidence. Do not rely on OUT values surviving a rethrow from the allocating procedure.

The outer caller also catches SQL failures when the procedure cannot return a valid JSON object, including compilation/invocation errors. A missing, invalid, or unknown-version outcome is a failure, never implicit success. A lost connection or terminated session may leave a run incomplete; absence of an error result is not success. Full JSON is retained in qualification evidence; the mock `LAST_ERROR` is limited to its existing 4000 characters. Actual RPDM binding/status integration remains to be verified before cutover; no deployed RPDM modification is claimed.

Snowflake SQL procedures support OUT arguments passed through scripting variables; session variables cannot themselves be OUT arguments. [Snowflake output argument documentation](https://docs.snowflake.com/en/developer-guide/stored-procedure/stored-procedures-snowflake-scripting#using-output-arguments-to-return-values)

The M0 prototype adds `prototypeEvidence` with session IDs, gate timestamps, and a synthetic counter observation exclusively for serialization evidence. This is not a new production reporting requirement. Success from this prototype does not certify assignment, reservation, migration, or allocator validation behavior.


| Table | Field | Description |
| --- | --- | --- |
| FEED_INSTANCE | FEED_INSTANCE_ID | Unique identifier for the feed execution. |
| FEED_INSTANCE | AUTOMATION_GUID | Link to the automation log. |
| FEED_INSTANCE | SOURCE_ID | Source system identifier. Always 99 for CDP Internal Process. |
| FEED_INSTANCE | FEED_ID | Feed identifier. Always 140 for Customer Number Maintenance. |
| FEED_INSTANCE | FEED_PROCESS_RESULT | Authoritative overall execution outcome. |
| FEED_INSTANCE | FEED_START_DATE | Timestamp when feed processing started. |
| FEED_INSTANCE | FEED_END_DATE | Timestamp when feed processing ended. |
| AUTOMATION_LOG | LAST_ERROR_STEP_NAME | The step where the last error occurred. |
| AUTOMATION_LOG | LAST_ERROR | The message or details of the last error. |

## 2. Process Specific

Store one row per procedure invocation in the proposed `STANDARDIZE_AUDIT.CUST_NUM_PROCESS_LOG` table. A retry creates a new row, preserving earlier attempts. `RUN_ID` is the same as `FEED_INSTANCE_ID` throughout staging, processing, and reporting. Each retry has a different `AUTOMATION_GUID`, `FEED_INSTANCE_ID` (and therefore `RUN_ID`), and `CUST_NUM_PROCESS_LOG_ID`. No correlation between retry attempts is required. No separate category-count, check-result, or timing tables are required by this reporting contract.

Mode, execution success, and persistence remain separate. A successful preview has no committed business changes. A successful no-work run is distinguishable from a failed or incomplete run through validation, persistence, and the feed outcome.

### 2.1 Table columns

| Column | Proposed type | Definition |
| --- | --- | --- |
| `CUST_NUM_PROCESS_LOG_ID` | `NUMBER(38,0)` | Primary key; auto-increment starting at 1, incrementing by 1, ordered, following the audit-table convention. |
| `AUTOMATION_GUID` | `VARCHAR(36)` | Externally supplied automation correlation identifier; user-verified contract settled under D06.2. Preserve the supplied value. |
| `FEED_INSTANCE_ID` | `NUMBER(38,0)` | Feed execution invoking this process. |
| `MODE` | `VARCHAR(16)` | `PREVIEW` or `LIVE`. |
| `UNMAPPED_INDIVIDUALS` | `NUMBER(38,0)` | Distinct valid individuals needing assignments at the start of processing. |
| `EXTERNAL_ASSIGNMENTS` | `NUMBER(38,0)` | New external assignments in the validated plan. |
| `GENERATED_ASSIGNMENTS` | `NUMBER(38,0)` | New generated assignments in the validated plan. |
| `RESERVATION_COUNT` | `NUMBER(38,0)` | Distinct new customer-number reservations in the validated plan; excludes existing reservations. |
| `METRICS` | `VARIANT` | JSON object described below. |
| `CREATE_DATETIME` | `TIMESTAMP_NTZ(9)` | Log-row creation time. |
| `CREATE_FEED_INSTANCE_ID` | `NUMBER(38,0)` | Feed execution creating this log row. |
| `UPDATE_DATETIME` | `TIMESTAMP_NTZ(9)` | Last log-row update time; initially null. |
| `UPDATE_FEED_INSTANCE_ID` | `NUMBER(38,0)` | Feed execution updating this log row; initially null. |

Require identity, mode, creation metadata, and the metrics object when creating a row. Counts remain null until known. Populate `UNMAPPED_INDIVIDUALS` after evaluating the valid input population; populate the three output counts only when a validated plan exists. Zero means a measured zero, never an unknown value.

The three output counts always describe the validated plan in both modes. They represent confirmed committed counts only when `persistence` is `COMMITTED`. Retain them if a later apply fails or rolls back; do not relabel them as attempted writes. Reservations are finalized after original dual-ranking external selection completes, without fallback. Count them once per number, without reason breakdowns.

### 2.2 Essential JSON metrics

Use camelCase for every JSON key, including nested objects. Enum values remain uppercase. Include the four count metrics stored as columns, populated from the same calculated values in the same log-row write; JSON values must match their columns, including nulls. Other table fields need not be duplicated in JSON.

| JSON key | Definition |
| --- | --- |
| `unmappedIndividuals` | Same value as `UNMAPPED_INDIVIDUALS`. |
| `externalAssignments` | Same value as `EXTERNAL_ASSIGNMENTS`. |
| `generatedAssignments` | Same value as `GENERATED_ASSIGNMENTS`. |
| `reservationCount` | Same value as `RESERVATION_COUNT`. |
| `generatedSeed` | Allocation boundary used to build the plan; allocation starts at the next permitted value. Null until evaluated. |
| `maxGeneratedValue` | Highest generated number in the validated plan. Null before validation or when no generated assignments are needed. |
| `generatedCapacityRemaining` | Remaining sequential allocation capacity observed during planning, before this run's demand. Null until evaluated. |
| `persistence` | `NOT_ATTEMPTED`, `IN_PROGRESS`, `COMMITTED`, `ROLLED_BACK`, or `UNKNOWN`; describes business-change persistence, not audit-row persistence. |
| `validation.status` | `NOT_RUN`, `PASS`, or `FAIL`. `PASS` requires every required check to have run and passed. |
| `validation.issues` | Array containing only failed or unexecuted required checks. Each entry has `checkId`, `status` (`FAIL` or `NOT_RUN`), and `affectedCount` (null when unknown). Empty when all required checks pass. |

Use explicit JSON nulls for unknown numeric values. The generated seed and maximum remain planning values until commit is confirmed. Under D04.1, the generated seed comes from retained XREF assignments; no separate allocation counter/state object is maintained. Under settled D04.2, do not add comparisons against historical reports/snapshots or history-loss checks, alerts, or failure outcomes for lost generated assignments, including known loss. Continue using the retained-XREF seed. Preview must not persist generated assignments or advance that derived seed. Assignable generated numbers remain `500000001` through `599999999`; `500000000` is reserved. Capacity shortfall can be derived from demand and capacity when both are known rather than stored separately.

Example of a committed run:

```json
{
  "unmappedIndividuals": 150,
  "externalAssignments": 100,
  "generatedAssignments": 50,
  "reservationCount": 20,
  "generatedSeed": 500001000,
  "maxGeneratedValue": 500001050,
  "generatedCapacityRemaining": 99998999,
  "persistence": "COMMITTED",
  "validation": {
    "status": "PASS",
    "issues": []
  }
}
```

Illustrative validation issue:

```json
{
  "checkId": "ASSIGNMENT_COUNT_RECONCILIATION",
  "status": "FAIL",
  "affectedCount": 2
}
```

Check IDs must be stable. Persist exceptions rather than a result row for every successful check. At initialization, validation is `NOT_RUN`; an empty issues array at that point does not imply success. On an unsuccessful completed attempt, include required checks that could not run. Any failed or unexecuted required check prevents success.

### 2.3 Validation and reconciliation

Simplifying reporting does not remove required processing checks. Retain checks for source individual-ID validity; existing assignment integrity and unresolved legacy rows; duplicate individuals or customer numbers; assignment/reservation overlap; blocked or reserved assignments; missing or multiple assignments; external-number disposition and retirement; generated range and capacity; dual-ranking selection without fallback and date priority; plan freshness and writer control; preservation of existing assignments; and absence of business changes during preview.

A validated plan must satisfy:

```text
UNMAPPED_INDIVIDUALS = EXTERNAL_ASSIGNMENTS + GENERATED_ASSIGNMENTS
Required checks failed = 0
Required checks not run = 0
```

Before a live commit, verify that applied counts match the validated plan separately for external assignments, generated assignments, and reservations. Unexpectedly skipped writes, unexpected updates/deletes under the insert-only contract, invalid ranges, and count mismatches remain failure conditions. Record detected check failures in `validation.issues`; retain the primary execution error in `AUTOMATION_LOG`.

Plan validation can pass before apply, but final validation status must include required apply checks. A later failed check changes the status to `FAIL` without erasing the previously validated plan counts. Validation passing alone does not establish execution success or commitment.

### 2.4 Log lifecycle and persistence

1. Create the invocation row with null counts, `persistence: "NOT_ATTEMPTED"`, and `validation.status: "NOT_RUN"`.
2. Populate measured input metrics and, once validated, the plan counts and allocation metrics. Write matching column and JSON values together.
3. For preview, retain `NOT_ATTEMPTED` for business persistence. Audit logging is allowed, but business assignments and reservations must remain unchanged; the D04.1 seed remains derived from committed XREF rows.
4. For live apply, record `IN_PROGRESS` before attempting business changes. Reconcile all three applied output counts against the plan before commit. Set `COMMITTED` only after commit is confirmed.
5. If business changes are confirmed rolled back, record `ROLLED_BACK`. If persistence cannot be established, record `UNKNOWN`; an interrupted `IN_PROGRESS` row must never be interpreted as committed.
6. Preserve failure reporting outside the rolled-back business transaction. Update the log's update metadata and the existing execution/error records. A diagnostic-write failure must not replace the original error or imply that business changes were rolled back after a confirmed commit.

Preview, not-attempted, and confirmed rolled-back runs have zero committed business changes, even when plan counts are nonzero. Committed counts are unknown for `IN_PROGRESS` or `UNKNOWN`. For `COMMITTED`, use the validated output counts. Successful zero-work live runs can retain `NOT_ATTEMPTED` when no assignment/reservation writes are needed; the gate/planning transaction still runs and closes. The feed outcome and passing validation distinguish these from failures.

D07.1 selects the dedicated audit logging helper; transaction ownership and independent durability remain implementation obligations; their dedicated fault qualification is excluded under the accepted reduced scope. An audit-write failure after business commit must be surfaced to the harness; it must not lead to blind reapplication of the plan.

### 2.5 F12 error handling decisions (October 19)

Capture the original error code, state, message, and processing stage before any diagnostic work, if performed. Protect rollback and reporting work so a secondary failure cannot replace the original runtime SQL error. The procedure-specific harness/RPDM caller receives the original details in RESULT OUT VARIANT and captures any escaping SQL error; shared framework redesign is out of scope.

Reuse `AUTOMATION_LOG.LAST_ERROR_STEP_NAME` and `LAST_ERROR` for persisted stage/error reporting under the existing infrastructure contract. Preserve failure reporting separately from the rolled-back business transaction as described above. Persisted bounded, rule-specific samples are out of scope; retain the compact `validation.issues` contract without adding sample tables or sample payloads. The original generic exception debug extract is not a required replacement deliverable.

The revised F12 contract preserves original details in ERROR JSON and requires an outer SQL-error fallback. Business-error JSON/caller reaction remains required testing. Secondary rollback/logging failures and post-commit fault injection are excluded and unverified under the accepted reduced scope; truthful persistence remains an implementation requirement.

### 2.6 Metrics excluded from routine collection

Keep routine reporting limited to the columns and JSON keys above. Do not collect population/occurrence breakdowns, external contention counts, candidate-rank breakdowns, generated-assignment reason breakdowns, reservation-reason totals, reused coverage, a proposed/accepted/rejected/committed matrix, successful per-check records, or redundant totals and rates.

Reuse existing audit fields for execution timing and errors. Stage timings, lock statistics, retry counts, per-stage query IDs, scan/spill statistics, and warehouse cost estimates are outside this routine reporting contract. Investigate these separately when needed. Business-rule checks remain mandatory even when their successful intermediate metrics are not persisted.
